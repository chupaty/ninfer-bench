//! 3D Perspective smooth directional chase camera rig.

use bevy_ecs::prelude::*;
use bevy_math::{EulerRot, Quat, Vec3};
use bevy_time::Time;
use bevy_transform::components::Transform;

/// Marker and configuration for smooth directional chase camera.
#[derive(Component, Debug, Clone, PartialEq)]
pub struct SmoothFollowCamera {
    /// Target entity to follow (e.g. vehicle).
    pub target: Option<Entity>,
    /// Distance behind the target in world units.
    pub distance: f32,
    /// Height above the target in world units.
    pub height: f32,
    /// Position damping speed (higher = snappier, lower = smoother).
    pub pos_smoothness: f32,
    /// Heading/yaw rotation tracking damping speed.
    pub rot_smoothness: f32,
    /// Vertical look-at target offset (e.g. aiming slightly above vehicle center).
    pub look_at_offset: Vec3,
    /// Current smoothed camera yaw angle in radians.
    pub current_yaw: f32,
}

impl Default for SmoothFollowCamera {
    fn default() -> Self {
        Self {
            target: None,
            distance: 28.0,
            height: 18.0,
            pos_smoothness: 8.0,
            rot_smoothness: 4.5,
            look_at_offset: Vec3::new(0.0, 1.2, 0.0),
            current_yaw: 0.0,
        }
    }
}

/// System that smoothly updates the camera's position and orientation to track its target from behind.
pub fn camera_follow_system(
    time: Res<Time>,
    target_query: Query<&Transform, Without<SmoothFollowCamera>>,
    mut camera_query: Query<(&mut Transform, &mut SmoothFollowCamera)>,
) {
    let dt = time.delta_secs();

    for (mut cam_transform, mut follow) in camera_query.iter_mut() {
        let Some(target_entity) = follow.target else {
            continue;
        };

        let Ok(target_transform) = target_query.get(target_entity) else {
            continue;
        };

        // Extract yaw from target's rotation
        let (target_yaw, _, _) = target_transform.rotation.to_euler(EulerRot::YXZ);

        // Smoothly interpolate camera yaw towards target yaw
        let mut diff = target_yaw - follow.current_yaw;
        while diff < -std::f32::consts::PI {
            diff += std::f32::consts::TAU;
        }
        while diff > std::f32::consts::PI {
            diff -= std::f32::consts::TAU;
        }
        follow.current_yaw += diff * (follow.rot_smoothness * dt).clamp(0.0, 1.0);

        // Compute backward offset vector from smoothed yaw
        let yaw_rot = Quat::from_rotation_y(follow.current_yaw);
        let forward_dir = yaw_rot * Vec3::NEG_Z;
        let desired_pos = target_transform.translation - forward_dir * follow.distance + Vec3::new(0.0, follow.height, 0.0);
        let look_target = target_transform.translation + follow.look_at_offset + forward_dir * 4.0;

        // Smoothly interpolate camera position
        cam_transform.translation = cam_transform
            .translation
            .lerp(desired_pos, (follow.pos_smoothness * dt).clamp(0.0, 1.0));

        // Point camera at look target
        cam_transform.look_at(look_target, Vec3::Y);
    }
}
