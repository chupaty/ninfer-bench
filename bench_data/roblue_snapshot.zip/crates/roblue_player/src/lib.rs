//! Player controller, movement, heightfield terrain adherence, and follow camera for Roblue.

pub mod camera;
pub mod controller;
pub mod movement;

pub use camera::{camera_follow_system, SmoothFollowCamera};
pub use controller::{AimReticle, FootstepTimer, PlayerController};
pub use movement::{player_input_system, player_mouse_aim_system, player_movement_and_terrain_system};

use bevy_app::prelude::*;

/// Plugin registering player movement, terrain height snapping, mouse aim, and camera systems.
pub struct RobluePlayerPlugin;

impl Plugin for RobluePlayerPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(
            Update,
            (
                player_input_system,
                player_mouse_aim_system,
                player_movement_and_terrain_system,
                camera_follow_system,
            ),
        );
    }
}
