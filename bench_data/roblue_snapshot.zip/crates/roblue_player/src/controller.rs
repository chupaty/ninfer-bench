//! Player controller state and components.

use bevy_ecs::prelude::*;
use bevy_math::{Vec2, Vec3};
use bevy_time::Timer;
use serde::{Deserialize, Serialize};

/// Core player movement and state component.
#[derive(Component, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PlayerController {
    /// Movement speed in world units per second.
    pub move_speed: f32,
    /// Facing orientation angle in radians around the Y-axis.
    pub facing_angle: f32,
    /// Current input movement vector (normalized direction on XZ plane).
    pub move_direction: Vec2,
    /// Whether the player is currently moving.
    pub is_moving: bool,
    /// 3D World position where the mouse cursor is currently aiming.
    pub aim_target_world: Vec3,
}

impl Default for PlayerController {
    fn default() -> Self {
        Self {
            move_speed: 18.0,
            facing_angle: 0.0,
            move_direction: Vec2::ZERO,
            is_moving: false,
            aim_target_world: Vec3::ZERO,
        }
    }
}

/// Interval timer for playing footstep audio effects while traversing terrain.
#[derive(Component, Debug, Clone)]
pub struct FootstepTimer {
    pub timer: Timer,
}

impl Default for FootstepTimer {
    fn default() -> Self {
        Self {
            timer: Timer::from_seconds(0.32, bevy_time::TimerMode::Repeating),
        }
    }
}

/// Marker component for the in-world mouse aiming reticle.
#[derive(Component, Debug, Default, Clone, Copy)]
pub struct AimReticle;
