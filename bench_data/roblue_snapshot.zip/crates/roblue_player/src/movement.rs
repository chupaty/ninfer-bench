//! Player input collection, ground movement, terrain height adherence, and mouse aim raycasting.

use crate::controller::{AimReticle, FootstepTimer, PlayerController};
use bevy_camera::Camera;
use bevy_ecs::prelude::*;
use bevy_input::keyboard::KeyCode;
use bevy_input::mouse::MouseButton;
use bevy_input::ButtonInput;
use bevy_math::{Quat, Vec2, Vec3};
use bevy_time::Time;
use bevy_transform::components::{GlobalTransform, Transform};
use bevy_window::{PrimaryWindow, Window};
use roblue_audio::{PlaySfxEvent, SfxKind};
use roblue_core::PlayerMarker;
use roblue_terrain::{Heightfield, TerrainMeshConfig};

/// System that collects keyboard WASD movement inputs and mouse action clicks.
pub fn player_input_system(
    mut commands: Commands,
    keyboard: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut query: Query<&mut PlayerController>,
) {
    let mut input_dir = Vec2::ZERO;

    if keyboard.pressed(KeyCode::KeyW) || keyboard.pressed(KeyCode::ArrowUp) {
        input_dir.y -= 1.0; // Forward (towards -Z in world coordinates)
    }
    if keyboard.pressed(KeyCode::KeyS) || keyboard.pressed(KeyCode::ArrowDown) {
        input_dir.y += 1.0; // Backward (towards +Z in world coordinates)
    }
    if keyboard.pressed(KeyCode::KeyA) || keyboard.pressed(KeyCode::ArrowLeft) {
        input_dir.x -= 1.0; // Left (towards -X in world coordinates)
    }
    if keyboard.pressed(KeyCode::KeyD) || keyboard.pressed(KeyCode::ArrowRight) {
        input_dir.x += 1.0; // Right (towards +X in world coordinates)
    }

    let is_moving = input_dir.length_squared() > 0.0;
    let normalized_dir = if is_moving {
        input_dir.normalize()
    } else {
        Vec2::ZERO
    };

    for mut controller in query.iter_mut() {
        controller.move_direction = normalized_dir;
        controller.is_moving = is_moving;
    }

    // Sound effect trigger on mouse click (evidence of sound support)
    if mouse_buttons.just_pressed(MouseButton::Left) {
        commands.trigger(
            PlaySfxEvent::new(SfxKind::ActionClick)
                .with_volume(0.65)
                .with_pitch(1.15),
        );
    }
}

/// System that raycasts the mouse cursor into the 3D scene and rotates the player toward the aim target.
pub fn player_mouse_aim_system(
    window_query: Query<&Window, With<PrimaryWindow>>,
    camera_query: Query<(&Camera, &GlobalTransform)>,
    mut player_query: Query<(&mut Transform, &mut PlayerController), With<PlayerMarker>>,
    mut reticle_query: Query<&mut Transform, (With<AimReticle>, Without<PlayerMarker>)>,
) {
    let Some(window) = window_query.iter().next() else {
        return;
    };
    let Some(cursor_pos) = window.cursor_position() else {
        return;
    };
    let Some((camera, camera_transform)) = camera_query.iter().next() else {
        return;
    };

    let Ok(ray) = camera.viewport_to_world(camera_transform, cursor_pos) else {
        return;
    };
    let dir = ray.direction.as_vec3();

    if dir.y.abs() < 1e-4 {
        return;
    }

    for (mut player_transform, mut controller) in player_query.iter_mut() {
        let player_y = player_transform.translation.y;
        let t = (player_y - ray.origin.y) / dir.y;
        if t <= 0.0 {
            continue;
        }

        let hit_point = ray.origin + dir * t;
        controller.aim_target_world = hit_point;

        // Calculate aim vector from player to ground mouse hit point
        let aim_vec = Vec2::new(
            hit_point.x - player_transform.translation.x,
            hit_point.z - player_transform.translation.z,
        );

        if aim_vec.length_squared() > 0.01 {
            let aim_angle = (-aim_vec.x).atan2(-aim_vec.y);
            controller.facing_angle = aim_angle;
            player_transform.rotation = Quat::from_rotation_y(aim_angle);
        }

        // Update the 3D aim reticle position to hover slightly above ground
        for mut reticle_transform in reticle_query.iter_mut() {
            reticle_transform.translation = hit_point + Vec3::new(0.0, 0.15, 0.0);
        }
    }
}

/// System that translates the player across the terrain while snapping to elevation.
pub fn player_movement_and_terrain_system(
    mut commands: Commands,
    time: Res<Time>,
    terrain_config: Res<TerrainMeshConfig>,
    mut query: Query<(&mut Transform, &PlayerController, &mut FootstepTimer), With<PlayerMarker>>,
) {
    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    for (mut transform, controller, mut footstep_timer) in query.iter_mut() {
        if controller.is_moving {
            // 1. Move on XZ plane
            let delta_x = controller.move_direction.x * controller.move_speed * dt;
            let delta_z = controller.move_direction.y * controller.move_speed * dt;

            transform.translation.x += delta_x;
            transform.translation.z += delta_z;

            // 2. Footstep sound interval trigger
            footstep_timer.timer.tick(time.delta());
            if footstep_timer.timer.just_finished() {
                commands.trigger(
                    PlaySfxEvent::new(SfxKind::Footstep)
                        .with_volume(0.35)
                        .with_pitch(0.95 + (transform.translation.x.abs() % 0.2)),
                );
            }
        }

        // 3. Sample terrain elevation at current (X, Z) and snap player's Y position
        let ground_y = hf.sample_height(transform.translation.x, transform.translation.z);
        const PLAYER_HEIGHT_CLEARANCE: f32 = 1.0;
        transform.translation.y = ground_y + PLAYER_HEIGHT_CLEARANCE;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_heightfield_adherence() {
        let config = TerrainMeshConfig::default();
        let hf = Heightfield::new(config.heightfield);

        let test_x = 15.0;
        let test_z = -22.0;
        let ground_y = hf.sample_height(test_x, test_z);

        let player_y = ground_y + 1.0;
        assert_eq!(player_y, ground_y + 1.0);
    }
}
