//! Systems for burst firing, homing projectile trajectory, terrain collisions, and explosive blasts.

use crate::components::{BurstShooter, ExplosionEffect, Projectile, WeaponAssets};
use bevy_asset::Assets;
use bevy_color::{Color, LinearRgba};
use bevy_ecs::prelude::*;
use bevy_input::mouse::MouseButton;
use bevy_input::ButtonInput;
use bevy_math::{primitives::Sphere, Vec2, Vec3};
use bevy_mesh::{Mesh, Mesh3d};
use bevy_pbr::{MeshMaterial3d, StandardMaterial};
use bevy_time::Time;
use bevy_transform::components::Transform;
use roblue_audio::{PlaySfxEvent, SfxKind};
use roblue_core::{EnemyMarker, PlayerMarker};
use roblue_enemy::OrcEnemy;
use roblue_player::PlayerController;
use roblue_terrain::{Heightfield, TerrainMeshConfig};

/// Startup system that compiles shared projectile and explosion mesh and material assets.
pub fn setup_weapon_assets(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let bullet_mesh = meshes.add(Sphere::new(0.20));
    let bullet_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.2, 0.85, 1.0),
        emissive: LinearRgba::new(0.4, 1.8, 2.4, 1.0),
        unlit: true,
        ..Default::default()
    });

    let big_bullet_mesh = meshes.add(Sphere::new(0.38));
    let big_bullet_material = materials.add(StandardMaterial {
        base_color: Color::srgb(1.0, 0.7, 0.1),
        emissive: LinearRgba::new(3.0, 1.8, 0.2, 1.0),
        unlit: true,
        ..Default::default()
    });

    let explosion_mesh = meshes.add(Sphere::new(1.0));
    let explosion_material = materials.add(StandardMaterial {
        base_color: Color::srgba(1.0, 0.45, 0.1, 0.9),
        emissive: LinearRgba::new(3.5, 1.4, 0.15, 1.0),
        unlit: true,
        ..Default::default()
    });

    commands.insert_resource(WeaponAssets {
        bullet_mesh,
        bullet_material,
        big_bullet_mesh,
        big_bullet_material,
        explosion_mesh,
        explosion_material,
    });

    tracing::info!("Roblue WeaponAssets initialized with kinetic and explosive payloads.");
}

/// Helper function to spawn an expanding explosion shockwave.
pub fn spawn_explosion(
    commands: &mut Commands,
    assets: &WeaponAssets,
    position: Vec3,
    radius: f32,
) {
    commands.spawn((
        Mesh3d(assets.explosion_mesh.clone()),
        MeshMaterial3d(assets.explosion_material.clone()),
        Transform::from_translation(position).with_scale(Vec3::splat(0.4)),
        ExplosionEffect::new(radius),
    ));

    // Heavy blast rumble sound effect
    commands.trigger(
        PlaySfxEvent::new(SfxKind::LevelUp)
            .with_volume(0.85)
            .with_pitch(0.60),
    );
}

/// Listens for LEFT-CLICK to queue a 10-shot burst over 1.0 second.
pub fn burst_fire_input_system(
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut query: Query<&mut BurstShooter, With<PlayerMarker>>,
) {
    if mouse_buttons.just_pressed(MouseButton::Left) {
        for mut shooter in query.iter_mut() {
            shooter.shots_queued = shooter.shots_queued.saturating_add(10);
            let dur = shooter.shot_timer.duration();
            shooter.shot_timer.set_elapsed(dur);
        }
    }
}

/// Ticks the burst shooter and fires homing bullets toward the closest orc.
pub fn burst_fire_system(
    mut commands: Commands,
    time: Res<Time>,
    weapon_assets: Option<Res<WeaponAssets>>,
    mut player_query: Query<(&Transform, Option<&PlayerController>, &mut BurstShooter), With<PlayerMarker>>,
    enemy_query: Query<(Entity, &Transform), With<EnemyMarker>>,
) {
    let Some(assets) = weapon_assets else {
        return;
    };

    for (player_transform, controller_opt, mut shooter) in player_query.iter_mut() {
        if shooter.shots_queued == 0 {
            continue;
        }

        shooter.shot_timer.tick(time.delta());

        if shooter.shot_timer.just_finished() {
            let spawn_pos = player_transform.translation + Vec3::new(0.0, 0.8, 0.0);
            let player_xz = Vec2::new(player_transform.translation.x, player_transform.translation.z);

            // 1. Find the closest orc
            let mut closest_enemy: Option<(Entity, Vec3, f32)> = None;

            for (enemy_entity, enemy_transform) in enemy_query.iter() {
                let enemy_pos = enemy_transform.translation + Vec3::new(0.0, 0.9, 0.0);
                let enemy_xz = Vec2::new(enemy_pos.x, enemy_pos.z);
                let dist_sq = (player_xz - enemy_xz).length_squared();

                if let Some((_, _, best_dist_sq)) = closest_enemy {
                    if dist_sq < best_dist_sq {
                        closest_enemy = Some((enemy_entity, enemy_pos, dist_sq));
                    }
                } else {
                    closest_enemy = Some((enemy_entity, enemy_pos, dist_sq));
                }
            }

            // 2. Compute initial bullet velocity
            let (target_entity, velocity) = if let Some((target_id, target_pos, _)) = closest_enemy {
                let dir = (target_pos - spawn_pos).normalize_or_zero();
                (Some(target_id), dir * 34.0)
            } else if let Some(controller) = controller_opt {
                let angle = controller.facing_angle;
                let dir = Vec3::new(-angle.sin(), 0.0, -angle.cos());
                (None, dir * 34.0)
            } else {
                let dir = player_transform.forward().as_vec3();
                (None, dir * 34.0)
            };

            // 3. Spawn projectile entity
            commands.spawn((
                Mesh3d(assets.bullet_mesh.clone()),
                MeshMaterial3d(assets.bullet_material.clone()),
                Transform::from_translation(spawn_pos),
                Projectile::autocannon_bullet(velocity, target_entity),
            ));

            // 4. Trigger shot sound effect
            commands.trigger(
                PlaySfxEvent::new(SfxKind::ActionClick)
                    .with_volume(0.45)
                    .with_pitch(1.3 + (shooter.shots_queued as f32 * 0.03)),
            );

            shooter.shots_queued = shooter.shots_queued.saturating_sub(1);
        }
    }
}

/// Updates projectile positions, handles terrain impact & enemy hits, detonating explosions and killing enemies.
#[allow(clippy::type_complexity)]
pub fn projectile_movement_and_collision_system(
    mut commands: Commands,
    time: Res<Time>,
    weapon_assets: Option<Res<WeaponAssets>>,
    terrain_config: Res<TerrainMeshConfig>,
    mut projectile_query: Query<(Entity, &mut Transform, &mut Projectile), Without<EnemyMarker>>,
    mut enemy_query: Query<(Entity, &Transform, &mut OrcEnemy), (With<EnemyMarker>, Without<Projectile>)>,
) {
    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());
    const HIT_RADIUS: f32 = 0.9;

    for (proj_entity, mut proj_transform, mut proj) in projectile_query.iter_mut() {
        proj.lifetime.tick(time.delta());
        if proj.lifetime.just_finished() {
            commands.entity(proj_entity).try_despawn();
            continue;
        }

        // Homing guidance toward target if target is alive
        if let Some(target_id) = proj.target_entity
            && let Ok((_, target_transform, _)) = enemy_query.get(target_id)
        {
            let target_pos = target_transform.translation + Vec3::new(0.0, 0.9, 0.0);
            let to_target = (target_pos - proj_transform.translation).normalize_or_zero();
            proj.velocity = proj.velocity.lerp(to_target * proj.speed, (14.0 * dt).clamp(0.0, 1.0));
        }

        proj_transform.translation += proj.velocity * dt;

        // 1. Terrain Collision Detection
        let ground_y = hf.sample_height(proj_transform.translation.x, proj_transform.translation.z);
        if proj_transform.translation.y <= ground_y + 0.15 {
            // Projectile hit the terrain!
            if proj.is_explosive
                && let Some(ref assets) = weapon_assets
            {
                let blast_pos = Vec3::new(proj_transform.translation.x, ground_y + 0.3, proj_transform.translation.z);
                spawn_explosion(&mut commands, assets, blast_pos, proj.explosion_radius);
            }
            commands.entity(proj_entity).try_despawn();
            continue;
        }

        // 2. Enemy Collision Detection (Instant Kill + Detonation)
        let mut hit_enemy = false;

        for (enemy_entity, enemy_transform, orc) in enemy_query.iter_mut() {
            let orc_center = enemy_transform.translation + Vec3::new(0.0, 0.9, 0.0);
            let dist = (proj_transform.translation - orc_center).length();

            if dist < (HIT_RADIUS + orc.hitbox_radius) {
                hit_enemy = true;

                if proj.is_explosive
                    && let Some(ref assets) = weapon_assets
                {
                    spawn_explosion(&mut commands, assets, proj_transform.translation, proj.explosion_radius);
                }

                // All bullets now kill enemy instantly!
                commands.entity(enemy_entity).try_despawn();

                commands.trigger(
                    PlaySfxEvent::new(SfxKind::LevelUp)
                        .with_volume(0.55)
                        .with_pitch(1.35),
                );

                break;
            }
        }

        if hit_enemy {
            commands.entity(proj_entity).try_despawn();
        }
    }
}

/// Animates expanding explosion shockwaves and instantly kills all enemies within blast radius.
#[allow(clippy::type_complexity)]
pub fn explosion_system(
    mut commands: Commands,
    time: Res<Time>,
    mut explosion_query: Query<(Entity, &mut Transform, &mut ExplosionEffect), Without<EnemyMarker>>,
    enemy_query: Query<(Entity, &Transform), (With<EnemyMarker>, Without<ExplosionEffect>)>,
) {
    let dt = time.delta();

    for (exp_entity, mut exp_transform, mut effect) in explosion_query.iter_mut() {
        effect.lifetime.tick(dt);
        let progress = effect.lifetime.fraction();

        // Fast expanding shockwave scale curve
        let scale = effect.max_radius * (1.0 - (1.0 - progress).powi(2));
        exp_transform.scale = Vec3::splat(scale.max(0.2));

        let current_blast_radius = scale * 1.1;

        // Area-of-effect lethal blast: all enemies inside die instantly!
        for (enemy_entity, enemy_transform) in enemy_query.iter() {
            let enemy_pos = enemy_transform.translation + Vec3::new(0.0, 0.9, 0.0);
            let dist = (exp_transform.translation - enemy_pos).length();

            if dist <= current_blast_radius {
                commands.entity(enemy_entity).try_despawn();
                commands.trigger(
                    PlaySfxEvent::new(SfxKind::ActionClick)
                        .with_volume(0.5)
                        .with_pitch(0.75),
                );
            }
        }

        if effect.lifetime.just_finished() {
            commands.entity(exp_entity).try_despawn();
        }
    }
}
