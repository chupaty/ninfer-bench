//! Components and resources for weapons, burst firing, projectiles, and blast explosions.

use bevy_asset::Handle;
use bevy_ecs::prelude::*;
use bevy_math::Vec3;
use bevy_mesh::Mesh;
use bevy_pbr::StandardMaterial;
use bevy_time::{Timer, TimerMode};

/// Component attached to the player managing queued burst fire shots.
#[derive(Component, Debug, Clone)]
pub struct BurstShooter {
    /// Number of shots remaining in the active burst.
    pub shots_queued: u32,
    /// Interval timer between individual shots in a burst (0.10s).
    pub shot_timer: Timer,
}

impl Default for BurstShooter {
    fn default() -> Self {
        Self {
            shots_queued: 0,
            shot_timer: Timer::from_seconds(0.10, TimerMode::Repeating),
        }
    }
}

/// Projectile component tracking trajectory, speed, damage, and explosive blast payload.
#[derive(Component, Debug, Clone, PartialEq)]
pub struct Projectile {
    pub speed: f32,
    pub damage: f32,
    pub target_entity: Option<Entity>,
    pub velocity: Vec3,
    pub lifetime: Timer,
    /// Whether this projectile detonates on impact with terrain or enemies.
    pub is_explosive: bool,
    /// Area-of-effect blast radius upon detonation.
    pub explosion_radius: f32,
}

impl Default for Projectile {
    fn default() -> Self {
        Self {
            speed: 34.0,
            damage: 1.0,
            target_entity: None,
            velocity: Vec3::ZERO,
            lifetime: Timer::from_seconds(3.0, TimerMode::Once),
            is_explosive: false,
            explosion_radius: 0.0,
        }
    }
}

impl Projectile {
    /// Constructs a Heavy Cannon explosive shell.
    pub fn heavy_shell(velocity: Vec3, target_entity: Option<Entity>) -> Self {
        Self {
            speed: 42.0,
            damage: 3.0,
            target_entity,
            velocity,
            lifetime: Timer::from_seconds(3.0, TimerMode::Once),
            is_explosive: true,
            explosion_radius: 5.5,
        }
    }

    /// Constructs a Rapid Autocannon kinetic bullet.
    pub fn autocannon_bullet(velocity: Vec3, target_entity: Option<Entity>) -> Self {
        Self {
            speed: 34.0,
            damage: 1.0,
            target_entity,
            velocity,
            lifetime: Timer::from_seconds(2.5, TimerMode::Once),
            is_explosive: false,
            explosion_radius: 0.0,
        }
    }
}

/// Expanding shockwave and area-of-effect lethal blast.
#[derive(Component, Debug, Clone)]
pub struct ExplosionEffect {
    pub lifetime: Timer,
    pub max_radius: f32,
}

impl ExplosionEffect {
    pub fn new(max_radius: f32) -> Self {
        Self {
            lifetime: Timer::from_seconds(0.35, TimerMode::Once),
            max_radius,
        }
    }
}

/// Shared asset handles for high-performance projectile spawning and blast effects.
#[derive(Resource, Debug, Clone)]
pub struct WeaponAssets {
    pub bullet_mesh: Handle<Mesh>,
    pub bullet_material: Handle<StandardMaterial>,
    pub big_bullet_mesh: Handle<Mesh>,
    pub big_bullet_material: Handle<StandardMaterial>,
    pub explosion_mesh: Handle<Mesh>,
    pub explosion_material: Handle<StandardMaterial>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_burst_shooter_defaults() {
        let shooter = BurstShooter::default();
        assert_eq!(shooter.shots_queued, 0);
        assert_eq!(shooter.shot_timer.duration().as_secs_f32(), 0.10);
    }

    #[test]
    fn test_projectile_defaults() {
        let proj = Projectile::default();
        assert_eq!(proj.speed, 34.0);
        assert_eq!(proj.damage, 1.0);
        assert_eq!(proj.target_entity, None);
        assert!(!proj.is_explosive);
        assert_eq!(proj.explosion_radius, 0.0);
    }

    #[test]
    fn test_heavy_shell_creation() {
        let shell = Projectile::heavy_shell(Vec3::NEG_Z * 40.0, None);
        assert!(shell.is_explosive);
        assert!(shell.explosion_radius > 4.0);
    }

    #[test]
    fn test_explosion_effect() {
        let exp = ExplosionEffect::new(5.0);
        assert_eq!(exp.max_radius, 5.0);
        assert_eq!(exp.lifetime.duration().as_secs_f32(), 0.35);
    }
}
