//! Burst firing, homing projectiles, targeting, and collision resolution for weapons.

pub mod components;
pub mod systems;

pub use components::{BurstShooter, ExplosionEffect, Projectile, WeaponAssets};
pub use systems::{
    burst_fire_input_system, burst_fire_system, explosion_system,
    projectile_movement_and_collision_system, setup_weapon_assets, spawn_explosion,
};

use bevy_app::prelude::*;

/// Plugin registering weapon assets, burst input handling, homing projectiles, and collision damage.
pub struct RoblueWeaponPlugin;

impl Plugin for RoblueWeaponPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, setup_weapon_assets)
            .add_systems(
                Update,
                (
                    burst_fire_input_system,
                    burst_fire_system,
                    projectile_movement_and_collision_system,
                    explosion_system,
                ),
            );
    }
}
