//! Deterministic 2D Simplex Noise and Fractal Brownian Motion (FBM) generator.

use serde::{Deserialize, Serialize};

/// Configuration for Fractal Brownian Motion (FBM) terrain noise.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct NoiseConfig {
    /// Random seed for noise generation.
    pub seed: u32,
    /// Base spatial frequency of the noise (smaller = larger features).
    pub base_frequency: f32,
    /// Number of layered noise octaves (typically 3 to 6).
    pub octaves: usize,
    /// Amplitude multiplier per octave (typically ~0.5).
    pub persistence: f32,
    /// Frequency multiplier per octave (typically ~2.0).
    pub lacunarity: f32,
    /// Overall height multiplier in world units.
    pub amplitude: f32,
}

impl Default for NoiseConfig {
    fn default() -> Self {
        Self {
            seed: 1337,
            base_frequency: 0.02,
            octaves: 4,
            persistence: 0.5,
            lacunarity: 2.0,
            amplitude: 12.0,
        }
    }
}

/// 2D Simplex Noise evaluator based on Stefan Gustavson's algorithm.
#[derive(Debug, Clone)]
pub struct SimplexNoise2D {
    perm: [u8; 512],
}

impl SimplexNoise2D {
    /// Creates a new Simplex Noise generator initialized with the given seed.
    pub fn new(seed: u32) -> Self {
        let mut p: [u8; 256] = [0; 256];
        for (i, val) in p.iter_mut().enumerate() {
            *val = i as u8;
        }

        // Deterministic Fisher-Yates shuffle using LCG from seed
        let mut state = seed.wrapping_add(0x9E3779B9);
        for i in (1..256).rev() {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            let j = (state >> 16) as usize % (i + 1);
            p.swap(i, j);
        }

        let mut perm = [0u8; 512];
        for (i, val) in perm.iter_mut().enumerate() {
            *val = p[i & 255];
        }

        Self { perm }
    }

    /// Evaluates 2D Simplex noise in range [-1.0, 1.0].
    pub fn sample(&self, x: f32, y: f32) -> f32 {
        const F2: f32 = 0.366_025_42; // 0.5 * (sqrt(3.0) - 1.0)
        const G2: f32 = 0.211_324_87; // (3.0 - sqrt(3.0)) / 6.0

        let s = (x + y) * F2;
        let i = (x + s).floor() as i32;
        let j = (y + s).floor() as i32;

        let t = (i + j) as f32 * G2;
        let x0 = x - (i as f32 - t);
        let y0 = y - (j as f32 - t);

        let (i1, j1) = if x0 > y0 { (1, 0) } else { (0, 1) };

        let x1 = x0 - i1 as f32 + G2;
        let y1 = y0 - j1 as f32 + G2;
        let x2 = x0 - 1.0 + 2.0 * G2;
        let y2 = y0 - 1.0 + 2.0 * G2;

        let ii = (i & 255) as usize;
        let jj = (j & 255) as usize;

        let gi0 = self.perm[ii + self.perm[jj] as usize] % 12;
        let gi1 = self.perm[ii + i1 as usize + self.perm[jj + j1 as usize] as usize] % 12;
        let gi2 = self.perm[ii + 1 + self.perm[jj + 1] as usize] % 12;

        let mut n0 = 0.0;
        let mut t0 = 0.5 - x0 * x0 - y0 * y0;
        if t0 > 0.0 {
            t0 *= t0;
            n0 = t0 * t0 * grad(gi0, x0, y0);
        }

        let mut n1 = 0.0;
        let mut t1 = 0.5 - x1 * x1 - y1 * y1;
        if t1 > 0.0 {
            t1 *= t1;
            n1 = t1 * t1 * grad(gi1, x1, y1);
        }

        let mut n2 = 0.0;
        let mut t2 = 0.5 - x2 * x2 - y2 * y2;
        if t2 > 0.0 {
            t2 *= t2;
            n2 = t2 * t2 * grad(gi2, x2, y2);
        }

        70.0 * (n0 + n1 + n2)
    }

    /// Evaluates multi-octave Fractal Brownian Motion (FBM).
    pub fn sample_fbm(&self, x: f32, z: f32, config: &NoiseConfig) -> f32 {
        let mut total = 0.0;
        let mut freq = config.base_frequency;
        let mut amp = 1.0;
        let mut max_amp = 0.0;

        for _ in 0..config.octaves {
            total += self.sample(x * freq, z * freq) * amp;
            max_amp += amp;
            amp *= config.persistence;
            freq *= config.lacunarity;
        }

        (total / max_amp) * config.amplitude
    }
}

#[inline(always)]
fn grad(gi: u8, x: f32, y: f32) -> f32 {
    let (u, v) = match gi & 7 {
        0 => (x, y),
        1 => (-x, y),
        2 => (x, -y),
        3 => (-x, -y),
        4 => (y, x),
        5 => (-y, x),
        6 => (y, -x),
        _ => (-y, -x),
    };
    u + v
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_noise_bounds() {
        let noise = SimplexNoise2D::new(42);
        for x in -100..100 {
            for y in -100..100 {
                let val = noise.sample(x as f32 * 0.1, y as f32 * 0.1);
                assert!(val >= -1.05 && val <= 1.05, "Noise sample out of expected range: {}", val);
            }
        }
    }

    #[test]
    fn test_fbm_deterministic() {
        let config = NoiseConfig::default();
        let noise1 = SimplexNoise2D::new(config.seed);
        let noise2 = SimplexNoise2D::new(config.seed);

        let h1 = noise1.sample_fbm(12.5, -34.2, &config);
        let h2 = noise2.sample_fbm(12.5, -34.2, &config);

        assert_eq!(h1, h2, "FBM evaluation must be strictly deterministic");
    }
}
