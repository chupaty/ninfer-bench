//! Procedural terrain and water mesh builder for Roblue.

pub mod biome;
pub mod builder;
pub mod heightfield;
pub mod noise;

pub use biome::BiomePalette;
pub use builder::{RawMeshData, TerrainBuilder, TerrainMeshConfig};
pub use heightfield::{Heightfield, HeightfieldConfig};
pub use noise::{NoiseConfig, SimplexNoise2D};

use bevy_app::prelude::*;

/// Terrain plugin registering default terrain resources.
pub struct TerrainPlugin;

impl Plugin for TerrainPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<TerrainMeshConfig>();
    }
}
