//! Mesh construction for procedural terrain and water planes.

use crate::biome::BiomePalette;
use crate::heightfield::{Heightfield, HeightfieldConfig};
use bevy_ecs::prelude::*;
use bevy_mesh::{Indices, Mesh, PrimitiveTopology};
use bevy_asset::RenderAssetUsages;
use serde::{Deserialize, Serialize};

/// Configuration for terrain mesh generation.
#[derive(Resource, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TerrainMeshConfig {
    /// Number of grid quad cells along X axis.
    pub width_cells: usize,
    /// Number of grid quad cells along Z axis.
    pub depth_cells: usize,
    /// World distance between adjacent vertices.
    pub cell_size: f32,
    /// Heightfield procedural configuration.
    pub heightfield: HeightfieldConfig,
    /// Color palette and biome thresholds.
    pub palette: BiomePalette,
    /// If true, blends colors smoothly; if false, creates distinct biome bands.
    pub smooth_colors: bool,
}

impl Default for TerrainMeshConfig {
    fn default() -> Self {
        Self {
            width_cells: 64,
            depth_cells: 64,
            cell_size: 2.0,
            heightfield: HeightfieldConfig::default(),
            palette: BiomePalette::default(),
            smooth_colors: true,
        }
    }
}

/// Pure CPU raw mesh data buffer (zero GPU dependencies, instantly testable).
#[derive(Debug, Clone, PartialEq)]
pub struct RawMeshData {
    pub positions: Vec<[f32; 3]>,
    pub normals: Vec<[f32; 3]>,
    pub colors: Vec<[f32; 4]>,
    pub uvs: Vec<[f32; 2]>,
    pub indices: Vec<u32>,
}

impl RawMeshData {
    /// Converts CPU raw mesh buffers into a Bevy engine `Mesh`.
    pub fn into_bevy_mesh(self) -> Mesh {
        let mut mesh = Mesh::new(
            PrimitiveTopology::TriangleList,
            RenderAssetUsages::default(),
        );
        mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, self.positions);
        mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, self.normals);
        mesh.insert_attribute(Mesh::ATTRIBUTE_COLOR, self.colors);
        mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, self.uvs);
        mesh.insert_indices(Indices::U32(self.indices));
        mesh
    }
}

/// Terrain and water mesh builder.
pub struct TerrainBuilder;

impl TerrainBuilder {
    /// Builds the raw CPU mesh data for terrain based on the provided configuration.
    pub fn build_raw_terrain(config: &TerrainMeshConfig) -> RawMeshData {
        let hf = Heightfield::new(config.heightfield.clone());

        let num_verts_x = config.width_cells + 1;
        let num_verts_z = config.depth_cells + 1;
        let total_vertices = num_verts_x * num_verts_z;

        let mut positions = Vec::with_capacity(total_vertices);
        let mut normals = Vec::with_capacity(total_vertices);
        let mut colors = Vec::with_capacity(total_vertices);
        let mut uvs = Vec::with_capacity(total_vertices);

        let half_w = (config.width_cells as f32 * config.cell_size) * 0.5;
        let half_d = (config.depth_cells as f32 * config.cell_size) * 0.5;

        // 1. Generate Vertex Attributes
        for z_idx in 0..num_verts_z {
            let z = (z_idx as f32 * config.cell_size) - half_d;
            for x_idx in 0..num_verts_x {
                let x = (x_idx as f32 * config.cell_size) - half_w;

                let y = hf.sample_height(x, z);
                let normal = hf.sample_normal(x, z);

                let color = if config.smooth_colors {
                    config.palette.evaluate_smooth_color(y)
                } else {
                    config.palette.evaluate_color(y)
                };

                let uv = [
                    x_idx as f32 / config.width_cells as f32,
                    z_idx as f32 / config.depth_cells as f32,
                ];

                positions.push([x, y, z]);
                normals.push([normal.x, normal.y, normal.z]);
                colors.push(color);
                uvs.push(uv);
            }
        }

        // 2. Generate Triangle Indices (2 triangles = 6 indices per cell)
        let total_quads = config.width_cells * config.depth_cells;
        let mut indices = Vec::with_capacity(total_quads * 6);

        for z in 0..config.depth_cells {
            for x in 0..config.width_cells {
                let top_left = (z * num_verts_x + x) as u32;
                let top_right = top_left + 1;
                let bottom_left = ((z + 1) * num_verts_x + x) as u32;
                let bottom_right = bottom_left + 1;

                // Triangle 1 (CCW)
                indices.push(top_left);
                indices.push(bottom_left);
                indices.push(top_right);

                // Triangle 2 (CCW)
                indices.push(top_right);
                indices.push(bottom_left);
                indices.push(bottom_right);
            }
        }

        RawMeshData {
            positions,
            normals,
            colors,
            uvs,
            indices,
        }
    }

    /// Builds a ready-to-render Bevy `Mesh` for terrain.
    pub fn build_terrain_mesh(config: &TerrainMeshConfig) -> Mesh {
        Self::build_raw_terrain(config).into_bevy_mesh()
    }

    /// Builds a flat water plane raw mesh at specified water elevation.
    pub fn build_raw_water_plane(width: f32, depth: f32, water_level: f32) -> RawMeshData {
        let half_w = width * 0.5;
        let half_d = depth * 0.5;

        let positions = vec![
            [-half_w, water_level, -half_d],
            [half_w, water_level, -half_d],
            [half_w, water_level, half_d],
            [-half_w, water_level, half_d],
        ];

        let normals = vec![
            [0.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
        ];

        let colors = vec![
            [0.1, 0.35, 0.65, 0.75],
            [0.1, 0.35, 0.65, 0.75],
            [0.1, 0.35, 0.65, 0.75],
            [0.1, 0.35, 0.65, 0.75],
        ];

        let uvs = vec![
            [0.0, 0.0],
            [1.0, 0.0],
            [1.0, 1.0],
            [0.0, 1.0],
        ];

        let indices = vec![0, 3, 1, 1, 3, 2];

        RawMeshData {
            positions,
            normals,
            colors,
            uvs,
            indices,
        }
    }

    /// Builds a ready-to-render Bevy `Mesh` for the water plane.
    pub fn build_water_plane_mesh(width: f32, depth: f32, water_level: f32) -> Mesh {
        Self::build_raw_water_plane(width, depth, water_level).into_bevy_mesh()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_grid_mesh_dimensions() {
        let config = TerrainMeshConfig {
            width_cells: 10,
            depth_cells: 8,
            cell_size: 1.0,
            ..Default::default()
        };

        let raw = TerrainBuilder::build_raw_terrain(&config);

        let expected_verts = (10 + 1) * (8 + 1); // 99
        let expected_indices = 10 * 8 * 6; // 480

        assert_eq!(raw.positions.len(), expected_verts);
        assert_eq!(raw.normals.len(), expected_verts);
        assert_eq!(raw.colors.len(), expected_verts);
        assert_eq!(raw.uvs.len(), expected_verts);
        assert_eq!(raw.indices.len(), expected_indices);
    }

    #[test]
    fn test_water_plane_mesh() {
        let raw = TerrainBuilder::build_raw_water_plane(100.0, 100.0, 0.0);
        assert_eq!(raw.positions.len(), 4);
        assert_eq!(raw.indices.len(), 6);
        for pos in &raw.positions {
            assert_eq!(pos[1], 0.0, "Water plane must stay at water level");
        }
    }

    #[test]
    fn test_island_boundary_underwater() {
        let config = TerrainMeshConfig {
            width_cells: 32,
            depth_cells: 32,
            cell_size: 10.0, // large island
            ..Default::default()
        };
        let hf = Heightfield::new(config.heightfield);
        // At radius > 150 units, elevation must drop well below water level (0.0)
        let edge_height = hf.sample_height(160.0, 160.0);
        assert!(edge_height < 0.0, "Island perimeter must submerge into water: {}", edge_height);
    }
}
