//! Elevation biome classification and vertex color palettes.

use serde::{Deserialize, Serialize};

/// Biome palette mapping elevation heights to vertex colors.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BiomePalette {
    /// Water level threshold. Heights below this are underwater.
    pub water_level: f32,
    /// RGBA color for deep water bed.
    pub deep_water_color: [f32; 4],
    /// RGBA color for shallow coastal water bed.
    pub shallow_water_color: [f32; 4],
    /// RGBA color for sandy beaches immediately above water.
    pub beach_color: [f32; 4],
    /// RGBA color for lowland grass plains.
    pub grass_color: [f32; 4],
    /// RGBA color for highland pine forests.
    pub forest_color: [f32; 4],
    /// RGBA color for rocky mountain cliffs.
    pub rock_color: [f32; 4],
    /// RGBA color for high snow peaks.
    pub snow_color: [f32; 4],
}

impl Default for BiomePalette {
    fn default() -> Self {
        Self {
            water_level: 0.0,
            deep_water_color: [0.05, 0.17, 0.27, 1.0],      // Deep navy/abyss #0d2b45
            shallow_water_color: [0.12, 0.24, 0.34, 1.0],   // Coastal aqua #203c56
            beach_color: [0.91, 0.77, 0.42, 1.0],           // Warm gold sand #e9c46a
            grass_color: [0.16, 0.62, 0.56, 1.0],           // Meadow emerald #2a9d8f
            forest_color: [0.15, 0.27, 0.33, 1.0],          // Deep pine forest #264653
            rock_color: [0.42, 0.46, 0.49, 1.0],            // Mountain slate #6c757d
            snow_color: [0.97, 0.98, 0.98, 1.0],            // Glacial white #f8f9fa
        }
    }
}

impl BiomePalette {
    /// Evaluates the vertex color for a given elevation height.
    pub fn evaluate_color(&self, height: f32) -> [f32; 4] {
        if height < self.water_level - 2.5 {
            self.deep_water_color
        } else if height < self.water_level {
            self.shallow_water_color
        } else if height < self.water_level + 0.8 {
            self.beach_color
        } else if height < self.water_level + 4.5 {
            self.grass_color
        } else if height < self.water_level + 9.0 {
            self.forest_color
        } else if height < self.water_level + 14.0 {
            self.rock_color
        } else {
            self.snow_color
        }
    }

    /// Evaluates smooth interpolated color across elevation transitions.
    pub fn evaluate_smooth_color(&self, height: f32) -> [f32; 4] {
        // Linear blend between adjacent biome layers
        let (c1, c2, t) = if height < self.water_level - 2.5 {
            (self.deep_water_color, self.deep_water_color, 0.0)
        } else if height < self.water_level {
            let t = (height - (self.water_level - 2.5)) / 2.5;
            (self.deep_water_color, self.shallow_water_color, t)
        } else if height < self.water_level + 0.8 {
            let t = (height - self.water_level) / 0.8;
            (self.shallow_water_color, self.beach_color, t)
        } else if height < self.water_level + 4.5 {
            let t = (height - (self.water_level + 0.8)) / 3.7;
            (self.beach_color, self.grass_color, t)
        } else if height < self.water_level + 9.0 {
            let t = (height - (self.water_level + 4.5)) / 4.5;
            (self.grass_color, self.forest_color, t)
        } else if height < self.water_level + 14.0 {
            let t = (height - (self.water_level + 9.0)) / 5.0;
            (self.forest_color, self.rock_color, t)
        } else {
            let t = ((height - (self.water_level + 14.0)) / 4.0).clamp(0.0, 1.0);
            (self.rock_color, self.snow_color, t)
        };

        lerp_color(c1, c2, t.clamp(0.0, 1.0))
    }
}

#[inline(always)]
fn lerp_color(a: [f32; 4], b: [f32; 4], t: f32) -> [f32; 4] {
    [
        a[0] + (b[0] - a[0]) * t,
        a[1] + (b[1] - a[1]) * t,
        a[2] + (b[2] - a[2]) * t,
        a[3] + (b[3] - a[3]) * t,
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_water_threshold() {
        let palette = BiomePalette::default();
        let deep = palette.evaluate_color(-5.0);
        assert_eq!(deep, palette.deep_water_color);

        let beach = palette.evaluate_color(0.2);
        assert_eq!(beach, palette.beach_color);

        let snow = palette.evaluate_color(25.0);
        assert_eq!(snow, palette.snow_color);
    }
}
