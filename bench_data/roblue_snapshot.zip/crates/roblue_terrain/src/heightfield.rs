//! Heightfield generation, sampling, and analytical normal calculation.

use crate::noise::{NoiseConfig, SimplexNoise2D};
use bevy_math::Vec3;
use serde::{Deserialize, Serialize};

/// High-level configuration for procedural heightfield generation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct HeightfieldConfig {
    /// Noise generator settings.
    pub noise: NoiseConfig,
    /// Radial island falloff exponent (0.0 = infinite terrain, >0.0 = island surrounded by water).
    pub island_falloff: f32,
    /// Island radius before tapering to deep ocean.
    pub island_radius: f32,
}

impl Default for HeightfieldConfig {
    fn default() -> Self {
        Self {
            noise: NoiseConfig::default(),
            island_falloff: 2.0,
            island_radius: 120.0,
        }
    }
}

/// Evaluator for procedural terrain height and surface normals.
#[derive(Debug, Clone)]
pub struct Heightfield {
    config: HeightfieldConfig,
    noise: SimplexNoise2D,
}

impl Heightfield {
    /// Creates a new heightfield evaluator with the given configuration.
    pub fn new(config: HeightfieldConfig) -> Self {
        let noise = SimplexNoise2D::new(config.noise.seed);
        Self { config, noise }
    }

    /// Evaluates the ground elevation $Y$ at world coordinate $(X, Z)$.
    pub fn sample_height(&self, x: f32, z: f32) -> f32 {
        let raw_h = self.noise.sample_fbm(x, z, &self.config.noise);

        // Plateau / flattening transfer curve:
        // Broadens central elevations into expansive flat driving plains while retaining hills and valleys.
        let flat_h = if raw_h.abs() < 3.6 {
            raw_h * 0.32
        } else if raw_h >= 3.6 {
            3.6 * 0.32 + (raw_h - 3.6) * 0.72
        } else {
            -3.6 * 0.32 + (raw_h + 3.6) * 0.72
        };

        if self.config.island_falloff > 0.0 && self.config.island_radius > 0.0 {
            let dist = (x * x + z * z).sqrt();
            let norm_dist = (dist / self.config.island_radius).clamp(0.0, 2.0);
            let falloff = (1.0 - norm_dist.powf(self.config.island_falloff)).clamp(-1.0, 1.0);
            flat_h + (falloff * 8.0 - 4.0)
        } else {
            flat_h
        }
    }

    /// Computes the normalized surface normal vector at $(X, Z)$ using central finite differences.
    pub fn sample_normal(&self, x: f32, z: f32) -> Vec3 {
        const DELTA: f32 = 0.5;

        let h_l = self.sample_height(x - DELTA, z);
        let h_r = self.sample_height(x + DELTA, z);
        let h_d = self.sample_height(x, z - DELTA);
        let h_u = self.sample_height(x, z + DELTA);

        Vec3::new(h_l - h_r, 2.0 * DELTA, h_d - h_u).normalize()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normal_length() {
        let hf = Heightfield::new(HeightfieldConfig::default());
        for x in [-50.0, 0.0, 35.0] {
            for z in [-40.0, 10.0, 60.0] {
                let n = hf.sample_normal(x, z);
                assert!(
                    (n.length() - 1.0).abs() < 1e-4,
                    "Normal must be unit length: {:?}",
                    n
                );
                assert!(n.y > 0.0, "Terrain normal should point generally upwards: {:?}", n);
            }
        }
    }
}
