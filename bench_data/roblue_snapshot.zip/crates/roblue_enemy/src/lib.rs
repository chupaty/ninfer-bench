//! Bearded Orc sprite enemies, horde swarm movement, terrain line-of-sight, and click spawner.

pub mod components;
pub mod sprite;
pub mod systems;

pub use components::{Billboard, EnemyAssets, LineOfSight, OrcEnemy};
pub use sprite::{build_bearded_orc_image, build_orc_billboard_quad};
pub use systems::{
    enemy_billboard_system, enemy_los_system, enemy_player_collision_system,
    enemy_spawn_on_click_system, enemy_swarm_system, setup_enemy_assets,
};

use bevy_app::prelude::*;

/// Plugin registering orc assets, mass spawner, swarm movement, billboarding, and LOS systems.
pub struct RoblueEnemyPlugin;

impl Plugin for RoblueEnemyPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, setup_enemy_assets)
            .add_systems(
                Update,
                (
                    enemy_spawn_on_click_system,
                    enemy_swarm_system,
                    enemy_billboard_system,
                    enemy_los_system,
                    enemy_player_collision_system,
                ),
            );
    }
}
