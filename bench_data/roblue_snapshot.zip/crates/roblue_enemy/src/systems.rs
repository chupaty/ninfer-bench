//! Enemy swarm AI, terrain Line-of-Sight occlusion, billboarding, and mass spawning systems.

use crate::components::{Billboard, EnemyAssets, LineOfSight, OrcEnemy};
use crate::sprite::{build_bearded_orc_image, build_orc_billboard_quad};
use bevy_asset::Assets;
use bevy_camera::prelude::Visibility;
use bevy_camera::Camera;
use bevy_color::Color;
use bevy_ecs::prelude::*;
use bevy_image::Image;
use bevy_input::mouse::MouseButton;
use bevy_input::ButtonInput;
use bevy_math::{Quat, Vec2, Vec3};
use bevy_mesh::{Mesh, Mesh3d};
use bevy_pbr::{MeshMaterial3d, StandardMaterial};
use bevy_render::alpha::AlphaMode;
use bevy_time::Time;
use bevy_transform::components::Transform;
use rand::Rng;
use roblue_audio::{PlaySfxEvent, SfxKind};
use roblue_core::{EnemyMarker, FriendlyMarker, PlayerMarker};
use roblue_terrain::{Heightfield, TerrainMeshConfig};

/// Startup system that compiles the shared 64x64 orc mesh and material assets.
pub fn setup_enemy_assets(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut images: ResMut<Assets<Image>>,
) {
    let orc_image = images.add(build_bearded_orc_image());
    let orc_mesh = meshes.add(build_orc_billboard_quad(Vec2::new(1.8, 1.8)));

    // Unlit: true ensures the pixel art colors (green skin, ivory horns, red eyes, brown beard)
    // shine with full vibrant contrast without being darkened by 3D shadows.
    let orc_material = materials.add(StandardMaterial {
        base_color_texture: Some(orc_image),
        base_color: Color::WHITE,
        alpha_mode: AlphaMode::Mask(0.5),
        cull_mode: None,
        unlit: true,
        ..Default::default()
    });

    commands.insert_resource(EnemyAssets {
        orc_mesh,
        orc_material,
    });

    tracing::info!("Roblue EnemyAssets initialized with unlit 64x64 Bearded Orc sprite.");
}

/// Spawns 100 orcs scattered across the terrain map whenever the user RIGHT-CLICKS the mouse.
pub fn enemy_spawn_on_click_system(
    mut commands: Commands,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    enemy_assets: Option<Res<EnemyAssets>>,
    terrain_config: Res<TerrainMeshConfig>,
    player_query: Query<&Transform, With<PlayerMarker>>,
) {
    let Some(assets) = enemy_assets else {
        return;
    };

    // RIGHT-CLICK spawns 100 orcs!
    if mouse_buttons.just_pressed(MouseButton::Right) {
        let hf = Heightfield::new(terrain_config.heightfield.clone());
        let player_pos = player_query.iter().next().map(|t| t.translation).unwrap_or(Vec3::ZERO);

        let mut rng = rand::thread_rng();
        const SPAWN_COUNT: usize = 100;

        for _ in 0..SPAWN_COUNT {
            // Random angle and distance between 18.0 and 65.0 world units from the player
            let angle = rng.gen_range(0.0..std::f32::consts::TAU);
            let dist = rng.gen_range(18.0..65.0);

            let spawn_x = player_pos.x + angle.cos() * dist;
            let spawn_z = player_pos.z + angle.sin() * dist;
            let spawn_y = hf.sample_height(spawn_x, spawn_z);

            // Don't spawn under water
            if spawn_y < terrain_config.palette.water_level + 0.15 {
                continue;
            }

            commands.spawn((
                Mesh3d(assets.orc_mesh.clone()),
                MeshMaterial3d(assets.orc_material.clone()),
                Transform::from_xyz(spawn_x, spawn_y, spawn_z),
                Visibility::Inherited,
                OrcEnemy::default(),
                EnemyMarker,
                Billboard,
                LineOfSight::default(),
            ));
        }

        // Trigger spawn sound effect
        commands.trigger(
            PlaySfxEvent::new(SfxKind::Dash)
                .with_volume(0.4)
                .with_pitch(1.3),
        );

        tracing::info!("Right-click spawned 100 Bearded Orc enemies!");
    }
}

/// Swarm AI system: moves all orcs toward the nearest friendly unit (Player or Ally) while sticking to terrain elevation.
#[allow(clippy::type_complexity)]
pub fn enemy_swarm_system(
    time: Res<Time>,
    terrain_config: Res<TerrainMeshConfig>,
    friendly_query: Query<&Transform, (With<FriendlyMarker>, Without<EnemyMarker>)>,
    mut enemy_query: Query<(&mut Transform, &OrcEnemy), (With<EnemyMarker>, Without<FriendlyMarker>)>,
) {
    if friendly_query.is_empty() {
        return;
    }

    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    for (mut transform, enemy) in enemy_query.iter_mut() {
        let enemy_xz = Vec2::new(transform.translation.x, transform.translation.z);

        // Find closest friendly unit (Player or Ally)
        let mut nearest_target_xz: Option<Vec2> = None;
        let mut min_dist_sq = f32::MAX;

        for friendly_trans in friendly_query.iter() {
            let f_xz = Vec2::new(friendly_trans.translation.x, friendly_trans.translation.z);
            let dist_sq = (f_xz - enemy_xz).length_squared();
            if dist_sq < min_dist_sq {
                min_dist_sq = dist_sq;
                nearest_target_xz = Some(f_xz);
            }
        }

        if let Some(target_xz) = nearest_target_xz {
            let to_target = target_xz - enemy_xz;
            let dist = to_target.length();

            if dist > 0.01 {
                let move_dir = to_target / dist;
                transform.translation.x += move_dir.x * enemy.move_speed * dt;
                transform.translation.z += move_dir.y * enemy.move_speed * dt;
            }
        }

        // Snap elevation to ground surface
        let ground_y = hf.sample_height(transform.translation.x, transform.translation.z);
        transform.translation.y = ground_y;
    }
}

/// Billboard system: rotates all 2D sprite quads around Y to face the camera viewport.
pub fn enemy_billboard_system(
    camera_query: Query<&Transform, (With<Camera>, Without<Billboard>)>,
    mut billboard_query: Query<&mut Transform, With<Billboard>>,
) {
    let Some(camera_transform) = camera_query.iter().next() else {
        return;
    };

    let cam_pos = camera_transform.translation;

    for mut transform in billboard_query.iter_mut() {
        let to_cam = Vec2::new(
            cam_pos.x - transform.translation.x,
            cam_pos.z - transform.translation.z,
        );

        if to_cam.length_squared() > 0.01 {
            let angle = (-to_cam.x).atan2(-to_cam.y);
            transform.rotation = Quat::from_rotation_y(angle);
        }
    }
}

/// Terrain Line-of-Sight (LOS) occlusion system: hides orcs that are occluded by hills/ridges.
#[allow(clippy::type_complexity)]
pub fn enemy_los_system(
    terrain_config: Res<TerrainMeshConfig>,
    player_query: Query<&Transform, With<PlayerMarker>>,
    mut enemy_query: Query<(&Transform, &LineOfSight, &mut Visibility), (With<EnemyMarker>, Without<PlayerMarker>)>,
) {
    let Some(player_transform) = player_query.iter().next() else {
        return;
    };

    let player_eye = player_transform.translation + Vec3::new(0.0, 1.2, 0.0);
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    const RAY_STEPS: usize = 8;

    for (enemy_transform, los, mut visibility) in enemy_query.iter_mut() {
        let enemy_center = enemy_transform.translation + Vec3::new(0.0, 1.0, 0.0);
        let dist = (player_eye - enemy_center).length();

        if dist > los.max_range {
            *visibility = Visibility::Hidden;
            continue;
        }

        let mut is_occluded = false;

        for step in 1..RAY_STEPS {
            let t = step as f32 / RAY_STEPS as f32;
            let sample_x = player_eye.x + (enemy_center.x - player_eye.x) * t;
            let sample_z = player_eye.z + (enemy_center.z - player_eye.z) * t;
            let ray_y = player_eye.y + (enemy_center.y - player_eye.y) * t;

            let terrain_y = hf.sample_height(sample_x, sample_z);

            if terrain_y > ray_y + 0.15 {
                is_occluded = true;
                break;
            }
        }

        *visibility = if is_occluded {
            Visibility::Hidden
        } else {
            Visibility::Inherited
        };
    }
}

/// Contact Collision system: when an orc touches any friendly unit (Player or Ally), the orc "dies" and despawns.
#[allow(clippy::type_complexity)]
pub fn enemy_player_collision_system(
    mut commands: Commands,
    friendly_query: Query<&Transform, (With<FriendlyMarker>, Without<EnemyMarker>)>,
    enemy_query: Query<(Entity, &Transform, &OrcEnemy), (With<EnemyMarker>, Without<FriendlyMarker>)>,
) {
    const FRIENDLY_HITBOX_RADIUS: f32 = 1.45;

    for (enemy_entity, enemy_transform, enemy) in enemy_query.iter() {
        let enemy_xz = Vec2::new(enemy_transform.translation.x, enemy_transform.translation.z);

        for friendly_trans in friendly_query.iter() {
            let f_xz = Vec2::new(friendly_trans.translation.x, friendly_trans.translation.z);
            let dist = (f_xz - enemy_xz).length();

            if dist < (FRIENDLY_HITBOX_RADIUS + enemy.hitbox_radius) {
                // Orc touches friendly -> Orc dies!
                commands.entity(enemy_entity).try_despawn();

                commands.trigger(
                    PlaySfxEvent::new(SfxKind::ActionClick)
                        .with_volume(0.8)
                        .with_pitch(0.85),
                );

                tracing::debug!("Orc touched friendly unit and died!");
                break;
            }
        }
    }
}
