//! Enemy components and spawner resource definitions.

use bevy_asset::Handle;
use bevy_ecs::prelude::*;
use bevy_mesh::Mesh;
use bevy_pbr::StandardMaterial;
use serde::{Deserialize, Serialize};

/// Main enemy component for the Bearded Orc.
#[derive(Component, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OrcEnemy {
    /// Movement speed across the terrain (units per second).
    pub move_speed: f32,
    /// Collision contact hitbox radius.
    pub hitbox_radius: f32,
    /// Current health points (dies after taking 3 shots).
    pub health: f32,
    /// Maximum health points.
    pub max_health: f32,
}

impl Default for OrcEnemy {
    fn default() -> Self {
        Self {
            move_speed: 7.5,
            hitbox_radius: 0.6,
            health: 3.0,
            max_health: 3.0,
        }
    }
}

/// Marker component for entities that rotate their orientation to face the active camera.
#[derive(Component, Debug, Default, Clone, Copy)]
pub struct Billboard;

/// Component tracking whether the entity has line-of-sight to the player.
#[derive(Component, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LineOfSight {
    /// Whether the entity is currently visible to the player pill.
    pub is_visible: bool,
    /// Maximum vision range before falling into fog / hidden.
    pub max_range: f32,
}

impl Default for LineOfSight {
    fn default() -> Self {
        Self {
            is_visible: true,
            max_range: 55.0,
        }
    }
}

/// Global resource holding pre-loaded shared mesh and material handles for fast mass instantiation.
#[derive(Resource, Debug, Clone)]
pub struct EnemyAssets {
    pub orc_mesh: Handle<Mesh>,
    pub orc_material: Handle<StandardMaterial>,
}
