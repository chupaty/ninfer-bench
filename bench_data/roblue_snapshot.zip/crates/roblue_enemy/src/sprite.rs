//! Procedural 64x64 pixel-art sprite generator for the Bearded Orc.

use bevy_asset::RenderAssetUsages;
use bevy_image::{Image, ImageSampler, ImageSamplerDescriptor};
use bevy_math::Vec2;
use bevy_mesh::{Indices, Mesh, PrimitiveTopology};
use bevy_render::render_resource::{Extent3d, TextureDimension, TextureFormat};

/// Width and height of the orc sprite texture in pixels.
pub const ORC_SPRITE_SIZE: u32 = 64;

/// Generates a 64x64 pixel-art texture buffer for the Bearded Orc.
pub fn generate_bearded_orc_pixel_art() -> Vec<u8> {
    let mut pixels = vec![0u8; (ORC_SPRITE_SIZE * ORC_SPRITE_SIZE * 4) as usize];

    let set_pixel = |pixels: &mut [u8], x: i32, y: i32, rgba: [u8; 4]| {
        if (0..ORC_SPRITE_SIZE as i32).contains(&x) && (0..ORC_SPRITE_SIZE as i32).contains(&y) {
            let idx = ((y as usize * ORC_SPRITE_SIZE as usize) + x as usize) * 4;
            pixels[idx] = rgba[0];
            pixels[idx + 1] = rgba[1];
            pixels[idx + 2] = rgba[2];
            pixels[idx + 3] = rgba[3];
        }
    };

    // Color Palette
    const HORN_IVORY: [u8; 4] = [238, 228, 205, 255];
    const HORN_SHADOW: [u8; 4] = [180, 168, 140, 255];
    const HELMET_IRON: [u8; 4] = [95, 105, 115, 255];
    const HELMET_HIGHLIGHT: [u8; 4] = [155, 165, 175, 255];
    const HELMET_DARK: [u8; 4] = [45, 50, 55, 255];
    const ORC_SKIN: [u8; 4] = [67, 137, 69, 255];
    const ORC_SKIN_SHADOW: [u8; 4] = [45, 98, 48, 255];
    const EYE_RED: [u8; 4] = [255, 34, 34, 255];
    const TUSK_WHITE: [u8; 4] = [245, 245, 230, 255];
    const BEARD_BROWN: [u8; 4] = [96, 56, 19, 255];
    const BEARD_HIGHLIGHT: [u8; 4] = [138, 82, 35, 255];
    const BEARD_DARK: [u8; 4] = [58, 32, 10, 255];
    const GOLD_BAND: [u8; 4] = [225, 175, 45, 255];
    const ARMOR_LEATHER: [u8; 4] = [61, 35, 20, 255];
    const OUTLINE: [u8; 4] = [20, 20, 20, 255];

    // 1. Shoulders & Armor (Y: 46..63)
    for y in 46i32..64i32 {
        for x in 14i32..50i32 {
            let dx = (x - 32i32).abs();
            if dx < 22 - (63 - y) / 3 {
                set_pixel(&mut pixels, x, y, ARMOR_LEATHER);
            }
        }
    }

    // 2. Head & Skin (Y: 26..44)
    for y in 26i32..45i32 {
        for x in 21i32..43i32 {
            let dx = (x - 32i32).abs();
            if dx <= 10 {
                let col = if dx > 7 || y > 38 { ORC_SKIN_SHADOW } else { ORC_SKIN };
                set_pixel(&mut pixels, x, y, col);
            }
        }
    }

    // 3. Iron Helmet (Y: 14..28)
    for y in 14i32..28i32 {
        for x in 19i32..45i32 {
            let dx = (x - 32i32).abs();
            let max_w = if y < 18 { 6 + (y - 14) * 2 } else { 11 };
            if dx <= max_w {
                let col = if x == 32 {
                    HELMET_HIGHLIGHT
                } else if dx > 8 {
                    HELMET_DARK
                } else {
                    HELMET_IRON
                };
                set_pixel(&mut pixels, x, y, col);
            }
        }
    }

    // 4. Curved Ivory Horns
    // Left horn
    for i in 0i32..14i32 {
        let hx = 22 - i;
        let hy = 20 - (i * i) / 14;
        set_pixel(&mut pixels, hx, hy, HORN_IVORY);
        set_pixel(&mut pixels, hx, hy + 1, HORN_SHADOW);
        set_pixel(&mut pixels, hx, hy - 1, OUTLINE);
    }
    // Right horn
    for i in 0i32..14i32 {
        let hx = 41 + i;
        let hy = 20 - (i * i) / 14;
        set_pixel(&mut pixels, hx, hy, HORN_IVORY);
        set_pixel(&mut pixels, hx, hy + 1, HORN_SHADOW);
        set_pixel(&mut pixels, hx, hy - 1, OUTLINE);
    }

    // 5. Red Glowing Eyes & Brow
    set_pixel(&mut pixels, 26, 32, OUTLINE);
    set_pixel(&mut pixels, 27, 32, OUTLINE);
    set_pixel(&mut pixels, 26, 33, EYE_RED);
    set_pixel(&mut pixels, 27, 33, EYE_RED);

    set_pixel(&mut pixels, 36, 32, OUTLINE);
    set_pixel(&mut pixels, 37, 32, OUTLINE);
    set_pixel(&mut pixels, 36, 33, EYE_RED);
    set_pixel(&mut pixels, 37, 33, EYE_RED);

    // 6. Huge Bushy Braided Beard (Y: 38..62)
    for y in 38i32..63i32 {
        let spread = if y < 50 { y - 38 } else { 12 - (y - 50) / 2 };
        for x in (32 - spread)..(32 + spread + 1) {
            let dx = (x - 32i32).abs();
            let col = if dx % 3 == 0 {
                BEARD_HIGHLIGHT
            } else if dx > spread - 2 {
                BEARD_DARK
            } else {
                BEARD_BROWN
            };
            set_pixel(&mut pixels, x, y, col);
        }
    }

    // Beard Gold Clasp Ring at Y: 52
    for x in 28i32..37i32 {
        set_pixel(&mut pixels, x, 52, GOLD_BAND);
        set_pixel(&mut pixels, x, 53, GOLD_BAND);
    }

    // 7. Tusks (Pointing Upwards from lower jaw)
    set_pixel(&mut pixels, 25, 41, TUSK_WHITE);
    set_pixel(&mut pixels, 25, 40, TUSK_WHITE);
    set_pixel(&mut pixels, 25, 39, TUSK_WHITE);

    set_pixel(&mut pixels, 38, 41, TUSK_WHITE);
    set_pixel(&mut pixels, 38, 40, TUSK_WHITE);
    set_pixel(&mut pixels, 38, 39, TUSK_WHITE);

    // 8. Dark Silhouette Outline
    let copy = pixels.clone();
    for y in 1i32..63i32 {
        for x in 1i32..63i32 {
            let idx = ((y * ORC_SPRITE_SIZE as i32) + x) as usize * 4;
            if copy[idx + 3] == 0 {
                let has_opaque_neighbor = [
                    (-1, 0), (1, 0), (0, -1), (0, 1)
                ].iter().any(|(dx, dy)| {
                    let n_idx = (((y + dy) * ORC_SPRITE_SIZE as i32) + (x + dx)) as usize * 4;
                    copy[n_idx + 3] > 0
                });

                if has_opaque_neighbor {
                    set_pixel(&mut pixels, x, y, OUTLINE);
                }
            }
        }
    }

    pixels
}

/// Builds a Bevy `Image` asset containing the bearded orc texture with nearest-neighbor pixel filter.
pub fn build_bearded_orc_image() -> Image {
    let raw_data = generate_bearded_orc_pixel_art();
    let size = Extent3d {
        width: ORC_SPRITE_SIZE,
        height: ORC_SPRITE_SIZE,
        depth_or_array_layers: 1,
    };

    let mut image = Image::new(
        size,
        TextureDimension::D2,
        raw_data,
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::default(),
    );

    image.sampler = ImageSampler::Descriptor(ImageSamplerDescriptor {
        mag_filter: bevy_image::ImageFilterMode::Nearest,
        min_filter: bevy_image::ImageFilterMode::Nearest,
        ..Default::default()
    });

    image
}

/// Creates a vertical billboard quad mesh with the base anchored at Y=0.0 (ground surface).
pub fn build_orc_billboard_quad(size: Vec2) -> Mesh {
    let half_w = size.x * 0.5;
    let height = size.y;

    let positions = vec![
        [-half_w, 0.0, 0.0],
        [half_w, 0.0, 0.0],
        [half_w, height, 0.0],
        [-half_w, height, 0.0],
    ];

    let normals = vec![
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
    ];

    let uvs = vec![
        [0.0, 1.0],
        [1.0, 1.0],
        [1.0, 0.0],
        [0.0, 0.0],
    ];

    let indices = vec![0, 1, 2, 0, 2, 3];

    let mut mesh = Mesh::new(
        PrimitiveTopology::TriangleList,
        RenderAssetUsages::default(),
    );
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_indices(Indices::U32(indices));

    mesh
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_orc_texture_dimensions() {
        let pixels = generate_bearded_orc_pixel_art();
        assert_eq!(pixels.len(), (64 * 64 * 4) as usize);

        let center_idx = (32 * 64 + 32) * 4;
        assert!(pixels[center_idx + 3] > 0, "Orc center must be opaque");
    }

    #[test]
    fn test_billboard_quad() {
        let mesh = build_orc_billboard_quad(Vec2::new(1.8, 1.8));
        assert_eq!(mesh.count_vertices(), 4);
    }
}
