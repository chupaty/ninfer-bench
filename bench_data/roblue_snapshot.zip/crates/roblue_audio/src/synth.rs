//! Procedural in-memory WAV audio synthesizer for instant sound effects.

/// Generates a valid RIFF/WAVE 16-bit Mono PCM audio byte buffer.
pub fn generate_wav_bytes(samples: &[f32], sample_rate: u32) -> Vec<u8> {
    let num_samples = samples.len() as u32;
    let byte_rate = sample_rate * 2; // 16-bit mono = 2 bytes per sample
    let data_size = num_samples * 2;
    let file_size = 36 + data_size;

    let mut bytes = Vec::with_capacity(44 + data_size as usize);

    // RIFF Header
    bytes.extend_from_slice(b"RIFF");
    bytes.extend_from_slice(&file_size.to_le_bytes());
    bytes.extend_from_slice(b"WAVE");

    // "fmt " Subchunk
    bytes.extend_from_slice(b"fmt ");
    bytes.extend_from_slice(&16u32.to_le_bytes()); // Subchunk1Size = 16 for PCM
    bytes.extend_from_slice(&1u16.to_le_bytes());  // AudioFormat = 1 (PCM)
    bytes.extend_from_slice(&1u16.to_le_bytes());  // NumChannels = 1 (Mono)
    bytes.extend_from_slice(&sample_rate.to_le_bytes()); // SampleRate
    bytes.extend_from_slice(&byte_rate.to_le_bytes());   // ByteRate
    bytes.extend_from_slice(&2u16.to_le_bytes());  // BlockAlign = 2
    bytes.extend_from_slice(&16u16.to_le_bytes()); // BitsPerSample = 16

    // "data" Subchunk
    bytes.extend_from_slice(b"data");
    bytes.extend_from_slice(&data_size.to_le_bytes());

    for &sample in samples {
        let clamped = sample.clamp(-1.0, 1.0);
        let pcm = (clamped * 32767.0) as i16;
        bytes.extend_from_slice(&pcm.to_le_bytes());
    }

    bytes
}

/// Synthesizes a short, punchy footstep tap sound (65ms).
pub fn synth_footstep_wav() -> Vec<u8> {
    const SAMPLE_RATE: u32 = 44100;
    const DURATION_SECS: f32 = 0.065;
    let total_samples = (SAMPLE_RATE as f32 * DURATION_SECS) as usize;

    let mut samples = Vec::with_capacity(total_samples);
    let mut phase = 0.0f32;

    for i in 0..total_samples {
        let t = i as f32 / SAMPLE_RATE as f32;
        let progress = t / DURATION_SECS;

        // Pitch drops from 170Hz down to 55Hz
        let freq = 170.0 * (1.0 - progress * 0.7);
        phase += freq * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;

        // Exponential decay envelope with fast attack
        let attack = (t / 0.005).min(1.0);
        let decay = (-progress * 6.5).exp();
        let amp = attack * decay;

        let sample = phase.sin() * amp * 0.6;
        samples.push(sample);
    }

    generate_wav_bytes(&samples, SAMPLE_RATE)
}

/// Synthesizes a crisp, bright sci-fi action click sound (110ms).
pub fn synth_action_click_wav() -> Vec<u8> {
    const SAMPLE_RATE: u32 = 44100;
    const DURATION_SECS: f32 = 0.11;
    let total_samples = (SAMPLE_RATE as f32 * DURATION_SECS) as usize;

    let mut samples = Vec::with_capacity(total_samples);
    let mut phase1 = 0.0f32;
    let mut phase2 = 0.0f32;

    for i in 0..total_samples {
        let t = i as f32 / SAMPLE_RATE as f32;
        let progress = t / DURATION_SECS;

        // Frequency sweep from 620Hz to 980Hz
        let freq1 = 620.0 + progress * 360.0;
        let freq2 = freq1 * 1.5; // Harmonic overtone

        phase1 += freq1 * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;
        phase2 += freq2 * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;

        let attack = (t / 0.003).min(1.0);
        let decay = (-progress * 5.0).exp();
        let amp = attack * decay;

        let sample = (phase1.sin() * 0.7 + phase2.sin() * 0.3) * amp * 0.7;
        samples.push(sample);
    }

    generate_wav_bytes(&samples, SAMPLE_RATE)
}

/// Synthesizes a dash/whoosh sound effect (160ms).
pub fn synth_dash_wav() -> Vec<u8> {
    const SAMPLE_RATE: u32 = 44100;
    const DURATION_SECS: f32 = 0.16;
    let total_samples = (SAMPLE_RATE as f32 * DURATION_SECS) as usize;

    let mut samples = Vec::with_capacity(total_samples);
    let mut phase = 0.0f32;

    for i in 0..total_samples {
        let t = i as f32 / SAMPLE_RATE as f32;
        let progress = t / DURATION_SECS;

        let freq = 340.0 * (1.0 - progress * 0.6);
        phase += freq * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;

        let envelope = (std::f32::consts::PI * progress).sin();
        let sample = phase.sin() * envelope * 0.6;
        samples.push(sample);
    }

    generate_wav_bytes(&samples, SAMPLE_RATE)
}

/// Synthesizes an ascending 4-note chime for level ups (320ms).
pub fn synth_levelup_wav() -> Vec<u8> {
    const SAMPLE_RATE: u32 = 44100;
    const DURATION_SECS: f32 = 0.32;
    let total_samples = (SAMPLE_RATE as f32 * DURATION_SECS) as usize;

    let notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    let note_len = total_samples / notes.len();

    let mut samples = Vec::with_capacity(total_samples);
    let mut phase = 0.0f32;

    for &note_freq in notes.iter() {
        for i in 0..note_len {
            let note_prog = i as f32 / note_len as f32;

            phase += note_freq * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;
            let envelope = (-note_prog * 3.5).exp();
            let sample = phase.sin() * envelope * 0.5;
            samples.push(sample);
        }
    }

    generate_wav_bytes(&samples, SAMPLE_RATE)
}

/// Synthesizes a punchy, sci-fi "puchu" sound effect (240ms) with a distinctive pitch-drop swoop and sub-bass thump.
pub fn synth_puchu_wav() -> Vec<u8> {
    const SAMPLE_RATE: u32 = 44100;
    const DURATION_SECS: f32 = 0.24;
    let total_samples = (SAMPLE_RATE as f32 * DURATION_SECS) as usize;

    let mut samples = Vec::with_capacity(total_samples);
    let mut phase_main = 0.0f32;
    let mut phase_fm = 0.0f32;

    for i in 0..total_samples {
        let t = i as f32 / SAMPLE_RATE as f32;
        let progress = t / DURATION_SECS;

        // "Pu-chu" pitch contour:
        // Starts with a snappy pitch sweep at 620Hz, rapidly swooping down to 140Hz and settling to 65Hz
        let freq_main = 65.0 + 555.0 * (1.0 - progress).powf(2.4);
        let freq_fm = freq_main * 1.5;

        phase_fm += freq_fm * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;
        let fm_mod = phase_fm.sin() * 0.35 * (1.0 - progress);

        phase_main += (freq_main * (1.0 + fm_mod)) * 2.0 * std::f32::consts::PI / SAMPLE_RATE as f32;

        // Envelope: instant 3ms attack, followed by resonant punch and warm exponential decay
        let attack = (t / 0.003).min(1.0);
        let decay = (-progress * 4.2).exp();
        let amp = attack * decay;

        // Mix fundamental sine wave with a soft second harmonic and slight warmth
        let raw_sample = (phase_main.sin() * 0.75 + (phase_main * 2.0).sin() * 0.25) * amp;
        // Soft saturation for analog warmth
        let sample = (raw_sample * 1.2).tanh() * 0.85;

        samples.push(sample);
    }

    generate_wav_bytes(&samples, SAMPLE_RATE)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wav_header() {
        let wav = synth_footstep_wav();
        assert!(wav.len() > 44);
        assert_eq!(&wav[0..4], b"RIFF");
        assert_eq!(&wav[8..12], b"WAVE");
        assert_eq!(&wav[12..16], b"fmt ");
        assert_eq!(&wav[36..40], b"data");
    }

    #[test]
    fn test_puchu_wav_generation() {
        let wav = synth_puchu_wav();
        assert!(wav.len() > 44);
        assert_eq!(&wav[0..4], b"RIFF");
        assert_eq!(&wav[8..12], b"WAVE");
    }
}
