//! Audio subsystem, procedural audio synthesis, and sound effect event pipeline for Roblue.

pub mod synth;

use std::sync::Arc;
use bevy_app::prelude::*;
use bevy_asset::{Assets, Handle};
use bevy_audio::{AudioPlayer, AudioSource, PlaybackSettings, Volume};
use bevy_ecs::event::Event;
use bevy_ecs::observer::On;
use bevy_ecs::prelude::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Identifiers for in-game sound effect triggers.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum SfxKind {
    Footstep,
    ActionClick,
    Dash,
    LevelUp,
    Puchu,
}

/// Event dispatched to play a sound effect via Bevy Observers.
#[derive(Event, Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct PlaySfxEvent {
    pub sound: SfxKind,
    pub volume: f32,
    pub pitch: f32,
}

impl PlaySfxEvent {
    pub fn new(sound: SfxKind) -> Self {
        Self {
            sound,
            volume: 0.5,
            pitch: 1.0,
        }
    }

    pub fn with_volume(mut self, volume: f32) -> Self {
        self.volume = volume;
        self
    }

    pub fn with_pitch(mut self, pitch: f32) -> Self {
        self.pitch = pitch;
        self
    }
}

/// Sound effect asset handle registry.
#[derive(Resource, Default, Debug)]
pub struct SfxLibrary {
    pub handles: HashMap<SfxKind, Handle<AudioSource>>,
}

/// Global audio settings and volume control.
#[derive(Resource, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AudioSettings {
    pub master_volume: f32,
    pub sfx_volume: f32,
    pub music_volume: f32,
    pub muted: bool,
}

impl Default for AudioSettings {
    fn default() -> Self {
        Self {
            master_volume: 1.0,
            sfx_volume: 0.85,
            music_volume: 0.7,
            muted: false,
        }
    }
}

/// Audio plugin initializing audio settings, synthesizer library, and observers.
pub struct RoblueAudioPlugin;

impl Plugin for RoblueAudioPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<AudioSettings>()
            .init_resource::<SfxLibrary>()
            .add_systems(Startup, setup_sfx_library)
            .add_observer(handle_sfx_trigger);
    }
}

/// Startup system that generates procedural audio waveforms and loads them into memory.
pub fn setup_sfx_library(
    mut audio_sources: ResMut<Assets<AudioSource>>,
    mut sfx_lib: ResMut<SfxLibrary>,
) {
    let footstep_wav = synth::synth_footstep_wav();
    let footstep_handle = audio_sources.add(AudioSource {
        bytes: Arc::from(footstep_wav.into_boxed_slice()),
    });

    let click_wav = synth::synth_action_click_wav();
    let click_handle = audio_sources.add(AudioSource {
        bytes: Arc::from(click_wav.into_boxed_slice()),
    });

    let dash_wav = synth::synth_dash_wav();
    let dash_handle = audio_sources.add(AudioSource {
        bytes: Arc::from(dash_wav.into_boxed_slice()),
    });

    let levelup_wav = synth::synth_levelup_wav();
    let levelup_handle = audio_sources.add(AudioSource {
        bytes: Arc::from(levelup_wav.into_boxed_slice()),
    });

    let puchu_wav = synth::synth_puchu_wav();
    let puchu_handle = audio_sources.add(AudioSource {
        bytes: Arc::from(puchu_wav.into_boxed_slice()),
    });

    sfx_lib.handles.insert(SfxKind::Footstep, footstep_handle);
    sfx_lib.handles.insert(SfxKind::ActionClick, click_handle);
    sfx_lib.handles.insert(SfxKind::Dash, dash_handle);
    sfx_lib.handles.insert(SfxKind::LevelUp, levelup_handle);
    sfx_lib.handles.insert(SfxKind::Puchu, puchu_handle);

    tracing::info!("Roblue SfxLibrary loaded with procedural synthesized audio.");
}

/// Observer system that spawns an AudioPlayer entity with dynamic volume and pitch on each event trigger.
pub fn handle_sfx_trigger(
    trigger: On<PlaySfxEvent>,
    mut commands: Commands,
    sfx_lib: Res<SfxLibrary>,
    settings: Res<AudioSettings>,
) {
    if settings.muted {
        return;
    }

    let Some(handle) = sfx_lib.handles.get(&trigger.sound) else {
        return;
    };

    let effective_volume = (trigger.volume * settings.sfx_volume * settings.master_volume).clamp(0.0, 2.0);

    commands.spawn((
        AudioPlayer::new(handle.clone()),
        PlaybackSettings::DESPAWN
            .with_volume(Volume::Linear(effective_volume))
            .with_speed(trigger.pitch),
    ));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sfx_event_builder() {
        let ev = PlaySfxEvent::new(SfxKind::Footstep)
            .with_volume(0.3)
            .with_pitch(1.2);
        assert_eq!(ev.sound, SfxKind::Footstep);
        assert_eq!(ev.volume, 0.3);
        assert_eq!(ev.pitch, 1.2);
    }
}
