//! Components and data models for modular stackable vehicles, sockets, and auto-turrets.

use bevy_asset::Handle;
use bevy_ecs::prelude::*;
use bevy_math::{Vec2, Vec3};
use bevy_mesh::Mesh;
use bevy_pbr::StandardMaterial;
use bevy_time::{Timer, TimerMode};
use serde::{Deserialize, Serialize};

/// Driving dynamics with momentum, terrain normal adherence, and slope-dependent speed scaling.
#[derive(Component, Debug, Clone)]
pub struct VehicleChassis {
    /// Current velocity vector in world XZ ground plane.
    pub velocity: Vec2,
    /// Acceleration force per second when input is held.
    pub acceleration: f32,
    /// Velocity drag factor per second (linear friction).
    pub drag: f32,
    /// Base maximum driving speed on level ground.
    pub base_max_speed: f32,
    /// Current effective top driving speed (dynamically scaled by terrain slope).
    pub max_speed: f32,
    /// Current steering yaw angle in radians.
    pub facing_angle: f32,
    /// Steering turn rate in radians per second.
    pub turn_speed: f32,
    /// Sensitivity to uphill slope resistance (0.0 = unaffected, 1.0 = heavy drag).
    pub slope_penalty: f32,
    /// Maximum climbable slope angle in radians before maximum deceleration (~45 deg = 0.78 rad).
    pub max_climb_angle: f32,
    /// Downhill acceleration and speed boost multiplier (e.g. 0.30 = +30% top speed).
    pub downhill_boost: f32,
}

impl Default for VehicleChassis {
    fn default() -> Self {
        Self {
            velocity: Vec2::ZERO,
            acceleration: 38.0,
            drag: 3.2,
            base_max_speed: 22.0,
            max_speed: 22.0,
            facing_angle: 0.0,
            turn_speed: 2.6, // Smooth, non-severe steering response
            slope_penalty: 0.65,
            max_climb_angle: 0.785, // 45 degrees
            downhill_boost: 0.30,
        }
    }
}

/// Socket compatibility classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum SocketKind {
    /// Mount socket for structural vehicle components (Big Turret, Small Turret).
    Mount,
    /// Gun socket for direct weapon attachments (Big Gun, Small Gun).
    Gun,
}

/// Type of modular vehicle component.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ComponentKind {
    BigTurret,
    SmallTurret,
    BigGun,
    SmallGun,
}

impl ComponentKind {
    /// Returns the socket classification required to mount this component.
    #[must_use]
    pub fn required_socket_kind(&self) -> SocketKind {
        match self {
            ComponentKind::BigTurret | ComponentKind::SmallTurret => SocketKind::Mount,
            ComponentKind::BigGun | ComponentKind::SmallGun => SocketKind::Gun,
        }
    }

    /// Display label for notifications and debugging.
    #[must_use]
    pub fn name(&self) -> &'static str {
        match self {
            ComponentKind::BigTurret => "Big Turret",
            ComponentKind::SmallTurret => "Small Turret",
            ComponentKind::BigGun => "Heavy Cannon",
            ComponentKind::SmallGun => "Twin Autocannon",
        }
    }
}

/// Individual socket on a vehicle component or chassis.
#[derive(Debug, Clone)]
pub struct Socket {
    pub id: usize,
    pub kind: SocketKind,
    pub local_pos: Vec3,
    pub local_dir: Vec3,
    pub extent_angle: f32,
    pub occupied: Option<Entity>,
}

/// Container component holding the open and occupied sockets of a vehicle part.
#[derive(Component, Debug, Clone, Default)]
pub struct Sockets {
    pub list: Vec<Socket>,
}

impl Sockets {
    /// Constructs a container with a pre-configured list of sockets.
    pub fn new(list: Vec<Socket>) -> Self {
        Self { list }
    }

    /// Finds the first available socket matching the required kind.
    #[must_use]
    pub fn find_available_socket(&self, kind: SocketKind) -> Option<(usize, Vec3, Vec3, f32)> {
        for socket in &self.list {
            if socket.kind == kind && socket.occupied.is_none() {
                return Some((socket.id, socket.local_pos, socket.local_dir, socket.extent_angle));
            }
        }
        None
    }

    /// Marks a specific socket as occupied by the given child entity.
    pub fn occupy_socket(&mut self, socket_id: usize, child: Entity) -> bool {
        if let Some(socket) = self.list.iter_mut().find(|s| s.id == socket_id && s.occupied.is_none()) {
            socket.occupied = Some(child);
            return true;
        }
        false
    }
}

/// Dynamic yaw tracking for turret platforms.
/// Dynamic yaw tracking for turret platforms.
#[derive(Component, Debug, Clone)]
pub struct TurretTracker {
    pub kind: ComponentKind,
    pub tracking_speed: f32,
    pub current_yaw: f32,
    /// Desired azimuth target direction in world space (supplied by mounted Big Gun or nearest enemy).
    pub desired_world_azimuth: Option<Vec3>,
}

impl TurretTracker {
    pub fn new(kind: ComponentKind, speed_rad_per_sec: f32) -> Self {
        Self {
            kind,
            tracking_speed: speed_rad_per_sec,
            current_yaw: 0.0,
            desired_world_azimuth: None,
        }
    }
}

/// Kinematic auto-targeting and continuous fire controller for guns.
#[derive(Component, Debug, Clone)]
pub struct GunAutoShooter {
    pub kind: ComponentKind,
    pub tracking_speed: f32,
    /// Current vertical elevation pitch in radians (relative to mount frame).
    pub current_pitch: f32,
    /// Current horizontal gimbal yaw in radians (used by Small Gun).
    pub current_yaw: f32,
    /// Minimum vertical pitch in radians (depression).
    pub min_pitch: f32,
    /// Maximum vertical pitch in radians (elevation).
    pub max_pitch: f32,
    /// Conical gimbal half-angle limit in radians (for Small Gun).
    pub cone_angle: f32,
    pub rest_dir: Vec3,
    pub fire_timer: Timer,
    pub damage: f32,
    pub projectile_speed: f32,
    pub range: f32,
    pub aim_tolerance: f32,
    pub target_entity: Option<Entity>,
    /// Whether the gun is aimed on target within tolerance.
    pub is_on_target: bool,
}

impl GunAutoShooter {
    /// Creates a Heavy Big Gun: Elevation pitch only (up/down), 0 relative yaw, delegates azimuth to Big Turret.
    pub fn big_gun(rest_dir: Vec3) -> Self {
        Self {
            kind: ComponentKind::BigGun,
            tracking_speed: 3.5,
            current_pitch: 0.0,
            current_yaw: 0.0,
            min_pitch: -0.85, // -48.7 degrees depression (supports high-altitude/chin shooting down)
            max_pitch: 0.65,  // +37.2 degrees elevation
            cone_angle: 0.0,  // Zero relative yaw: slaved to parent turret
            rest_dir,
            fire_timer: Timer::from_seconds(1.80, TimerMode::Repeating),
            damage: 3.0,
            projectile_speed: 40.0,
            range: 36.0,
            aim_tolerance: 0.22,
            target_entity: None,
            is_on_target: false,
        }
    }

    /// Creates a Rapid Small Gun: Full spherical conical gimbal tracking (pitch & yaw inside cone).
    pub fn small_gun(rest_dir: Vec3, cone_angle: f32) -> Self {
        Self {
            kind: ComponentKind::SmallGun,
            tracking_speed: 8.5,
            current_pitch: 0.0,
            current_yaw: 0.0,
            min_pitch: -0.95, // -54.4 degrees depression
            max_pitch: 0.75,  // +43.0 degrees elevation
            cone_angle,       // e.g. 0.61 rad (35 degrees) cone
            rest_dir,
            fire_timer: Timer::from_seconds(0.14, TimerMode::Repeating),
            damage: 1.0,
            projectile_speed: 34.0,
            range: 25.0,
            aim_tolerance: 0.30,
            target_entity: None,
            is_on_target: false,
        }
    }
}

/// Loose pickup component resting on the terrain.
#[derive(Component, Debug, Clone)]
pub struct PickupItem {
    pub kind: ComponentKind,
    pub base_y: f32,
    pub bob_phase: f32,
    pub pickup_radius: f32,
}

impl PickupItem {
    pub fn new(kind: ComponentKind, base_y: f32) -> Self {
        Self {
            kind,
            base_y,
            bob_phase: rand::random::<f32>() * std::f32::consts::TAU,
            pickup_radius: 2.4,
        }
    }
}

/// Tag component for the player vehicle.
#[derive(Component, Debug, Clone, Copy, Default)]
pub struct PlayerVehicle;

/// 3D aerial flight dynamics for rotorcraft (helicopters, gunships, drones) and aircraft.
#[derive(Component, Debug, Clone)]
pub struct FlightLocomotion {
    pub velocity: Vec3,
    pub target_altitude: f32, // Desired height above terrain elevation (e.g. 7.5m)
    pub current_altitude: f32,
    pub max_speed: f32,
    pub acceleration: f32,
    pub drag: f32,
    pub facing_angle: f32,
    pub turn_speed: f32,
    /// Current banking roll angle in radians (tilts into turns).
    pub roll_angle: f32,
    /// Current forward pitch angle in radians (tilts forward on acceleration).
    pub pitch_angle: f32,
}

impl Default for FlightLocomotion {
    fn default() -> Self {
        Self {
            velocity: Vec3::ZERO,
            target_altitude: 7.5,
            current_altitude: 7.5,
            max_speed: 25.0,
            acceleration: 36.0,
            drag: 2.2,
            facing_angle: 0.0,
            turn_speed: 3.5,
            roll_angle: 0.0,
            pitch_angle: 0.0,
        }
    }
}

/// Component for animated spinning rotor blades on helicopters and aircraft.
#[derive(Component, Debug, Clone)]
pub struct RotorBlade {
    pub spin_speed: f32,
    pub axis: Vec3,
}

impl Default for RotorBlade {
    fn default() -> Self {
        Self {
            spin_speed: 38.0,
            axis: Vec3::Y,
        }
    }
}

/// High-level locomotion intent generated either by Player Input (WASD) or AI Navigation (AllyController).
#[derive(Component, Debug, Clone, Default)]
pub struct VehicleDriveIntent {
    /// Desired throttle in [-1.0, 1.0] (1.0 = forward, -0.65 = reverse).
    pub throttle: f32,
    /// Desired steering yaw angular direction in radians.
    pub desired_heading: f32,
    /// Whether the unit should actively apply drive thrust.
    pub active_drive: bool,
}

/// Target formation orientation frame for ally positioning.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum AllyFormationMode {
    /// Target destination is calculated relative to the player's facing orientation (attitude).
    RelativePlayerAttitude,
    /// Target destination is calculated relative to world north.
    RelativeToNorth,
}

/// Autonomous navigation and formation tracking controller for Ally companion units.
#[derive(Component, Debug, Clone)]
pub struct AllyController {
    /// Distinct identifier for multi-ally squads (e.g. 0 = Ground Tank, 1 = Helicopter Gunship).
    pub ally_id: usize,
    /// Desired formation offset in local coordinates (default: left wing trailing (-6.5, 4.0)).
    pub formation_offset: Vec2,
    /// Cruising hover altitude above terrain (0.0 for ground vehicles, 7.5 for helicopters).
    pub cruise_altitude: f32,
    /// Computed target destination in world coordinates.
    pub target_world_pos: Vec3,
    /// Inner stopping deadzone radius in meters (1.8m).
    pub inner_radius: f32,
    /// Outer reactivation moving radius in meters (3.6m).
    pub outer_radius: f32,
    /// Hysteresis motion state flag.
    pub is_moving: bool,
    /// Active formation orientation frame mode.
    pub mode: AllyFormationMode,
}

impl Default for AllyController {
    fn default() -> Self {
        Self {
            ally_id: 0,
            formation_offset: Vec2::new(-6.5, 4.0),
            cruise_altitude: 0.0,
            target_world_pos: Vec3::ZERO,
            inner_radius: 1.8,
            outer_radius: 3.6,
            is_moving: false,
            mode: AllyFormationMode::RelativePlayerAttitude,
        }
    }
}

/// Tag component for visual waypoint marker rendering on the terrain.
#[derive(Component, Debug, Clone, Copy, Default)]
pub struct AllyWaypointer;

/// State tracker for mouse drag interactions with ally formation positioning.
#[derive(Resource, Debug, Clone, Default)]
pub struct AllyCommandState {
    pub is_dragging: bool,
    pub drag_start_pos: Option<Vec2>,
    pub current_ground_hit: Option<Vec3>,
}

/// Tag component for vehicle wheels.
#[derive(Component, Debug, Clone, Copy, Default)]
pub struct VehicleWheel;

/// Shared assets for all modular vehicle components, models, pickup halos, and waypoint markers.
#[derive(Resource, Debug, Clone)]
pub struct VehicleAssets {
    pub chassis_mesh: Handle<Mesh>,
    pub chassis_material: Handle<StandardMaterial>,
    pub ally_chassis_material: Handle<StandardMaterial>,
    pub helicopter_fuselage_mesh: Handle<Mesh>,
    pub helicopter_material: Handle<StandardMaterial>,
    pub main_rotor_mesh: Handle<Mesh>,
    pub tail_rotor_mesh: Handle<Mesh>,
    pub rotor_material: Handle<StandardMaterial>,
    pub skids_mesh: Handle<Mesh>,
    pub skids_material: Handle<StandardMaterial>,
    pub wheel_mesh: Handle<Mesh>,
    pub wheel_material: Handle<StandardMaterial>,
    pub big_turret_mesh: Handle<Mesh>,
    pub big_turret_material: Handle<StandardMaterial>,
    pub small_turret_mesh: Handle<Mesh>,
    pub small_turret_material: Handle<StandardMaterial>,
    pub big_gun_mesh: Handle<Mesh>,
    pub big_gun_material: Handle<StandardMaterial>,
    pub small_gun_mesh: Handle<Mesh>,
    pub small_gun_material: Handle<StandardMaterial>,
    pub halo_mesh: Handle<Mesh>,
    pub halo_mat_big_turret: Handle<StandardMaterial>,
    pub halo_mat_small_turret: Handle<StandardMaterial>,
    pub halo_mat_big_gun: Handle<StandardMaterial>,
    pub halo_mat_small_gun: Handle<StandardMaterial>,
    pub waypoint_mesh: Handle<Mesh>,
    pub waypoint_material: Handle<StandardMaterial>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_component_required_socket() {
        assert_eq!(ComponentKind::BigTurret.required_socket_kind(), SocketKind::Mount);
        assert_eq!(ComponentKind::SmallTurret.required_socket_kind(), SocketKind::Mount);
        assert_eq!(ComponentKind::BigGun.required_socket_kind(), SocketKind::Gun);
        assert_eq!(ComponentKind::SmallGun.required_socket_kind(), SocketKind::Gun);
    }

    #[test]
    fn test_socket_container() {
        let mut sockets = Sockets::new(vec![
            Socket {
                id: 0,
                kind: SocketKind::Mount,
                local_pos: Vec3::Y,
                local_dir: Vec3::Y,
                extent_angle: std::f32::consts::PI,
                occupied: None,
            },
            Socket {
                id: 1,
                kind: SocketKind::Gun,
                local_pos: Vec3::Z,
                local_dir: Vec3::Z,
                extent_angle: 1.0,
                occupied: None,
            },
        ]);

        let mount = sockets.find_available_socket(SocketKind::Mount);
        assert!(mount.is_some());
        assert_eq!(mount.unwrap().0, 0);

        let dummy_entity = Entity::from_bits(42);
        assert!(sockets.occupy_socket(0, dummy_entity));
        assert!(sockets.find_available_socket(SocketKind::Mount).is_none());
        assert!(sockets.find_available_socket(SocketKind::Gun).is_some());
    }

    #[test]
    fn test_flight_locomotion_defaults() {
        let flight = FlightLocomotion::default();
        assert_eq!(flight.target_altitude, 7.5);
        assert_eq!(flight.max_speed, 25.0);
        assert_eq!(flight.velocity, Vec3::ZERO);
        assert_eq!(flight.roll_angle, 0.0);
        assert_eq!(flight.pitch_angle, 0.0);
    }

    #[test]
    fn test_rotor_blade_defaults() {
        let rotor = RotorBlade::default();
        assert_eq!(rotor.spin_speed, 38.0);
        assert_eq!(rotor.axis, Vec3::Y);
    }

    #[test]
    fn test_gun_pitch_limits() {
        let big = GunAutoShooter::big_gun(Vec3::NEG_Z);
        assert!(big.min_pitch < -0.80);
        assert!(big.max_pitch > 0.60);

        let small = GunAutoShooter::small_gun(Vec3::NEG_Z, 0.61);
        assert!(small.min_pitch < -0.90);
        assert!(small.max_pitch > 0.70);
    }
}
