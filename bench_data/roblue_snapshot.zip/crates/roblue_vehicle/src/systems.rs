//! Systems for vehicle momentum physics, socket attachment, hierarchical auto-tracking, and auto-firing.

use crate::components::*;
use crate::models::*;
use bevy_asset::Assets;
use bevy_color::{Color, LinearRgba};
use bevy_ecs::prelude::*;
use bevy_input::keyboard::KeyCode;
use bevy_input::ButtonInput;
use bevy_math::{EulerRot, Quat, Vec2, Vec3};
use bevy_mesh::{Mesh, Mesh3d};
use bevy_pbr::{MeshMaterial3d, StandardMaterial};
use bevy_time::Time;
use bevy_transform::components::{GlobalTransform, Transform};
use rand::Rng;
use roblue_audio::{PlaySfxEvent, SfxKind};
use roblue_core::{EnemyMarker, PlayerMarker};
use roblue_terrain::{Heightfield, TerrainMeshConfig};
use roblue_weapon::{Projectile, WeaponAssets};

/// Startup system: creates procedural meshes and materials for vehicles, turrets, guns, and pickups.
pub fn setup_vehicle_assets(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let chassis_mesh = meshes.add(build_chassis_mesh());
    let chassis_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.18, 0.28, 0.38),
        perceptual_roughness: 0.4,
        metallic: 0.6,
        ..Default::default()
    });

    let wheel_mesh = meshes.add(build_wheel_mesh());
    let wheel_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.08, 0.08, 0.09),
        perceptual_roughness: 0.9,
        ..Default::default()
    });

    let big_turret_mesh = meshes.add(build_big_turret_mesh());
    let big_turret_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.85, 0.18, 0.28),
        emissive: LinearRgba::new(0.4, 0.05, 0.08, 1.0),
        perceptual_roughness: 0.35,
        metallic: 0.7,
        ..Default::default()
    });

    let small_turret_mesh = meshes.add(build_small_turret_mesh());
    let small_turret_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.72, 0.22, 0.90),
        emissive: LinearRgba::new(0.35, 0.08, 0.45, 1.0),
        perceptual_roughness: 0.3,
        metallic: 0.75,
        ..Default::default()
    });

    let big_gun_mesh = meshes.add(build_big_gun_mesh());
    let big_gun_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.95, 0.68, 0.12),
        emissive: LinearRgba::new(0.8, 0.5, 0.08, 1.0),
        perceptual_roughness: 0.25,
        metallic: 0.85,
        ..Default::default()
    });

    let small_gun_mesh = meshes.add(build_small_gun_mesh());
    let small_gun_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.12, 0.82, 0.95),
        emissive: LinearRgba::new(0.15, 0.7, 0.9, 1.0),
        perceptual_roughness: 0.2,
        metallic: 0.85,
        ..Default::default()
    });

    let halo_mesh = meshes.add(build_pickup_halo_mesh());

    let halo_mat_big_turret = materials.add(StandardMaterial {
        base_color: Color::srgba(0.9, 0.1, 0.2, 0.85),
        emissive: LinearRgba::new(2.2, 0.3, 0.3, 1.0),
        unlit: true,
        ..Default::default()
    });

    let halo_mat_small_turret = materials.add(StandardMaterial {
        base_color: Color::srgba(0.8, 0.2, 0.9, 0.85),
        emissive: LinearRgba::new(1.8, 0.4, 2.2, 1.0),
        unlit: true,
        ..Default::default()
    });

    let halo_mat_big_gun = materials.add(StandardMaterial {
        base_color: Color::srgba(1.0, 0.7, 0.1, 0.85),
        emissive: LinearRgba::new(2.4, 1.6, 0.2, 1.0),
        unlit: true,
        ..Default::default()
    });

    let halo_mat_small_gun = materials.add(StandardMaterial {
        base_color: Color::srgba(0.1, 0.8, 1.0, 0.85),
        emissive: LinearRgba::new(0.3, 1.8, 2.4, 1.0),
        unlit: true,
        ..Default::default()
    });

    let ally_chassis_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.08, 0.48, 0.52),
        emissive: LinearRgba::new(0.08, 0.55, 0.65, 1.0),
        perceptual_roughness: 0.35,
        metallic: 0.7,
        ..Default::default()
    });

    let helicopter_fuselage_mesh = meshes.add(build_helicopter_fuselage_mesh());
    let helicopter_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.12, 0.42, 0.48),
        emissive: LinearRgba::new(0.05, 0.35, 0.45, 1.0),
        perceptual_roughness: 0.3,
        metallic: 0.8,
        ..Default::default()
    });

    let main_rotor_mesh = meshes.add(build_main_rotor_mesh());
    let tail_rotor_mesh = meshes.add(build_tail_rotor_mesh());
    let rotor_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.08, 0.08, 0.10),
        perceptual_roughness: 0.8,
        metallic: 0.9,
        ..Default::default()
    });

    let skids_mesh = meshes.add(build_helicopter_skids_mesh());
    let skids_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.25, 0.25, 0.28),
        perceptual_roughness: 0.5,
        metallic: 0.85,
        ..Default::default()
    });

    let waypoint_mesh = meshes.add(build_waypoint_ring_mesh());
    let waypoint_material = materials.add(StandardMaterial {
        base_color: Color::srgba(0.1, 0.85, 1.0, 0.85),
        emissive: LinearRgba::new(0.3, 2.0, 2.6, 1.0),
        unlit: true,
        ..Default::default()
    });

    commands.insert_resource(VehicleAssets {
        chassis_mesh,
        chassis_material,
        ally_chassis_material,
        helicopter_fuselage_mesh,
        helicopter_material,
        main_rotor_mesh,
        tail_rotor_mesh,
        rotor_material,
        skids_mesh,
        skids_material,
        wheel_mesh,
        wheel_material,
        big_turret_mesh,
        big_turret_material,
        small_turret_mesh,
        small_turret_material,
        big_gun_mesh,
        big_gun_material,
        small_gun_mesh,
        small_gun_material,
        halo_mesh,
        halo_mat_big_turret,
        halo_mat_small_turret,
        halo_mat_big_gun,
        halo_mat_small_gun,
        waypoint_mesh,
        waypoint_material,
    });

    commands.init_resource::<AllyCommandState>();

    tracing::info!("Roblue VehicleAssets initialized with Ally and Helicopter assets.");
}

/// Animates spinning rotor blades on helicopters, gunships, and aerial vehicles.
pub fn rotor_animation_system(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &RotorBlade)>,
) {
    let dt = time.delta_secs();
    for (mut transform, blade) in query.iter_mut() {
        let delta_rot = Quat::from_axis_angle(blade.axis, blade.spin_speed * dt);
        transform.rotation *= delta_rot;
    }
}

/// Helper function to spawn a single pickup item in the world.
pub fn spawn_pickup(
    commands: &mut Commands,
    assets: &VehicleAssets,
    kind: ComponentKind,
    pos_x: f32,
    pos_z: f32,
    ground_y: f32,
) {
    let (mesh, material, halo_mat) = match kind {
        ComponentKind::BigTurret => (
            assets.big_turret_mesh.clone(),
            assets.big_turret_material.clone(),
            assets.halo_mat_big_turret.clone(),
        ),
        ComponentKind::SmallTurret => (
            assets.small_turret_mesh.clone(),
            assets.small_turret_material.clone(),
            assets.halo_mat_small_turret.clone(),
        ),
        ComponentKind::BigGun => (
            assets.big_gun_mesh.clone(),
            assets.big_gun_material.clone(),
            assets.halo_mat_big_gun.clone(),
        ),
        ComponentKind::SmallGun => (
            assets.small_gun_mesh.clone(),
            assets.small_gun_material.clone(),
            assets.halo_mat_small_gun.clone(),
        ),
    };

    let base_y = ground_y + 0.5;

    // Spawn pickup root with halo
    commands
        .spawn((
            Mesh3d(assets.halo_mesh.clone()),
            MeshMaterial3d(halo_mat),
            Transform::from_xyz(pos_x, base_y, pos_z),
            PickupItem::new(kind, base_y),
        ))
        .with_children(|parent| {
            // Spawn miniature rotating component preview inside the halo
            parent.spawn((
                Mesh3d(mesh),
                MeshMaterial3d(material),
                Transform::from_xyz(0.0, 0.2, 0.0),
            ));
        });
}

/// Startup system: spawns 5 of each component (20 total) across the island map.
pub fn spawn_initial_pickups_system(
    mut commands: Commands,
    vehicle_assets: Option<Res<VehicleAssets>>,
    terrain_config: Res<TerrainMeshConfig>,
) {
    let Some(assets) = vehicle_assets else {
        return;
    };

    let hf = Heightfield::new(terrain_config.heightfield.clone());
    let mut rng = rand::thread_rng();

    const KINDS: [ComponentKind; 4] = [
        ComponentKind::BigTurret,
        ComponentKind::SmallTurret,
        ComponentKind::BigGun,
        ComponentKind::SmallGun,
    ];

    for kind in KINDS {
        let mut spawned = 0;
        let mut attempts = 0;
        while spawned < 5 && attempts < 100 {
            attempts += 1;
            let angle = rng.gen_range(0.0..std::f32::consts::TAU);
            let dist = rng.gen_range(10.0..56.0);
            let px = angle.cos() * dist;
            let pz = angle.sin() * dist;
            let py = hf.sample_height(px, pz);

            if py >= terrain_config.palette.water_level + 0.35 {
                spawn_pickup(&mut commands, &assets, kind, px, pz, py);
                spawned += 1;
            }
        }
    }

    tracing::info!("Spawned initial 20 modular vehicle pickups (5 of each type).");
}

/// Twin-stick driving physics with acceleration, momentum, and terrain normal alignment.
pub fn vehicle_movement_system(
    time: Res<Time>,
    keyboard: Res<ButtonInput<KeyCode>>,
    terrain_config: Res<TerrainMeshConfig>,
    mut query: Query<(&mut Transform, &mut VehicleChassis), With<PlayerMarker>>,
) {
    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    for (mut transform, mut chassis) in query.iter_mut() {
        let turn_speed = chassis.turn_speed;

        // 1. A / D Steering Controls: Directly rotate the chassis facing angle
        if keyboard.pressed(KeyCode::KeyA) || keyboard.pressed(KeyCode::ArrowLeft) {
            chassis.facing_angle += turn_speed * dt;
        }
        if keyboard.pressed(KeyCode::KeyD) || keyboard.pressed(KeyCode::ArrowRight) {
            chassis.facing_angle -= turn_speed * dt;
        }

        // Keep facing_angle normalized within [-PI, PI]
        while chassis.facing_angle > std::f32::consts::PI {
            chassis.facing_angle -= std::f32::consts::TAU;
        }
        while chassis.facing_angle < -std::f32::consts::PI {
            chassis.facing_angle += std::f32::consts::TAU;
        }

        // Vehicle forward unit vector in XZ ground plane
        let forward_vec = Vec2::new(-chassis.facing_angle.sin(), -chassis.facing_angle.cos());

        // 2. W / S Throttle Controls (W = forward, S = reverse)
        let mut throttle = 0.0f32;
        if keyboard.pressed(KeyCode::KeyW) || keyboard.pressed(KeyCode::ArrowUp) {
            throttle += 1.0;
        }
        if keyboard.pressed(KeyCode::KeyS) || keyboard.pressed(KeyCode::ArrowDown) {
            throttle -= 0.65;
        }

        let current_pos = transform.translation;
        let current_normal = hf.sample_normal(current_pos.x, current_pos.z);
        let min_land_height = terrain_config.palette.water_level + 0.20;

        // 3. Calculate terrain slope in direction of travel and scale max speed & acceleration
        let slope_speed_mult = if chassis.velocity.length_squared() > 0.1 {
            let vel_norm = chassis.velocity.normalize();
            let slope_grad = -(current_normal.x * vel_norm.x + current_normal.z * vel_norm.y) / current_normal.y.max(0.1);
            let slope_angle = slope_grad.atan();

            if slope_angle > 0.0 {
                // Uphill: apply vehicle slope penalty
                let factor = (slope_angle / chassis.max_climb_angle).clamp(0.0, 1.0);
                (1.0 - factor * chassis.slope_penalty).max(0.20)
            } else {
                // Downhill: apply downhill boost
                let factor = ((-slope_angle) / chassis.max_climb_angle).clamp(0.0, 1.0);
                1.0 + factor * chassis.downhill_boost
            }
        } else {
            1.0
        };

        chassis.max_speed = chassis.base_max_speed * slope_speed_mult;
        let effective_accel = chassis.acceleration * slope_speed_mult;
        let drag = chassis.drag;
        let max_speed = chassis.max_speed;

        // 4. Apply throttle acceleration along forward vector
        if throttle.abs() > 0.01 {
            chassis.velocity += forward_vec * (throttle * effective_accel * dt);
        }

        // 5. Tire Traction Physics: Decompose into forward speed and lateral drift
        let fwd_speed = chassis.velocity.dot(forward_vec);
        let lat_vel = chassis.velocity - forward_vec * fwd_speed;

        let fwd_drag = (1.0 - drag * dt).clamp(0.0, 1.0);
        let lat_drag = (1.0 - (drag * 3.5) * dt).clamp(0.0, 1.0);

        chassis.velocity = forward_vec * (fwd_speed * fwd_drag) + lat_vel * lat_drag;

        // 6. Clamp to current slope-adjusted maximum speed
        if chassis.velocity.length() > max_speed {
            chassis.velocity = chassis.velocity.normalize() * max_speed;
        }

        // 7. Water Prohibition: Test next movement on dry land before updating position
        let delta_x = chassis.velocity.x * dt;
        let delta_z = chassis.velocity.y * dt;

        let next_x = current_pos.x + delta_x;
        let next_z = current_pos.z + delta_z;
        let next_h = hf.sample_height(next_x, next_z);

        if next_h >= min_land_height {
            transform.translation.x = next_x;
            transform.translation.z = next_z;
        } else {
            // Blocked by water! Try sliding along axes:
            let try_x_h = hf.sample_height(next_x, current_pos.z);
            let try_z_h = hf.sample_height(current_pos.x, next_z);

            if try_x_h >= min_land_height {
                transform.translation.x = next_x;
                chassis.velocity.y *= 0.2;
            } else if try_z_h >= min_land_height {
                transform.translation.z = next_z;
                chassis.velocity.x *= 0.2;
            } else {
                // Direct shoreline wall: stop motion into water
                chassis.velocity *= 0.1;
            }
        }

        // 8. Snap elevation to terrain height + chassis ground clearance
        let ground_y = hf.sample_height(transform.translation.x, transform.translation.z);
        transform.translation.y = ground_y + 0.65;

        // 9. Sample terrain normal and apply pitch/roll surface adherence
        let terrain_normal = hf.sample_normal(transform.translation.x, transform.translation.z);
        let normal_rot = Quat::from_rotation_arc(Vec3::Y, terrain_normal);
        let yaw_rot = Quat::from_rotation_y(chassis.facing_angle);

        transform.rotation = normal_rot * yaw_rot;
    }
}

/// Animates loose pickup items floating and spinning above the terrain.
pub fn pickup_animation_system(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &PickupItem)>,
) {
    let dt = time.delta_secs();
    let elapsed = time.elapsed_secs();

    for (mut transform, pickup) in query.iter_mut() {
        // Vertical bobbing
        let bob = (elapsed * 2.6 + pickup.bob_phase).sin() * 0.22;
        transform.translation.y = pickup.base_y + bob;

        // Continuous rotation
        transform.rotate_y(1.6 * dt);
    }
}

/// Detects when the player touches a pickup and attaches it to the closest available socket.
pub fn pickup_collection_and_attachment_system(
    mut commands: Commands,
    vehicle_assets: Option<Res<VehicleAssets>>,
    terrain_config: Res<TerrainMeshConfig>,
    player_query: Query<(&Transform, Entity), With<PlayerMarker>>,
    mut sockets_query: Query<(Entity, &GlobalTransform, &mut Sockets)>,
    pickup_query: Query<(Entity, &Transform, &PickupItem)>,
) {
    let Some(assets) = vehicle_assets else {
        return;
    };

    let Some((player_transform, _player_entity)) = player_query.iter().next() else {
        return;
    };

    let player_pos = player_transform.translation;
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    for (pickup_entity, pickup_transform, pickup) in pickup_query.iter() {
        let dist = (player_pos - pickup_transform.translation).length();

        if dist <= pickup.pickup_radius {
            let req_kind = pickup.kind.required_socket_kind();

            // Find the closest available compatible socket across all vehicle parts in the tree
            let mut best_match: Option<(Entity, usize, Vec3, Vec3, f32, f32)> = None;

            for (socket_entity, socket_global_trans, sockets) in sockets_query.iter() {
                if let Some((socket_id, local_pos, local_dir, extent_angle)) = sockets.find_available_socket(req_kind) {
                    let socket_world_pos = socket_global_trans.transform_point(local_pos);
                    let socket_dist_sq = (player_pos - socket_world_pos).length_squared();

                    if let Some((_, _, _, _, _, best_dist_sq)) = best_match {
                        if socket_dist_sq < best_dist_sq {
                            best_match = Some((socket_entity, socket_id, local_pos, local_dir, extent_angle, socket_dist_sq));
                        }
                    } else {
                        best_match = Some((socket_entity, socket_id, local_pos, local_dir, extent_angle, socket_dist_sq));
                    }
                }
            }

            if let Some((parent_entity, socket_id, local_pos, local_dir, _extent_angle, _)) = best_match {
                // 1. Mark the socket as occupied
                if let Ok((_, _, mut sockets)) = sockets_query.get_mut(parent_entity) {
                    // Spawn the new child entity attached to this socket
                    let child_id = match pickup.kind {
                        ComponentKind::BigTurret => {
                            // Big Turret: has top mount and 2 side gun points
                            commands.spawn((
                                Mesh3d(assets.big_turret_mesh.clone()),
                                MeshMaterial3d(assets.big_turret_material.clone()),
                                Transform::from_translation(local_pos),
                                TurretTracker::new(ComponentKind::BigTurret, 1.5),
                                Sockets::new(vec![
                                    Socket {
                                        id: 0,
                                        kind: SocketKind::Mount,
                                        local_pos: Vec3::new(0.0, 0.48, 0.0),
                                        local_dir: Vec3::Y,
                                        extent_angle: std::f32::consts::PI,
                                        occupied: None,
                                    },
                                    Socket {
                                        id: 1,
                                        kind: SocketKind::Gun,
                                        local_pos: Vec3::new(-0.7, 0.15, 0.0),
                                        local_dir: Vec3::new(-1.0, 0.0, 1.0).normalize(),
                                        extent_angle: std::f32::consts::FRAC_PI_2,
                                        occupied: None,
                                    },
                                    Socket {
                                        id: 2,
                                        kind: SocketKind::Gun,
                                        local_pos: Vec3::new(0.7, 0.15, 0.0),
                                        local_dir: Vec3::new(1.0, 0.0, 1.0).normalize(),
                                        extent_angle: std::f32::consts::FRAC_PI_2,
                                        occupied: None,
                                    },
                                ]),
                            )).id()
                        }
                        ComponentKind::SmallTurret => {
                            // Small Turret: has top gun point and side gun point
                            commands.spawn((
                                Mesh3d(assets.small_turret_mesh.clone()),
                                MeshMaterial3d(assets.small_turret_material.clone()),
                                Transform::from_translation(local_pos),
                                TurretTracker::new(ComponentKind::SmallTurret, 4.0),
                                Sockets::new(vec![
                                    Socket {
                                        id: 0,
                                        kind: SocketKind::Gun,
                                        local_pos: Vec3::new(0.0, 0.35, 0.0),
                                        local_dir: Vec3::Z,
                                        extent_angle: std::f32::consts::PI,
                                        occupied: None,
                                    },
                                    Socket {
                                        id: 1,
                                        kind: SocketKind::Gun,
                                        local_pos: Vec3::new(0.35, 0.15, 0.0),
                                        local_dir: Vec3::Z,
                                        extent_angle: std::f32::consts::FRAC_PI_2,
                                        occupied: None,
                                    },
                                ]),
                            )).id()
                        }
                        ComponentKind::BigGun => {
                            // Big Gun: Heavy Cannon with vertical elevation pitch only
                            commands.spawn((
                                Mesh3d(assets.big_gun_mesh.clone()),
                                MeshMaterial3d(assets.big_gun_material.clone()),
                                Transform::from_translation(local_pos),
                                GunAutoShooter::big_gun(local_dir),
                            )).id()
                        }
                        ComponentKind::SmallGun => {
                            // Small Gun: Conical gimbal twin autocannon
                            commands.spawn((
                                Mesh3d(assets.small_gun_mesh.clone()),
                                MeshMaterial3d(assets.small_gun_material.clone()),
                                Transform::from_translation(local_pos),
                                GunAutoShooter::small_gun(local_dir, 0.61),
                            )).id()
                        }
                    };

                    // Attach as child in Bevy hierarchy
                    commands.entity(parent_entity).add_child(child_id);
                    sockets.occupy_socket(socket_id, child_id);

                    // 2. Play attachment sound effect
                    commands.trigger(
                        PlaySfxEvent::new(SfxKind::LevelUp)
                            .with_volume(0.65)
                            .with_pitch(1.2),
                    );

                    tracing::info!("Attached {:?} to socket #{} on {:?}", pickup.kind, socket_id, parent_entity);

                    // 3. Despawn the collected pickup item
                    commands.entity(pickup_entity).try_despawn();

                    // 4. Respawn a new replacement pickup elsewhere on the terrain
                    let mut rng = rand::thread_rng();
                    for _ in 0..50 {
                        let angle = rng.gen_range(0.0..std::f32::consts::TAU);
                        let respawn_dist = rng.gen_range(14.0..58.0);
                        let rx = player_pos.x + angle.cos() * respawn_dist;
                        let rz = player_pos.z + angle.sin() * respawn_dist;
                        let ry = hf.sample_height(rx, rz);

                        if ry >= terrain_config.palette.water_level + 0.35 {
                            spawn_pickup(&mut commands, &assets, pickup.kind, rx, rz, ry);
                            break;
                        }
                    }
                }
            }
        }
    }
}

/// Kinematic auto-tracking: Big Gun elevation, Big Turret azimuth, and Small Gun conical gimbal aiming.
#[allow(clippy::type_complexity)]
pub fn turret_and_gun_tracking_system(
    time: Res<Time>,
    enemy_query: Query<(Entity, &GlobalTransform), With<EnemyMarker>>,
    mut turret_query: Query<(&GlobalTransform, &mut Transform, &mut TurretTracker), (Without<GunAutoShooter>, Without<EnemyMarker>)>,
    mut gun_query: Query<(&GlobalTransform, &mut Transform, &mut GunAutoShooter), (Without<TurretTracker>, Without<EnemyMarker>)>,
) {
    let dt = time.delta_secs();

    // 1. Turret Azimuth Tracking
    for (global_trans, mut local_trans, mut tracker) in turret_query.iter_mut() {
        let turret_world_pos = global_trans.translation();
        let mut target_enemy_pos: Option<Vec3> = None;

        match tracker.kind {
            ComponentKind::BigTurret => {
                // Big Turret Heuristic: Least time to acquire aim (in range, minimum yaw traverse time)
                const BIG_TURRET_RANGE: f32 = 38.0;
                let mut min_acquire_time = f32::MAX;

                for (_, enemy_trans) in enemy_query.iter() {
                    let enemy_pos = enemy_trans.translation();
                    let dist = (turret_world_pos - enemy_pos).length();

                    if dist <= BIG_TURRET_RANGE {
                        let local_target = global_trans.affine().inverse().transform_point3(enemy_pos);
                        let target_yaw = (-local_target.x).atan2(-local_target.z);
                        let time_to_acquire = target_yaw.abs() / tracker.tracking_speed.max(0.1);

                        if time_to_acquire < min_acquire_time {
                            min_acquire_time = time_to_acquire;
                            target_enemy_pos = Some(enemy_pos);
                        }
                    }
                }
            }
            ComponentKind::SmallTurret | ComponentKind::BigGun | ComponentKind::SmallGun => {
                // Small Turret Heuristic: Closest Euclidean distance (unchanged)
                let mut min_dist_sq = f32::MAX;

                for (_, enemy_trans) in enemy_query.iter() {
                    let enemy_pos = enemy_trans.translation();
                    let dist_sq = (turret_world_pos - enemy_pos).length_squared();
                    if dist_sq < min_dist_sq {
                        min_dist_sq = dist_sq;
                        target_enemy_pos = Some(enemy_pos);
                    }
                }
            }
        }

        if let Some(target_pos) = target_enemy_pos {
            let local_target = global_trans.affine().inverse().transform_point3(target_pos);
            let target_yaw = (-local_target.x).atan2(-local_target.z);

            // Smoothly traverse horizontal yaw
            let step = target_yaw.clamp(-tracker.tracking_speed * dt, tracker.tracking_speed * dt);
            local_trans.rotate_y(step);
            tracker.current_yaw += step;
        }
    }

    // 2. Gun Kinematic Tracking
    for (global_trans, mut local_trans, mut gun) in gun_query.iter_mut() {
        let gun_world_pos = global_trans.translation();
        let mut chosen_target: Option<(Entity, Vec3)> = None;

        match gun.kind {
            ComponentKind::BigGun => {
                // Big Gun Heuristic: Least time to acquire aim within range and elevation limits
                let mut min_acquire_time = f32::MAX;

                for (enemy_entity, enemy_trans) in enemy_query.iter() {
                    let enemy_pos = enemy_trans.translation();
                    let dist = (gun_world_pos - enemy_pos).length();

                    if dist <= gun.range {
                        let local_target = global_trans.affine().inverse().transform_point3(enemy_pos);
                        let dist_xz = (local_target.x * local_target.x + local_target.z * local_target.z).sqrt();
                        let desired_pitch = (local_target.y / dist_xz.max(0.1)).atan();

                        // Check available elevation limits
                        if desired_pitch >= (gun.min_pitch - 0.08) && desired_pitch <= (gun.max_pitch + 0.08) {
                            let pitch_diff = (desired_pitch - gun.current_pitch).abs();
                            let t_pitch = pitch_diff / gun.tracking_speed.max(0.1);

                            let target_yaw = (-local_target.x).atan2(-local_target.z);
                            let t_yaw = target_yaw.abs() / 2.0; // Turret traverse rate estimate

                            let total_acquire_time = t_pitch.max(t_yaw);

                            if total_acquire_time < min_acquire_time {
                                min_acquire_time = total_acquire_time;
                                chosen_target = Some((enemy_entity, enemy_pos));
                            }
                        }
                    }
                }
            }
            ComponentKind::SmallGun | ComponentKind::BigTurret | ComponentKind::SmallTurret => {
                // Small Gun Heuristic: Closest Euclidean distance within range (unchanged)
                let mut best_dist = f32::MAX;

                for (enemy_entity, enemy_trans) in enemy_query.iter() {
                    let enemy_pos = enemy_trans.translation();
                    let dist = (gun_world_pos - enemy_pos).length();

                    if dist <= gun.range && dist < best_dist {
                        best_dist = dist;
                        chosen_target = Some((enemy_entity, enemy_pos));
                    }
                }
            }
        }

        if let Some((enemy_entity, target_pos)) = chosen_target {
            gun.target_entity = Some(enemy_entity);

            let local_target = global_trans.affine().inverse().transform_point3(target_pos);
            let dist_xz = (local_target.x * local_target.x + local_target.z * local_target.z).sqrt();

            match gun.kind {
                ComponentKind::BigGun => {
                    // Big Gun: Elevation pitch only (up/down), zero relative yaw
                    let desired_pitch = (local_target.y / dist_xz.max(0.1)).atan().clamp(gun.min_pitch, gun.max_pitch);
                    let pitch_step = (desired_pitch - gun.current_pitch).clamp(-gun.tracking_speed * dt, gun.tracking_speed * dt);
                    gun.current_pitch += pitch_step;

                    // Apply pure vertical pitch around X-axis (tilts forward-facing -Z barrel up/down)
                    local_trans.rotation = Quat::from_rotation_x(gun.current_pitch);

                    // Big Gun is on target when elevation is aligned and parent turret has traversed onto azimuth
                    let pitch_err = (desired_pitch - gun.current_pitch).abs();
                    let yaw_err = (-local_target.x).atan2(-local_target.z).abs();
                    gun.is_on_target = pitch_err < gun.aim_tolerance && yaw_err < (gun.aim_tolerance * 1.6);
                }
                ComponentKind::SmallGun | ComponentKind::BigTurret | ComponentKind::SmallTurret => {
                    // Small Gun: Conical gimbal (moves in a 3D spherical cone)
                    let target_yaw = (-local_target.x).atan2(-local_target.z);
                    let target_pitch = (local_target.y / dist_xz.max(0.1)).atan();

                    let clamped_yaw = target_yaw.clamp(-gun.cone_angle, gun.cone_angle);
                    let clamped_pitch = target_pitch.clamp(gun.min_pitch, gun.max_pitch);

                    let yaw_step = (clamped_yaw - gun.current_yaw).clamp(-gun.tracking_speed * dt, gun.tracking_speed * dt);
                    let pitch_step = (clamped_pitch - gun.current_pitch).clamp(-gun.tracking_speed * dt, gun.tracking_speed * dt);

                    gun.current_yaw += yaw_step;
                    gun.current_pitch += pitch_step;

                    // Apply combined gimbal rotation in cone
                    local_trans.rotation = Quat::from_euler(EulerRot::YXZ, gun.current_yaw, gun.current_pitch, 0.0);

                    let err = (target_yaw - gun.current_yaw).abs() + (target_pitch - gun.current_pitch).abs();
                    gun.is_on_target = err < gun.aim_tolerance;
                }
            }
        } else {
            gun.target_entity = None;
            gun.is_on_target = false;
        }
    }
}

/// Auto-fires active guns when aimed at an enemy target within tolerance.
pub fn gun_auto_fire_system(
    mut commands: Commands,
    time: Res<Time>,
    weapon_assets: Option<Res<WeaponAssets>>,
    mut gun_query: Query<(&GlobalTransform, &mut GunAutoShooter)>,
) {
    let Some(w_assets) = weapon_assets else {
        return;
    };

    let dt = time.delta();

    for (global_trans, mut gun) in gun_query.iter_mut() {
        gun.fire_timer.tick(dt);

        if gun.fire_timer.just_finished() && gun.is_on_target && gun.target_entity.is_some() {
            let forward_dir = global_trans.forward().as_vec3();
            let muzzle_offset = if gun.kind == ComponentKind::BigGun { 1.6 } else { 0.8 };
            let spawn_pos = global_trans.translation() + forward_dir * muzzle_offset;

            let (mesh, material, proj) = if gun.kind == ComponentKind::BigGun {
                (
                    w_assets.big_bullet_mesh.clone(),
                    w_assets.big_bullet_material.clone(),
                    Projectile::heavy_shell(forward_dir * gun.projectile_speed, gun.target_entity),
                )
            } else {
                (
                    w_assets.bullet_mesh.clone(),
                    w_assets.bullet_material.clone(),
                    Projectile::autocannon_bullet(forward_dir * gun.projectile_speed, gun.target_entity),
                )
            };

            commands.spawn((
                Mesh3d(mesh),
                MeshMaterial3d(material),
                Transform::from_translation(spawn_pos),
                proj,
            ));

            // Play sound effect tailored to weapon type: Puchu for Big Gun!
            if gun.kind == ComponentKind::BigGun {
                commands.trigger(
                    PlaySfxEvent::new(SfxKind::Puchu)
                        .with_volume(0.85)
                        .with_pitch(1.0),
                );
            } else {
                commands.trigger(
                    PlaySfxEvent::new(SfxKind::ActionClick)
                        .with_volume(0.40)
                        .with_pitch(1.45),
                );
            }
        }
    }
}
