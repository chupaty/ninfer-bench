//! Procedural 3D mesh constructors for modular vehicles, turrets, weapons, and pickups.

use bevy_asset::RenderAssetUsages;
use bevy_math::primitives::{Cuboid, Cylinder, Torus};
use bevy_mesh::{Indices, Mesh, PrimitiveTopology};

/// Builds the heavy armored chassis base mesh.
#[must_use]
pub fn build_chassis_mesh() -> Mesh {
    Mesh::from(Cuboid::new(2.2, 0.65, 3.4))
}

/// Builds the treaded wheel mesh for vehicle corners.
#[must_use]
pub fn build_wheel_mesh() -> Mesh {
    Mesh::from(Cylinder::new(0.42, 0.35))
}

/// Builds the heavy armored Big Turret ring mesh.
#[must_use]
pub fn build_big_turret_mesh() -> Mesh {
    Mesh::from(Cylinder::new(0.95, 0.48))
}

/// Builds the agile Small Turret cupola mesh.
#[must_use]
pub fn build_small_turret_mesh() -> Mesh {
    Mesh::from(Cylinder::new(0.58, 0.36))
}

/// Builds a forward-pointing barrel mesh along the -Z axis with the pivot at Z = 0.0.
#[allow(clippy::type_complexity)]
pub fn build_forward_barrel_mesh(radius: f32, length: f32, segments: usize, offset_x: f32) -> (Vec<[f32; 3]>, Vec<[f32; 3]>, Vec<[f32; 2]>, Vec<u32>) {
    let mut positions = Vec::new();
    let mut normals = Vec::new();
    let mut uvs = Vec::new();
    let mut indices = Vec::new();

    // Side vertices
    for s in 0..=segments {
        let frac = s as f32 / segments as f32;
        let angle = frac * std::f32::consts::TAU;
        let x = offset_x + angle.cos() * radius;
        let y = angle.sin() * radius;
        let nx = angle.cos();
        let ny = angle.sin();

        // Base vertex (at z = 0.0)
        positions.push([x, y, 0.0]);
        normals.push([nx, ny, 0.0]);
        uvs.push([frac, 0.0]);

        // Tip vertex (at z = -length)
        positions.push([x, y, -length]);
        normals.push([nx, ny, 0.0]);
        uvs.push([frac, 1.0]);
    }

    // Side indices
    for s in 0..segments {
        let i0 = (s * 2) as u32;
        let i1 = i0 + 1;
        let i2 = i0 + 2;
        let i3 = i0 + 3;

        indices.extend_from_slice(&[i0, i1, i2, i1, i3, i2]);
    }

    // Front cap (at z = -length, pointing -Z)
    let center_idx = positions.len() as u32;
    positions.push([offset_x, 0.0, -length]);
    normals.push([0.0, 0.0, -1.0]);
    uvs.push([0.5, 0.5]);

    for s in 0..=segments {
        let frac = s as f32 / segments as f32;
        let angle = frac * std::f32::consts::TAU;
        let x = offset_x + angle.cos() * radius;
        let y = angle.sin() * radius;

        positions.push([x, y, -length]);
        normals.push([0.0, 0.0, -1.0]);
        uvs.push([0.5 + angle.cos() * 0.5, 0.5 + angle.sin() * 0.5]);
    }

    for s in 0..segments {
        let i1 = center_idx + 1 + s as u32;
        let i2 = i1 + 1;
        indices.extend_from_slice(&[center_idx, i2, i1]);
    }

    (positions, normals, uvs, indices)
}

/// Builds the heavy long-range cannon barrel mesh pointing forward horizontally along -Z.
#[must_use]
pub fn build_big_gun_mesh() -> Mesh {
    let (mut positions, mut normals, mut uvs, mut indices) = build_forward_barrel_mesh(0.18, 2.3, 16, 0.0);

    // Add muzzle brake ring at the tip (z = -2.0 to -2.3, radius 0.25)
    let (mb_pos, mb_norm, mb_uv, mb_idx) = build_forward_barrel_mesh(0.25, 0.35, 16, 0.0);
    let base_idx = positions.len() as u32;

    for mut p in mb_pos {
        p[2] -= 1.95; // shift muzzle brake to barrel tip
        positions.push(p);
    }
    normals.extend(mb_norm);
    uvs.extend(mb_uv);
    for idx in mb_idx {
        indices.push(base_idx + idx);
    }

    let mut mesh = Mesh::new(PrimitiveTopology::TriangleList, RenderAssetUsages::default());
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_indices(Indices::U32(indices));

    mesh
}

/// Builds the rapid-fire twin autocannon barrel mesh pointing forward horizontally along -Z.
#[must_use]
pub fn build_small_gun_mesh() -> Mesh {
    let (mut positions, mut normals, mut uvs, mut indices) = build_forward_barrel_mesh(0.09, 1.4, 12, -0.14);
    let (b2_pos, b2_norm, b2_uv, b2_idx) = build_forward_barrel_mesh(0.09, 1.4, 12, 0.14);

    let base_idx = positions.len() as u32;
    positions.extend(b2_pos);
    normals.extend(b2_norm);
    uvs.extend(b2_uv);
    for idx in b2_idx {
        indices.push(base_idx + idx);
    }

    let mut mesh = Mesh::new(PrimitiveTopology::TriangleList, RenderAssetUsages::default());
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_indices(Indices::U32(indices));

    mesh
}

/// Builds the glowing holographic beacon ring mesh for pickup items.
#[must_use]
pub fn build_pickup_halo_mesh() -> Mesh {
    Mesh::from(Torus::new(0.08, 1.1))
}

/// Builds the glowing waypoint command ring for the ally's target destination.
#[must_use]
pub fn build_waypoint_ring_mesh() -> Mesh {
    Mesh::from(Torus::new(0.06, 1.4))
}

/// Builds the aerodynamic fuselage body for the Helicopter Gunship.
#[must_use]
pub fn build_helicopter_fuselage_mesh() -> Mesh {
    // Fuselage cabin: sleek aerodynamic box body
    Mesh::from(Cuboid::new(1.8, 1.2, 3.2))
}

/// Builds the 4-blade spinning main rotor mesh.
#[must_use]
pub fn build_main_rotor_mesh() -> Mesh {
    Mesh::from(Cuboid::new(5.2, 0.04, 0.22))
}

/// Builds the 2-blade spinning tail rotor mesh.
#[must_use]
pub fn build_tail_rotor_mesh() -> Mesh {
    Mesh::from(Cuboid::new(0.12, 1.2, 0.04))
}

/// Builds the twin landing skids mesh for the helicopter undercarriage.
#[must_use]
pub fn build_helicopter_skids_mesh() -> Mesh {
    Mesh::from(Cuboid::new(1.9, 0.15, 2.6))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chassis_mesh_creation() {
        let mesh = build_chassis_mesh();
        assert!(mesh.count_vertices() > 0);
    }

    #[test]
    fn test_turret_and_gun_meshes() {
        let big_t = build_big_turret_mesh();
        let small_t = build_small_turret_mesh();
        let big_g = build_big_gun_mesh();
        let small_g = build_small_gun_mesh();
        let halo = build_pickup_halo_mesh();
        let wp = build_waypoint_ring_mesh();
        let heli = build_helicopter_fuselage_mesh();
        let rotor = build_main_rotor_mesh();
        let tail = build_tail_rotor_mesh();
        let skids = build_helicopter_skids_mesh();

        assert!(big_t.count_vertices() > 0);
        assert!(small_t.count_vertices() > 0);
        assert!(big_g.count_vertices() > 0);
        assert!(small_g.count_vertices() > 0);
        assert!(halo.count_vertices() > 0);
        assert!(wp.count_vertices() > 0);
        assert!(heli.count_vertices() > 0);
        assert!(rotor.count_vertices() > 0);
        assert!(tail.count_vertices() > 0);
        assert!(skids.count_vertices() > 0);
    }
}
