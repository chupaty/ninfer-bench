//! Autonomous Ally vehicle AI, formation tracking, hysteresis navigation, and mouse command interface.

use crate::components::*;
use bevy_camera::Camera;
use bevy_ecs::prelude::*;
use bevy_input::mouse::MouseButton;
use bevy_input::ButtonInput;
use bevy_math::{Quat, Ray3d, Vec2, Vec3};
use bevy_mesh::Mesh3d;
use bevy_pbr::MeshMaterial3d;
use bevy_time::Time;
use bevy_transform::components::{GlobalTransform, Transform};
use bevy_window::{PrimaryWindow, Window};
use roblue_core::{AllyMarker, FriendlyMarker, PlayerMarker};
use roblue_terrain::{Heightfield, TerrainMeshConfig};

/// Spawns the autonomous Ally companion vehicle with pre-equipped heavy turret & weapons.
pub fn spawn_ally_vehicle(
    commands: &mut Commands,
    assets: &VehicleAssets,
    player_pos: Vec3,
    hf: &Heightfield,
    water_level: f32,
) -> Entity {
    let min_dry_height = water_level + 0.35;

    // Search preferred offsets around the player to guarantee spawning strictly on dry land
    let preferred_offsets = [
        Vec2::new(-7.0, 4.5),  // Left flank (default)
        Vec2::new(7.0, 4.5),   // Right flank
        Vec2::new(0.0, 6.5),   // Rear trail
        Vec2::new(-5.5, 0.0),  // Left abeam
        Vec2::new(5.5, 0.0),   // Right abeam
        Vec2::new(0.0, -6.5),  // Vanguard front
    ];

    let mut chosen_offset = preferred_offsets[0];
    let mut found_dry_land = false;

    for offset in preferred_offsets {
        let test_x = player_pos.x + offset.x;
        let test_z = player_pos.z + offset.y;
        let test_h = hf.sample_height(test_x, test_z);

        if test_h >= min_dry_height {
            chosen_offset = offset;
            found_dry_land = true;
            break;
        }
    }

    if !found_dry_land {
        // Spiral search nearby radii if standard offsets are near coastline
        for r in (3..=20).step_by(2) {
            let radius = r as f32;
            for i in 0..16 {
                let angle = (i as f32 / 16.0) * std::f32::consts::TAU;
                let test_x = player_pos.x + angle.cos() * radius;
                let test_z = player_pos.z + angle.sin() * radius;
                let test_h = hf.sample_height(test_x, test_z);

                if test_h >= min_dry_height {
                    chosen_offset = Vec2::new(test_x - player_pos.x, test_z - player_pos.z);
                    found_dry_land = true;
                    break;
                }
            }
            if found_dry_land {
                break;
            }
        }
    }

    let start_x = player_pos.x + chosen_offset.x;
    let start_z = player_pos.z + chosen_offset.y;
    let raw_h = hf.sample_height(start_x, start_z);
    let start_y = raw_h.max(min_dry_height) + 0.65;

    let start_normal = hf.sample_normal(start_x, start_z);
    let normal_rot = Quat::from_rotation_arc(Vec3::Y, start_normal);

    // 1. Spawn Chassis Base Entity
    let ally_entity = commands
        .spawn((
            Mesh3d(assets.chassis_mesh.clone()),
            MeshMaterial3d(assets.ally_chassis_material.clone()),
            Transform::from_xyz(start_x, start_y, start_z).with_rotation(normal_rot),
            VehicleChassis {
                velocity: Vec2::ZERO,
                acceleration: 42.0,
                drag: 3.2,
                base_max_speed: 23.0,
                max_speed: 23.0,
                facing_angle: 0.0,
                turn_speed: 3.2,
                slope_penalty: 0.60,
                max_climb_angle: 0.785,
                downhill_boost: 0.35,
            },
            AllyController {
                ally_id: 0,
                formation_offset: chosen_offset,
                cruise_altitude: 0.0,
                target_world_pos: Vec3::new(start_x, start_y, start_z),
                inner_radius: 1.8,
                outer_radius: 3.6,
                is_moving: false,
                mode: AllyFormationMode::RelativePlayerAttitude,
            },
            AllyMarker,
            FriendlyMarker,
            Sockets::new(vec![
                Socket {
                    id: 0,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, 0.42, -0.3),
                    local_dir: Vec3::Y,
                    extent_angle: std::f32::consts::TAU,
                    occupied: None,
                },
                Socket {
                    id: 1,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, 0.42, 1.2),
                    local_dir: Vec3::Y,
                    extent_angle: std::f32::consts::TAU,
                    occupied: None,
                },
                Socket {
                    id: 2,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(-1.15, 0.20, -0.8),
                    local_dir: Vec3::NEG_Z,
                    extent_angle: std::f32::consts::FRAC_PI_2,
                    occupied: None,
                },
                Socket {
                    id: 3,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(1.15, 0.20, -0.8),
                    local_dir: Vec3::NEG_Z,
                    extent_angle: std::f32::consts::FRAC_PI_2,
                    occupied: None,
                },
            ]),
        ))
        .id();

    // 2. Spawn Wheels on Chassis
    const WHEEL_OFFSETS: [(f32, f32, f32, f32); 4] = [
        (-1.12, -0.12, -1.25, 0.0),
        (1.12, -0.12, -1.25, std::f32::consts::PI),
        (-1.12, -0.12, 1.25, 0.0),
        (1.12, -0.12, 1.25, std::f32::consts::PI),
    ];

    for (wx, wy, wz, yaw_rot) in WHEEL_OFFSETS {
        let wheel_rot = Quat::from_rotation_y(yaw_rot) * Quat::from_rotation_z(std::f32::consts::FRAC_PI_2);
        let wheel_id = commands
            .spawn((
                Mesh3d(assets.wheel_mesh.clone()),
                MeshMaterial3d(assets.wheel_material.clone()),
                Transform::from_xyz(wx, wy, wz).with_rotation(wheel_rot),
                VehicleWheel,
            ))
            .id();
        commands.entity(ally_entity).add_child(wheel_id);
    }

    // 3. Spawn Pre-Equipped Gear on Socket #0: Big Turret with Big Gun & Small Gun
    let turret_id = commands
        .spawn((
            Mesh3d(assets.big_turret_mesh.clone()),
            MeshMaterial3d(assets.big_turret_material.clone()),
            Transform::from_xyz(0.0, 0.42, -0.3),
            TurretTracker::new(ComponentKind::BigTurret, 2.0),
            Sockets::new(vec![
                Socket {
                    id: 0,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, 0.48, 0.0),
                    local_dir: Vec3::Y,
                    extent_angle: std::f32::consts::PI,
                    occupied: None,
                },
                Socket {
                    id: 1,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(-0.7, 0.15, 0.0),
                    local_dir: Vec3::new(-1.0, 0.0, 1.0).normalize(),
                    extent_angle: std::f32::consts::FRAC_PI_2,
                    occupied: None,
                },
                Socket {
                    id: 2,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(0.7, 0.15, 0.0),
                    local_dir: Vec3::new(1.0, 0.0, 1.0).normalize(),
                    extent_angle: std::f32::consts::FRAC_PI_2,
                    occupied: None,
                },
            ]),
        ))
        .id();

    // Attach Big Gun (Heavy Cannon) on Turret Socket #1
    let big_gun_id = commands
        .spawn((
            Mesh3d(assets.big_gun_mesh.clone()),
            MeshMaterial3d(assets.big_gun_material.clone()),
            Transform::from_xyz(-0.7, 0.15, 0.0),
            GunAutoShooter::big_gun(Vec3::NEG_Z),
        ))
        .id();
    commands.entity(turret_id).add_child(big_gun_id);

    // Attach Small Gun (Twin Autocannon) on Turret Socket #2
    let small_gun_id = commands
        .spawn((
            Mesh3d(assets.small_gun_mesh.clone()),
            MeshMaterial3d(assets.small_gun_material.clone()),
            Transform::from_xyz(0.7, 0.15, 0.0),
            GunAutoShooter::small_gun(Vec3::NEG_Z, 0.61),
        ))
        .id();
    commands.entity(turret_id).add_child(small_gun_id);

    commands.entity(ally_entity).add_child(turret_id);

    // 4. Spawn Visual Waypoint Ring on Ground
    commands.spawn((
        Mesh3d(assets.waypoint_mesh.clone()),
        MeshMaterial3d(assets.waypoint_material.clone()),
        Transform::from_xyz(start_x, start_y, start_z),
        AllyWaypointer,
    ));

    tracing::info!("Spawned autonomous pre-equipped Ground Tank Ally at ({:.1}, {:.1})", start_x, start_z);

    ally_entity
}

/// Spawns the autonomous Helicopter Gunship Ally companion vehicle with spinning rotors and underbelly chin armament.
pub fn spawn_helicopter_ally_vehicle(
    commands: &mut Commands,
    assets: &VehicleAssets,
    player_pos: Vec3,
    hf: &Heightfield,
) -> Entity {
    let chosen_offset = Vec2::new(7.5, -2.0); // Right flank forward echelon
    let start_x = player_pos.x + chosen_offset.x;
    let start_z = player_pos.z + chosen_offset.y;
    let ground_h = hf.sample_height(start_x, start_z);
    let cruise_alt = 7.5;
    let start_y = ground_h + cruise_alt;

    // 1. Spawn Helicopter Fuselage Entity
    let heli_entity = commands
        .spawn((
            Mesh3d(assets.helicopter_fuselage_mesh.clone()),
            MeshMaterial3d(assets.helicopter_material.clone()),
            Transform::from_xyz(start_x, start_y, start_z),
            FlightLocomotion {
                velocity: Vec3::ZERO,
                target_altitude: cruise_alt,
                current_altitude: cruise_alt,
                max_speed: 26.0,
                acceleration: 38.0,
                drag: 2.2,
                facing_angle: 0.0,
                turn_speed: 3.5,
                roll_angle: 0.0,
                pitch_angle: 0.0,
            },
            AllyController {
                ally_id: 1,
                formation_offset: chosen_offset,
                cruise_altitude: cruise_alt,
                target_world_pos: Vec3::new(start_x, start_y, start_z),
                inner_radius: 2.0,
                outer_radius: 4.2,
                is_moving: false,
                mode: AllyFormationMode::RelativePlayerAttitude,
            },
            AllyMarker,
            FriendlyMarker,
            Sockets::new(vec![
                Socket {
                    id: 0,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, -0.65, -0.6),
                    local_dir: Vec3::NEG_Y,
                    extent_angle: std::f32::consts::TAU,
                    occupied: None,
                },
                Socket {
                    id: 1,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(-1.25, -0.15, -0.2),
                    local_dir: Vec3::NEG_Z,
                    extent_angle: std::f32::consts::PI,
                    occupied: None,
                },
                Socket {
                    id: 2,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(1.25, -0.15, -0.2),
                    local_dir: Vec3::NEG_Z,
                    extent_angle: std::f32::consts::PI,
                    occupied: None,
                },
            ]),
        ))
        .id();

    // 2. Spawn Main Rotor Blade on Top
    let main_rotor_id = commands
        .spawn((
            Mesh3d(assets.main_rotor_mesh.clone()),
            MeshMaterial3d(assets.rotor_material.clone()),
            Transform::from_xyz(0.0, 0.72, -0.2),
            RotorBlade {
                spin_speed: 40.0,
                axis: Vec3::Y,
            },
        ))
        .id();
    commands.entity(heli_entity).add_child(main_rotor_id);

    // 3. Spawn Tail Rotor Blade
    let tail_rotor_id = commands
        .spawn((
            Mesh3d(assets.tail_rotor_mesh.clone()),
            MeshMaterial3d(assets.rotor_material.clone()),
            Transform::from_xyz(0.18, 0.35, 2.0),
            RotorBlade {
                spin_speed: 48.0,
                axis: Vec3::X,
            },
        ))
        .id();
    commands.entity(heli_entity).add_child(tail_rotor_id);

    // 4. Spawn Landing Skids
    let skids_id = commands
        .spawn((
            Mesh3d(assets.skids_mesh.clone()),
            MeshMaterial3d(assets.skids_material.clone()),
            Transform::from_xyz(0.0, -0.68, 0.0),
        ))
        .id();
    commands.entity(heli_entity).add_child(skids_id);

    // 5. Spawn Underbelly Chin Big Turret on Socket #0
    let chin_turret_id = commands
        .spawn((
            Mesh3d(assets.big_turret_mesh.clone()),
            MeshMaterial3d(assets.big_turret_material.clone()),
            Transform::from_xyz(0.0, -0.65, -0.6),
            TurretTracker::new(ComponentKind::BigTurret, 2.4),
            Sockets::new(vec![
                Socket {
                    id: 0,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(0.0, -0.25, -0.4),
                    local_dir: Vec3::NEG_Z,
                    extent_angle: std::f32::consts::TAU,
                    occupied: None,
                },
            ]),
        ))
        .id();

    // Heavy Cannon (Big Gun) attached to Chin Turret
    let chin_gun_id = commands
        .spawn((
            Mesh3d(assets.big_gun_mesh.clone()),
            MeshMaterial3d(assets.big_gun_material.clone()),
            Transform::from_xyz(0.0, -0.25, -0.4),
            GunAutoShooter::big_gun(Vec3::NEG_Z),
        ))
        .id();
    commands.entity(chin_turret_id).add_child(chin_gun_id);
    commands.entity(heli_entity).add_child(chin_turret_id);

    // 6. Spawn Wing Autocannons on Sockets #1 & #2
    let left_wing_gun = commands
        .spawn((
            Mesh3d(assets.small_gun_mesh.clone()),
            MeshMaterial3d(assets.small_gun_material.clone()),
            Transform::from_xyz(-1.25, -0.15, -0.2),
            GunAutoShooter::small_gun(Vec3::NEG_Z, 0.75),
        ))
        .id();
    commands.entity(heli_entity).add_child(left_wing_gun);

    let right_wing_gun = commands
        .spawn((
            Mesh3d(assets.small_gun_mesh.clone()),
            MeshMaterial3d(assets.small_gun_material.clone()),
            Transform::from_xyz(1.25, -0.15, -0.2),
            GunAutoShooter::small_gun(Vec3::NEG_Z, 0.75),
        ))
        .id();
    commands.entity(heli_entity).add_child(right_wing_gun);

    tracing::info!("Spawned autonomous Helicopter Gunship Ally at ({:.1}, {:.1}, {:.1})", start_x, start_y, start_z);

    heli_entity
}

/// Startup system: spawns the initial autonomous Ally squad (Ground Tank + Helicopter Gunship).
pub fn spawn_initial_ally_system(
    mut commands: Commands,
    vehicle_assets: Option<Res<VehicleAssets>>,
    terrain_config: Res<TerrainMeshConfig>,
) {
    let Some(assets) = vehicle_assets else {
        return;
    };

    let hf = Heightfield::new(terrain_config.heightfield.clone());
    let player_spawn_pos = Vec3::new(0.0, 5.0, 0.0);

    // Spawn Ground Tank Ally (#0) on left flank
    spawn_ally_vehicle(
        &mut commands,
        &assets,
        player_spawn_pos,
        &hf,
        terrain_config.palette.water_level,
    );

    // Spawn Aerial Helicopter Gunship Ally (#1) on right flank hover
    spawn_helicopter_ally_vehicle(
        &mut commands,
        &assets,
        player_spawn_pos,
        &hf,
    );
}

/// Autonomous navigation physics system for ground ally vehicles with hysteresis radius of operation.
#[allow(clippy::type_complexity)]
pub fn ally_movement_system(
    time: Res<Time>,
    terrain_config: Res<TerrainMeshConfig>,
    player_query: Query<(&Transform, &VehicleChassis), (With<PlayerMarker>, Without<AllyMarker>)>,
    mut ally_query: Query<(&mut Transform, &mut VehicleChassis, &mut AllyController), (With<AllyMarker>, Without<PlayerMarker>, Without<FlightLocomotion>)>,
) {
    let Some((player_transform, player_chassis)) = player_query.iter().next() else {
        return;
    };

    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());
    let player_pos = player_transform.translation;
    let min_land_height = terrain_config.palette.water_level + 0.25;

    for (mut ally_transform, mut chassis, mut controller) in ally_query.iter_mut() {
        // 1. Calculate Target Destination based on Active Formation Mode
        let target_xz = match controller.mode {
            AllyFormationMode::RelativePlayerAttitude => {
                let rot = Quat::from_rotation_y(player_chassis.facing_angle);
                let offset_3d = rot * Vec3::new(controller.formation_offset.x, 0.0, controller.formation_offset.y);
                Vec2::new(player_pos.x + offset_3d.x, player_pos.z + offset_3d.z)
            }
            AllyFormationMode::RelativeToNorth => {
                Vec2::new(player_pos.x + controller.formation_offset.x, player_pos.z + controller.formation_offset.y)
            }
        };

        let target_y = hf.sample_height(target_xz.x, target_xz.y);
        controller.target_world_pos = Vec3::new(target_xz.x, target_y, target_xz.y);

        let ally_pos = ally_transform.translation;
        let ally_xz = Vec2::new(ally_pos.x, ally_pos.z);
        let to_target = target_xz - ally_xz;
        let dist = to_target.length();

        // 2. Hysteresis Radius of Operation Logic
        if dist <= controller.inner_radius {
            controller.is_moving = false;
        } else if dist >= controller.outer_radius {
            controller.is_moving = true;
        }

        // 3. Autonomous Steering & Throttle Dynamics
        if controller.is_moving && dist > 0.1 {
            let desired_yaw = (-to_target.x).atan2(-to_target.y);
            let mut diff = desired_yaw - chassis.facing_angle;

            while diff < -std::f32::consts::PI {
                diff += std::f32::consts::TAU;
            }
            while diff > std::f32::consts::PI {
                diff -= std::f32::consts::TAU;
            }

            // Smoothly steer towards target
            let turn_step = diff.clamp(-chassis.turn_speed * dt, chassis.turn_speed * dt);
            chassis.facing_angle += turn_step;

            while chassis.facing_angle > std::f32::consts::PI {
                chassis.facing_angle -= std::f32::consts::TAU;
            }
            while chassis.facing_angle < -std::f32::consts::PI {
                chassis.facing_angle += std::f32::consts::TAU;
            }

            let forward_vec = Vec2::new(-chassis.facing_angle.sin(), -chassis.facing_angle.cos());

            // Alignment throttle factor (slow down on sharp corners)
            let alignment = (1.0 - (diff.abs() / std::f32::consts::PI)).clamp(0.2, 1.0);
            let throttle = (dist / 5.0).clamp(0.35, 1.0) * alignment;

            let current_normal = hf.sample_normal(ally_pos.x, ally_pos.z);
            let slope_speed_mult = if chassis.velocity.length_squared() > 0.1 {
                let vel_norm = chassis.velocity.normalize();
                let slope_grad = -(current_normal.x * vel_norm.x + current_normal.z * vel_norm.y) / current_normal.y.max(0.1);
                let slope_angle = slope_grad.atan();

                if slope_angle > 0.0 {
                    let factor = (slope_angle / chassis.max_climb_angle).clamp(0.0, 1.0);
                    (1.0 - factor * chassis.slope_penalty).max(0.25)
                } else {
                    let factor = ((-slope_angle) / chassis.max_climb_angle).clamp(0.0, 1.0);
                    1.0 + factor * chassis.downhill_boost
                }
            } else {
                1.0
            };

            chassis.max_speed = chassis.base_max_speed * slope_speed_mult;
            let effective_accel = chassis.acceleration * slope_speed_mult;

            chassis.velocity += forward_vec * (throttle * effective_accel * dt);
        }

        // 4. Tire Traction & Drag Physics
        let forward_vec = Vec2::new(-chassis.facing_angle.sin(), -chassis.facing_angle.cos());
        let fwd_speed = chassis.velocity.dot(forward_vec);
        let lat_vel = chassis.velocity - forward_vec * fwd_speed;

        let drag = chassis.drag;
        let fwd_drag = (1.0 - drag * dt).clamp(0.0, 1.0);
        let lat_drag = (1.0 - (drag * 3.5) * dt).clamp(0.0, 1.0);

        chassis.velocity = forward_vec * (fwd_speed * fwd_drag) + lat_vel * lat_drag;

        if chassis.velocity.length() > chassis.max_speed {
            chassis.velocity = chassis.velocity.normalize() * chassis.max_speed;
        }

        // 5. Water Barrier & Position Update
        let next_x = ally_pos.x + chassis.velocity.x * dt;
        let next_z = ally_pos.z + chassis.velocity.y * dt;
        let next_h = hf.sample_height(next_x, next_z);

        if next_h >= min_land_height {
            ally_transform.translation.x = next_x;
            ally_transform.translation.z = next_z;
        } else {
            chassis.velocity *= 0.2;
        }

        // 6. Terrain Normal Adherence
        let ground_y = hf.sample_height(ally_transform.translation.x, ally_transform.translation.z);
        ally_transform.translation.y = ground_y + 0.65;

        let terrain_normal = hf.sample_normal(ally_transform.translation.x, ally_transform.translation.z);
        let normal_rot = Quat::from_rotation_arc(Vec3::Y, terrain_normal);
        let yaw_rot = Quat::from_rotation_y(chassis.facing_angle);

        ally_transform.rotation = normal_rot * yaw_rot;
    }
}

/// Autonomous 3D flight navigation system for aerial ally vehicles (Helicopters, Gunships, Drones).
#[allow(clippy::type_complexity)]
pub fn ally_flight_navigation_system(
    time: Res<Time>,
    terrain_config: Res<TerrainMeshConfig>,
    player_query: Query<(&Transform, &VehicleChassis), (With<PlayerMarker>, Without<AllyMarker>)>,
    mut ally_query: Query<(&mut Transform, &mut FlightLocomotion, &mut AllyController), (With<AllyMarker>, Without<PlayerMarker>, Without<VehicleChassis>)>,
) {
    let Some((player_transform, player_chassis)) = player_query.iter().next() else {
        return;
    };

    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());
    let player_pos = player_transform.translation;

    for (mut ally_transform, mut flight, mut controller) in ally_query.iter_mut() {
        // 1. Calculate Target Destination based on Active Formation Mode
        let target_xz = match controller.mode {
            AllyFormationMode::RelativePlayerAttitude => {
                let rot = Quat::from_rotation_y(player_chassis.facing_angle);
                let offset_3d = rot * Vec3::new(controller.formation_offset.x, 0.0, controller.formation_offset.y);
                Vec2::new(player_pos.x + offset_3d.x, player_pos.z + offset_3d.z)
            }
            AllyFormationMode::RelativeToNorth => {
                Vec2::new(player_pos.x + controller.formation_offset.x, player_pos.z + controller.formation_offset.y)
            }
        };

        let target_ground_y = hf.sample_height(target_xz.x, target_xz.y).max(terrain_config.palette.water_level);
        let target_y = target_ground_y + controller.cruise_altitude;
        controller.target_world_pos = Vec3::new(target_xz.x, target_y, target_xz.y);

        let ally_pos = ally_transform.translation;
        let ally_xz = Vec2::new(ally_pos.x, ally_pos.z);
        let to_target = target_xz - ally_xz;
        let dist_xz = to_target.length();

        // 2. Hysteresis Radius of Operation
        if dist_xz <= controller.inner_radius {
            controller.is_moving = false;
        } else if dist_xz >= controller.outer_radius {
            controller.is_moving = true;
        }

        let accel = flight.acceleration;
        let drag = flight.drag;
        let max_speed = flight.max_speed;
        let target_altitude = flight.target_altitude;

        // 3. Autonomous Flight Steering & Throttle
        if controller.is_moving && dist_xz > 0.1 {
            let desired_yaw = (-to_target.x).atan2(-to_target.y);
            let mut diff = desired_yaw - flight.facing_angle;

            while diff < -std::f32::consts::PI {
                diff += std::f32::consts::TAU;
            }
            while diff > std::f32::consts::PI {
                diff -= std::f32::consts::TAU;
            }

            // Smoothly steer yaw towards destination
            let turn_step = diff.clamp(-flight.turn_speed * dt, flight.turn_speed * dt);
            flight.facing_angle += turn_step;

            while flight.facing_angle > std::f32::consts::PI {
                flight.facing_angle -= std::f32::consts::TAU;
            }
            while flight.facing_angle < -std::f32::consts::PI {
                flight.facing_angle += std::f32::consts::TAU;
            }

            let forward_vec = Vec3::new(-flight.facing_angle.sin(), 0.0, -flight.facing_angle.cos());

            let alignment = (1.0 - (diff.abs() / std::f32::consts::PI)).clamp(0.2, 1.0);
            let throttle = (dist_xz / 6.0).clamp(0.35, 1.0) * alignment;

            flight.velocity += forward_vec * (throttle * accel * dt);

            // Dynamic banking roll into turns
            let target_roll = (-diff.clamp(-0.8, 0.8) * 0.45).clamp(-0.45, 0.45);
            flight.roll_angle += (target_roll - flight.roll_angle) * (4.0 * dt).min(1.0);

            // Dynamic forward pitch tilt on acceleration
            let speed_ratio = (flight.velocity.length() / max_speed).clamp(0.0, 1.0);
            let target_pitch = -(speed_ratio * 0.28);
            flight.pitch_angle += (target_pitch - flight.pitch_angle) * (4.0 * dt).min(1.0);
        } else {
            // Level out when hovering in place
            flight.roll_angle += (0.0 - flight.roll_angle) * (3.0 * dt).min(1.0);
            flight.pitch_angle += (0.0 - flight.pitch_angle) * (3.0 * dt).min(1.0);
        }

        // 4. Air Resistance & Speed Limiting
        flight.velocity *= (1.0 - drag * dt).clamp(0.0, 1.0);
        if flight.velocity.length() > max_speed {
            flight.velocity = flight.velocity.normalize() * max_speed;
        }

        // 5. Position & Smooth Terrain-Altitude Tracking (Helicopters fly freely over water)
        ally_transform.translation.x += flight.velocity.x * dt;
        ally_transform.translation.z += flight.velocity.z * dt;

        let current_ground_y = hf.sample_height(ally_transform.translation.x, ally_transform.translation.z).max(terrain_config.palette.water_level);
        let desired_y = current_ground_y + target_altitude;
        ally_transform.translation.y += (desired_y - ally_transform.translation.y) * (3.5 * dt).min(1.0);

        // 6. Apply 3D Orientation (Yaw + Pitch + Roll)
        let yaw_rot = Quat::from_rotation_y(flight.facing_angle);
        let pitch_rot = Quat::from_rotation_x(flight.pitch_angle);
        let roll_rot = Quat::from_rotation_z(flight.roll_angle);
        ally_transform.rotation = yaw_rot * pitch_rot * roll_rot;
    }
}

/// System updating the visual holographic waypoint ring at the ally's target destination.
pub fn ally_waypoint_visual_system(
    time: Res<Time>,
    terrain_config: Res<TerrainMeshConfig>,
    ally_query: Query<&AllyController, (With<AllyMarker>, Without<AllyWaypointer>)>,
    mut waypoint_query: Query<&mut Transform, (With<AllyWaypointer>, Without<AllyMarker>)>,
) {
    let Some(controller) = ally_query.iter().next() else {
        return;
    };
    let Some(mut wp_transform) = waypoint_query.iter_mut().next() else {
        return;
    };

    let dt = time.delta_secs();
    let hf = Heightfield::new(terrain_config.heightfield.clone());

    let target = controller.target_world_pos;
    let ground_y = hf.sample_height(target.x, target.z);
    let terrain_normal = hf.sample_normal(target.x, target.z);

    wp_transform.translation = Vec3::new(target.x, ground_y + 0.12, target.z);
    let normal_rot = Quat::from_rotation_arc(Vec3::Y, terrain_normal);
    wp_transform.rotation = normal_rot;
    wp_transform.rotate_local_y(1.2 * dt);
}

/// Mouse drag interaction: Left-click drag on the terrain updates the ally squad's target destinations.
pub fn ally_command_system(
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    windows: Query<&Window, With<PrimaryWindow>>,
    cameras: Query<(&Camera, &GlobalTransform)>,
    terrain_config: Res<TerrainMeshConfig>,
    mut command_state: ResMut<AllyCommandState>,
    player_query: Query<(&Transform, &VehicleChassis), With<PlayerMarker>>,
    mut ally_query: Query<&mut AllyController, With<AllyMarker>>,
) {
    let Ok(window) = windows.single() else {
        return;
    };
    let cursor_pos: Vec2 = match window.cursor_position() {
        Some(pos) => pos,
        None => return,
    };
    let Some((camera, cam_global_trans)) = cameras.iter().next() else {
        return;
    };
    let Some((player_transform, player_chassis)) = player_query.iter().next() else {
        return;
    };

    let Ok(ray) = camera.viewport_to_world(cam_global_trans, cursor_pos) else {
        return;
    };

    let hf = Heightfield::new(terrain_config.heightfield.clone());

    // Approximate raycast onto ground heightfield
    let ground_hit = raycast_heightfield(&ray, &hf, terrain_config.palette.water_level);

    command_state.current_ground_hit = ground_hit;

    if mouse_buttons.just_pressed(MouseButton::Left) {
        command_state.drag_start_pos = Some(cursor_pos);
        command_state.is_dragging = false;
    }

    if mouse_buttons.pressed(MouseButton::Left) {
        if let Some(start_pos) = command_state.drag_start_pos
            && (cursor_pos - start_pos).length() > 6.0
        {
            command_state.is_dragging = true;
        }

        if command_state.is_dragging
            && let Some(hit) = ground_hit
        {
            let ground_h = hf.sample_height(hit.x, hit.z);
            // Ensure target formation is strictly on dry land
            if ground_h >= terrain_config.palette.water_level + 0.25 {
                let player_pos = player_transform.translation;
                let delta = hit - player_pos;

                for mut ally in ally_query.iter_mut() {
                    let squad_offset = if ally.ally_id == 0 {
                        Vec2::new(-2.5, 1.5) // Left flank for Tank
                    } else {
                        Vec2::new(3.0, -1.5) // Right flank for Helicopter
                    };

                    match ally.mode {
                        AllyFormationMode::RelativePlayerAttitude => {
                            let rot_inv = Quat::from_rotation_y(-player_chassis.facing_angle);
                            let local_3d = rot_inv * delta;
                            let base_offset = Vec2::new(local_3d.x, local_3d.z);
                            ally.formation_offset = (base_offset + squad_offset).clamp_length(2.5, 45.0);
                        }
                        AllyFormationMode::RelativeToNorth => {
                            let base_offset = Vec2::new(delta.x, delta.z);
                            ally.formation_offset = (base_offset + squad_offset).clamp_length(2.5, 45.0);
                        }
                    }
                }
            }
        }
    }

    if mouse_buttons.just_released(MouseButton::Left) {
        command_state.is_dragging = false;
        command_state.drag_start_pos = None;
    }
}

/// Helper function to raycast from camera ray onto the heightfield surface.
fn raycast_heightfield(ray: &Ray3d, hf: &Heightfield, water_level: f32) -> Option<Vec3> {
    let mut current = ray.origin;
    let dir = ray.direction.as_vec3();

    if dir.y >= 0.0 {
        return None;
    }

    const STEPS: usize = 64;
    const STEP_SIZE: f32 = 1.6;

    for _ in 0..STEPS {
        current += dir * STEP_SIZE;
        let ground_y = hf.sample_height(current.x, current.z).max(water_level);

        if current.y <= ground_y {
            return Some(Vec3::new(current.x, ground_y, current.z));
        }
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ally_controller_defaults() {
        let ally = AllyController::default();
        assert_eq!(ally.formation_offset, Vec2::new(-6.5, 4.0));
        assert_eq!(ally.inner_radius, 1.8);
        assert_eq!(ally.outer_radius, 3.6);
        assert!(!ally.is_moving);
        assert_eq!(ally.mode, AllyFormationMode::RelativePlayerAttitude);
    }

    #[test]
    fn test_multi_ally_controller_configurations() {
        let tank_ally = AllyController {
            ally_id: 0,
            formation_offset: Vec2::new(-7.0, 4.5),
            cruise_altitude: 0.0,
            ..Default::default()
        };
        assert_eq!(tank_ally.ally_id, 0);
        assert_eq!(tank_ally.cruise_altitude, 0.0);

        let heli_ally = AllyController {
            ally_id: 1,
            formation_offset: Vec2::new(7.5, -2.0),
            cruise_altitude: 7.5,
            ..Default::default()
        };
        assert_eq!(heli_ally.ally_id, 1);
        assert_eq!(heli_ally.cruise_altitude, 7.5);
    }
}
