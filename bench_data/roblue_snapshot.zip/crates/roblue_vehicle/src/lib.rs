pub mod ally;
pub mod components;
pub mod models;
pub mod systems;

pub use ally::{
    ally_command_system, ally_flight_navigation_system, ally_movement_system,
    ally_waypoint_visual_system, spawn_ally_vehicle, spawn_helicopter_ally_vehicle,
    spawn_initial_ally_system,
};
pub use components::{
    AllyCommandState, AllyController, AllyFormationMode, AllyWaypointer, ComponentKind,
    FlightLocomotion, GunAutoShooter, PickupItem, PlayerVehicle, RotorBlade, Socket, SocketKind,
    Sockets, TurretTracker, VehicleAssets, VehicleChassis, VehicleWheel,
};
pub use models::*;
pub use systems::*;

use bevy_app::prelude::*;
use bevy_ecs::schedule::IntoScheduleConfigs;

/// Plugin registering modular vehicle assets, physics driving, sockets, tracking, auto-firing, and ally companion AI.
pub struct RoblueVehiclePlugin;

impl Plugin for RoblueVehiclePlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(
            Startup,
            (
                setup_vehicle_assets,
                spawn_initial_pickups_system,
                spawn_initial_ally_system,
            )
                .chain(),
        )
            .add_systems(
                Update,
                (
                    vehicle_movement_system,
                    ally_movement_system,
                    ally_flight_navigation_system,
                    rotor_animation_system,
                    ally_waypoint_visual_system,
                    ally_command_system,
                    pickup_animation_system,
                    pickup_collection_and_attachment_system,
                    turret_and_gun_tracking_system,
                    gun_auto_fire_system,
                ),
            );
    }
}
