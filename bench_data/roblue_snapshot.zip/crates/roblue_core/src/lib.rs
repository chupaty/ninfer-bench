//! Core data types, states, components, and events for Roblue.

use bevy_ecs::prelude::*;
use bevy_math::Vec3;
use bevy_reflect::Reflect;
use bevy_state::prelude::*;
use serde::{Deserialize, Serialize};

/// Global high-level game state.
#[derive(States, Default, Debug, Clone, Copy, PartialEq, Eq, Hash, Reflect, Serialize, Deserialize)]
pub enum GameState {
    #[default]
    Loading,
    InGame,
    Paused,
    GameOver,
}

/// Dimensional mode: 2D Orthographic horde mode vs 3D Perspective action mode.
#[derive(Resource, Debug, Clone, Copy, PartialEq, Reflect, Serialize, Deserialize)]
pub enum DimensionMode {
    /// 2D Orthographic top-down mode with planar horde simulation.
    TwoD { ortho_scale: f32 },
    /// Active transition between modes (smooth camera interpolation).
    Transitioning { progress: f32, duration: f32 },
    /// 3D Perspective mode with full depth and verticality.
    ThreeD { fov_degrees: f32, pitch: f32 },
}

impl Default for DimensionMode {
    fn default() -> Self {
        DimensionMode::TwoD { ortho_scale: 1.0 }
    }
}

/// Simulation position in unified 3D coordinates (ground plane is XZ, elevation is Y).
#[derive(Component, Debug, Clone, Copy, PartialEq, Reflect, Default)]
pub struct SimPosition(pub Vec3);

/// Simulation velocity vector.
#[derive(Component, Debug, Clone, Copy, PartialEq, Reflect, Default)]
pub struct SimVelocity(pub Vec3);

/// Health component for combat entities.
#[derive(Component, Debug, Clone, Copy, PartialEq, Reflect)]
pub struct Health {
    pub current: f32,
    pub max: f32,
}

impl Health {
    pub fn new(max: f32) -> Self {
        Self { current: max, max }
    }

    pub fn is_dead(&self) -> bool {
        self.current <= 0.0
    }

    pub fn take_damage(&mut self, amount: f32) {
        self.current = (self.current - amount).max(0.0);
    }
}

/// Bounding sphere hitbox for broad-phase spatial checks.
#[derive(Component, Debug, Clone, Copy, PartialEq, Reflect)]
pub struct HitboxRadius(pub f32);

/// Marker component for player entity.
#[derive(Component, Debug, Default, Clone, Copy, Reflect)]
pub struct PlayerMarker;

/// Marker component for autonomous ally vehicle entities.
#[derive(Component, Debug, Default, Clone, Copy, Reflect)]
pub struct AllyMarker;

/// Marker component for all friendly combatants (Player & Ally), used by enemy swarm targeting.
#[derive(Component, Debug, Default, Clone, Copy, Reflect)]
pub struct FriendlyMarker;

/// Marker component for horde enemy entities.
#[derive(Component, Debug, Default, Clone, Copy, Reflect)]
pub struct EnemyMarker;
