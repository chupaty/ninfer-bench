use bevy::prelude::*;
use roblue_audio::RoblueAudioPlugin;
use roblue_core::*;
use roblue_enemy::RoblueEnemyPlugin;
use roblue_player::*;
use roblue_terrain::*;
use roblue_vehicle::*;
use roblue_weapon::*;

fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "Roblue - Goal 4: Autonomous Ally Companion | Mouse Drag Formation | Auto-Tracking Horde Combat".into(),
                resolution: (1280, 720).into(),
                ..default()
            }),
            ..default()
        }))
        .init_state::<GameState>()
        .add_plugins((
            TerrainPlugin,
            RobluePlayerPlugin,
            RoblueEnemyPlugin,
            RoblueWeaponPlugin,
            RoblueVehiclePlugin,
            RoblueAudioPlugin,
        ))
        .add_systems(Startup, setup)
        .run();
}

fn setup(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    terrain_config: Res<TerrainMeshConfig>,
) {
    // 1. Directional Sun Light
    commands.spawn((
        DirectionalLight {
            illuminance: 16_000.0,
            shadows_enabled: true,
            ..default()
        },
        Transform::from_xyz(40.0, 60.0, 40.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));

    // 2. Generate and spawn procedural terrain mesh
    let terrain_mesh = TerrainBuilder::build_terrain_mesh(&terrain_config);
    commands.spawn((
        Mesh3d(meshes.add(terrain_mesh)),
        MeshMaterial3d(materials.add(StandardMaterial {
            perceptual_roughness: 0.85,
            ..default()
        })),
        Transform::IDENTITY,
    ));

    // 3. Generate and spawn transparent water plane
    let water_mesh = TerrainBuilder::build_water_plane_mesh(
        terrain_config.width_cells as f32 * terrain_config.cell_size,
        terrain_config.depth_cells as f32 * terrain_config.cell_size,
        terrain_config.palette.water_level,
    );
    commands.spawn((
        Mesh3d(meshes.add(water_mesh)),
        MeshMaterial3d(materials.add(StandardMaterial {
            base_color: Color::srgba(0.1, 0.4, 0.75, 0.75),
            alpha_mode: AlphaMode::Blend,
            perceptual_roughness: 0.1,
            ..default()
        })),
        Transform::IDENTITY,
    ));

    // 4. Spawn Player Vehicle Chassis (Modular Base with 4 Wheels & Sockets)
    let chassis_mesh = meshes.add(build_chassis_mesh());
    let chassis_mat = materials.add(StandardMaterial {
        base_color: Color::srgb(0.18, 0.38, 0.65),
        perceptual_roughness: 0.35,
        metallic: 0.7,
        ..default()
    });

    let wheel_mesh = meshes.add(build_wheel_mesh());
    let wheel_mat = materials.add(StandardMaterial {
        base_color: Color::srgb(0.08, 0.08, 0.09),
        perceptual_roughness: 0.9,
        ..default()
    });

    let player_id = commands
        .spawn((
            Mesh3d(chassis_mesh),
            MeshMaterial3d(chassis_mat),
            Transform::from_xyz(0.0, 5.0, 0.0),
            PlayerMarker,
            FriendlyMarker,
            PlayerVehicle,
            VehicleChassis::default(),
            BurstShooter::default(),
            Sockets::new(vec![
                Socket {
                    id: 0,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, 0.55, 0.0),
                    local_dir: Vec3::Y,
                    extent_angle: std::f32::consts::PI,
                    occupied: None,
                },
                Socket {
                    id: 1,
                    kind: SocketKind::Mount,
                    local_pos: Vec3::new(0.0, 0.45, -1.1),
                    local_dir: Vec3::Y,
                    extent_angle: std::f32::consts::PI,
                    occupied: None,
                },
                Socket {
                    id: 2,
                    kind: SocketKind::Gun,
                    local_pos: Vec3::new(0.0, 0.25, 1.4),
                    local_dir: Vec3::Z,
                    extent_angle: 1.05,
                    occupied: None,
                },
            ]),
        ))
        .with_children(|parent| {
            let wheel_rot = Quat::from_rotation_z(std::f32::consts::FRAC_PI_2);
            let wheel_positions = [
                Vec3::new(-1.15, -0.15, 1.1),
                Vec3::new(1.15, -0.15, 1.1),
                Vec3::new(-1.15, -0.15, -1.1),
                Vec3::new(1.15, -0.15, -1.1),
            ];
            for pos in wheel_positions {
                parent.spawn((
                    Mesh3d(wheel_mesh.clone()),
                    MeshMaterial3d(wheel_mat.clone()),
                    Transform::from_translation(pos).with_rotation(wheel_rot),
                    VehicleWheel,
                ));
            }
        })
        .id();

    // 5. Spawn Directional Chase 3D Perspective Camera Tracking Vehicle
    commands.spawn((
        Camera3d::default(),
        SmoothFollowCamera {
            target: Some(player_id),
            distance: 26.0,
            height: 16.0,
            pos_smoothness: 8.0,
            rot_smoothness: 4.5,
            look_at_offset: Vec3::new(0.0, 1.2, 0.0),
            current_yaw: 0.0,
        },
        Transform::from_xyz(0.0, 20.0, 30.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));

    // 6. Spawn Glowing Mouse Aim Reticle (Projects cursor onto 3D terrain)
    let reticle_mesh = meshes.add(Cylinder::new(0.45, 0.06));
    let reticle_mat = materials.add(StandardMaterial {
        base_color: Color::srgba(1.0, 0.35, 0.15, 0.9),
        emissive: LinearRgba::new(0.9, 0.3, 0.1, 1.0),
        unlit: true,
        ..default()
    });
    commands.spawn((
        Mesh3d(reticle_mesh),
        MeshMaterial3d(reticle_mat),
        Transform::from_xyz(0.0, 1.0, 0.0),
        AimReticle,
    ));

    info!("Roblue Goal 3 initialized with modular stackable vehicles and auto-tracking weapon trees.");
}

