# Roblue: Goal 1 (G1) Specification

## Objective
Establish the **"Minimum Playable Character"** slice:
1. A player entity traversing procedural 3D terrain using traditional **WASD** and **Mouse Aiming**.
2. **Heightfield Adherence**: Player position dynamically snaps to the terrain elevation $Y = \text{height}(X, Z)$.
3. **Smooth Follow Camera**: 3D Perspective camera trailing behind and above the player.
4. **Audio Support**: Working audio pipeline triggering sounds on movement/actions.

---

## Architecture Breakdown

### 1. `crates/roblue_player`
* **Components**:
  * `PlayerController { move_speed: f32, facing_angle: f32 }`: Player state and movement speeds.
  * `SmoothFollowCamera { target: Entity, offset: Vec3, smoothness: f32 }`: Camera rig tracking the player.
  * `FootstepAudioTimer { timer: Timer }`: Emits audio events during continuous movement.
* **Systems**:
  * `player_input_system`: Collects WASD keyboard inputs.
  * `player_movement_and_terrain_system`: Translates player and samples terrain height.
  * `camera_follow_system`: Smoothly interpolates camera position toward player position.
  * `mouse_aim_system`: Projects cursor ray onto ground plane to orient player.

### 2. `crates/roblue_audio`
* **Events**: `PlaySfxEvent { sound: SfxKind, volume: f32 }`
* **Systems**: `audio_event_listener_system` playing audio via Bevy's audio engine.
