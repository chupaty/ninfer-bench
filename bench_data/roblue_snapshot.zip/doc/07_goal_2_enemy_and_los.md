# Roblue: Goal 2 (G2) Specification - Bearded Orc Sprite Horde & Terrain Line-of-Sight

## 1. Objective
1. **Bearded Orc Sprite**: 64x64 procedural pixel-art sprite with green skin, horns, tusks, and a braided brown beard.
2. **Perspective Billboard Quad**: Rendered as a 3D billboarded sprite quad ($1.8 \times 1.8$ units) always facing the active perspective camera.
3. **Terrain Line-of-Sight (LOS) Occlusion**:
   * The orc is **only visible if the player pill has direct line-of-sight**.
   * Raycast between player eye and orc center samples the terrain heightfield along the path. If a hill or ridge blocks the line, the orc is set to `Visibility::Hidden`.
4. **Swarm AI & Contact Death**:
   * Orcs constantly move toward the player along the terrain surface slope.
   * Touching the player causes the orc to "die" (despawn with sound effect).
5. **Mass Spawner**:
   * Left-clicking the mouse generates **100 orcs** across the island map.

---

## 2. Terrain Line-of-Sight Algorithm

```
  Player Pill (Eye) ───────────────────────────────> Bearded Orc
        (Xp, Yp)                   \                     (Xe, Ye)
                                    \
                                  [ Hill Crest ]  <── If Terrain Y > Ray Y:
                                  (Occlusion!)        Set Visibility::Hidden
```

For $N = 10$ steps along line segment $t \in [0.1, 0.9]$:
$$X(t) = X_p + t(X_e - X_p), \quad Z(t) = Z_p + t(Z_e - Z_p)$$
$$Y_{\text{ray}}(t) = Y_p + t(Y_e - Y_p)$$
If $\text{Heightfield}(X(t), Z(t)) > Y_{\text{ray}}(t)$, LOS is blocked.
