# 09 - Goal 3: Stackable Modular Vehicles & Weapon Trees

## 1. High Concept & Vision
Goal 3 elevates *Roblue* from single-character combat into a modular, stacking vehicle builder. The player operates an armored wheeled vehicle chassis traversing the 3D heightfield island with physics-based momentum. Loose vehicle modules and weapons appear across the terrain. Driving over compatible modules snaps them into the closest available sockets on the vehicle tree, forming towering, multi-tiered battle configurations that independently acquire targets and auto-fire.

```mermaid
graph TD
    subgraph "Vehicle Assembly Hierarchy"
        C[Vehicle Chassis Base<br/>WASD Momentum + Terrain Alignment]
        C -->|Mount Socket 0: Top Deck| BT[Big Turret<br/>1.5 rad/s Yaw Rate]
        C -->|Mount Socket 1: Rear Deck| ST1[Small Turret<br/>4.0 rad/s Yaw Rate]
        C -->|Gun Socket 2: Front Bumper| SG1[Small Autocannon<br/>60 deg Forward Arc]
        BT -->|Mount Socket 0: Top| ST2[Small Turret]
        BT -->|Gun Socket 1: Left Sponson| BG[Big Cannon<br/>3.0 DMG, 0.8s CD]
        BT -->|Gun Socket 2: Right Sponson| SG2[Small Autocannon]
        ST1 -->|Gun Socket 0| SG3[Small Autocannon]
        ST2 -->|Gun Socket 0| SG4[Small Autocannon]
    end
```

---

## 2. Component Specifications

### A. Vehicle Base (Chassis)
- **Physics**: W/S throttle ($a = 38.0\text{ u/s}^2$) + A/D steering with momentum ($d = 3.2$), base max velocity $22.0\text{ u/s}$.
- **Steering Tuning**: Softened `turn_speed = 2.6\text{ rad/s}` ($150^\circ/\text{sec}$) with tire traction physics (high forward grip, controlled lateral drift).
- **Directional Chase Camera**: Camera stays behind the vehicle heading with smoothed yaw tracking.
- **Terrain Alignment**: Surface normal sampling to pitch and roll across hills and ridges.
- **Slope Speed Scaling (Per-Vehicle Parameters)**:
  - `base_max_speed`: $22.0\text{ u/s}$
  - `slope_penalty`: $0.65$ (uphill resistance reduces top speed and acceleration)
  - `max_climb_angle`: $0.785\text{ rad}$ ($45^\circ$)
  - `downhill_boost`: $+30\%$ speed bonus when rolling down slopes.
- **Water Boundary Barrier**: Movement into water ($\text{height} \le \text{water\_level} + 0.2$) is strictly prohibited, smoothly sliding vehicles along coastlines.
- **Wheels**: 4 treaded wheel hubs positioned at chassis corners.
- **Sockets**:
  - `MountPoint 0` (Top Deck, $(0.0, 0.55, 0.0)$, Up: $+Y$)
  - `MountPoint 1` (Rear Deck, $(0.0, 0.45, -1.1)$, Up: $+Y$)
  - `GunPoint 2` (Front Bumper, $(0.0, 0.25, 1.3)$, Forward: $+Z$, Arc: $\pm 60^\circ$)

### B. Big Turret (Ruby Crimson)
- **Role**: Heavy rotating platform slaved to the horizontal azimuth of its mounted Big Gun.
- **Tracking Rate**: $1.5\text{ rad/s}$ (heavy rotational inertia).
- **Targeting Heuristic**: **Least Time to Acquire Aim** within range ($38\text{m}$). Evaluates relative yaw traverse time $t_{\text{yaw}} = \frac{|\Delta \text{yaw}|}{\omega_{\text{turret}}}$ and prioritizes targets that can be aligned in the minimal angular time.
- **Sockets**:
  - `MountPoint 0` (Top Deck, $(0.0, 0.5, 0.0)$, Up: $+Y$)
  - `GunPoint 1` (Left Sponson, $(-0.65, 0.2, 0.0)$, Normal: Left, Arc: $\pm 90^\circ$)
  - `GunPoint 2` (Right Sponson, $(0.65, 0.2, 0.0)$, Normal: Right, Arc: $\pm 90^\circ$)

### C. Small Turret (Amethyst Purple)
- **Role**: Agile rotating platform for rapid gun alignment.
- **Tracking Rate**: $4.0\text{ rad/s}$.
- **Targeting Heuristic**: **Closest Euclidean Distance** (unchanged).
- **Sockets**:
  - `GunPoint 0` (Top Mount, $(0.0, 0.35, 0.0)$, Forward: $+Z$, Arc: $360^\circ$)
  - `GunPoint 1` (Side Mount, $(0.35, 0.2, 0.0)$, Forward: $+Z$, Arc: $\pm 90^\circ$)

### D. Big Gun (Heavy Cannon - Amber Gold)
- **Kinematics**: **Vertical elevation pitch only** ($\phi \in [-8^\circ, +31.5^\circ]$). Local yaw is fixed at $0^\circ$ relative to mount; horizontal azimuth is delegated to the parent Big Turret.
- **Tracking Rate**: $3.5\text{ rad/s}$ vertical pitch.
- **Targeting Heuristic**: **Least Time to Acquire Aim** ($t_{\text{acquire}} = \max(t_{\text{pitch}}, t_{\text{yaw}})$) within $36.0\text{m}$ range and available elevation limits.
- **Damage**: $3.0$ (instant 1-hit kill with explosive blast and "puchu" sound).
- **Cooldown**: $1.80\text{s}$.
- **Range**: $36.0$ world units.
- **Firing Rule**: Auto-fires when both parent turret azimuth ($\Delta \text{yaw} < 14^\circ$) and barrel elevation ($\Delta \text{pitch} < 12^\circ$) are on target.

### E. Small Gun (Twin Autocannon - Neon Cyan)
- **Kinematics**: **3D Spherical Conical Gimbal Tracking** ($\pm 35^\circ$ cone).
- **Tracking Rate**: $8.5\text{ rad/s}$.
- **Targeting Heuristic**: **Closest Euclidean Distance** within $25.0\text{m}$ range (unchanged).
- **Damage**: $1.0$ (instant kill on direct hit).
- **Cooldown**: $0.14\text{s}$.
- **Range**: $25.0$ world units.
- **Firing Rule**: Auto-fires when aimed within conical tolerance ($< 17^\circ$).

---

## 3. Terrain Plateau Shaping & Dry Land Guarantees
- **Plateau Transfer Function**: Central noise elevations are smoothed via a non-linear plateau curve, generating broad, flat plains ideal for high-speed vehicle maneuvers while retaining scenic hills and coastal slopes.
- **Dry Land Guarantees**: Pickups and enemy orcs only spawn on dry land ($h \ge \text{water\_level} + 0.35$), preventing inaccessible items or submerged foes.

---

## 4. World Economy & Pickup Rules
- **Constant Field Pool**: Exactly **5 of each component** (5 Big Turrets, 5 Small Turrets, 5 Big Guns, 5 Small Guns = 20 total) exist on the map at all times.
- **Visual Indicator**: Floating, rotating items with glowing colored halos and vertical beacon light.
- **Attachment Rule**:
  - Guns attach only to `GunPoint` sockets.
  - Turrets attach only to `MountPoint` sockets.
  - Sockets attach to the closest available open socket across the entire vehicle hierarchy tree.
  - If no compatible socket is open, the pickup is ignored.
- **Respawn**: Collecting an item immediately triggers a respawn of that component type on valid dry terrain.

