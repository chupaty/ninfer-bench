# Roblue: Goals & Implementation Roadmap

## Milestone 1: Procedural Island Terrain & Water (Goal 1 - Completed)
- [x] Procedural island generation via 2D Simplex noise and analytical normals.
- [x] Biome coloring (underwater shelf, sand, grass, rock, mountain snow).
- [x] Infinite water plane mesh with depth-based color grading and water level snapping.

## Milestone 2: 2D Sprite Horde & LOS Occlusion (Goal 2 - Completed)
- [x] Procedural pixel-art bearded Orc enemy sprites.
- [x] Raycasted terrain line-of-sight (LOS) occlusion hiding enemies behind ridges.
- [x] Swarm AI tracking nearest friendly units across heightfields.
- [x] Right-click 100-Orc horde spawner for combat testing.

## Milestone 3: Modular Stackable Vehicles & Audio (Goal 3 - Completed)
- [x] Hierarchical socket attachment system (`Mount` and `Gun` sockets).
- [x] Heavy chassis base, Big Turrets, Small Turrets, Heavy Cannons, Twin Autocannons.
- [x] Kinematic auto-targeting with least-time-to-acquire heuristics.
- [x] Procedural synthesized audio engine ("puchu" blast, action clicks, explosion booms).
- [x] Projectile collisions, terrain blasts, and enemy kills.

## Milestone 4: Multi-Archetype Locomotion & Aerial Helicopter Ally (Goal 4 - Completed)
- [x] Decoupled locomotion (`VehicleChassis` ground driving & `FlightLocomotion` 3D rotorcraft).
- [x] Pre-equipped Ground Tank Ally and Aerial Helicopter Gunship Ally.
- [x] Animated spinning main and tail rotor blades with banking roll and pitch tilt.
- [x] Underbelly chin turret with downward elevation depression to rain fire from above.
- [x] Interactive mouse-drag terrain command interface with holographic waypoint ring.

## Milestone 5: Modular Mech Combiner & Vehicle Fusion (Goal 5 - Tentative)
- [ ] `SocketKind::ChassisDock` for sub-vehicle docking (dorsal flight mounts, flank tread pods, walker legs).
- [ ] Magnetic docking / undocking state machine with animated latching (`F` key toggle).
- [ ] Jump-Jet thruster lift (`Space` key): docked helicopter rotors provide vertical boost to hover/jump across terrain and water.
- [ ] Unified weapon battery: simultaneous synchronized firing across all docked ally turrets and cannons.
- [ ] Procedural combiner visuals (magnetic energy beams) and mechanical latch SFX.

