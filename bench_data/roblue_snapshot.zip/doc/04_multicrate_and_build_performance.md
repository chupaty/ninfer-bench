# Roblue: Multi-Crate Architecture & Build Performance Strategy

To guarantee near-instant incremental compilation (< 1.0s) and clean separation of concerns, Roblue is structured as a modular multi-crate workspace.

---

## 1. Crate Hierarchy & Dependency Graph

```
                            ┌──────────────┐
                            │  roblue_app  │  (Thin Binary Entrypoint)
                            └──────┬───────┘
           ┌──────────────┬────────┼──────────────┬──────────────┐
           ▼              ▼        ▼              ▼              ▼
     ┌───────────┐  ┌───────────┐ ┌────────────┐ ┌───────────┐ ┌───────────┐
     │ roblue_ui │  │roblue_game│ │roblue_rende│ │roblue_came│ │roblue_data│
     └─────┬─────┘  └─────┬─────┘ └─────┬──────┘ └─────┬─────┘ └─────┬─────┘
           │              │             │              │             │
           │              ▼             │              │             │
           │        ┌───────────┐       │              │             │
           │        │roblue_spat│       │              │             │
           │        └─────┬─────┘       │              │             │
           └──────────────┼─────────────┴──────────────┴─────────────┘
                          ▼
                   ┌─────────────┐
                   │ roblue_core │  (Pure Math, IDs, Components, Events)
                   └─────────────┘
```

---

## 2. Crate Responsibilities

| Crate | Primary Focus | Key Dependencies | Compile Time Impact |
| :--- | :--- | :--- | :--- |
| **`roblue_core`** | Enums (`GameState`, `DimensionMode`), ECS base components (`Position`, `Velocity`, `Health`, `Hitbox`), events (`DamageEvent`, `ShiftTriggerEvent`). | `bevy_ecs`, `bevy_math`, `bevy_reflect`, `serde` | **Extremely Fast (<0.3s)**; rarely modified once core math is settled. |
| **`roblue_spatial`** | Spatial Hash Grid (`SpatialGrid`), broad-phase radius queries, neighbor bucketing for 5,000+ entities. | `roblue_core`, `bevy_ecs`, `bevy_math` | Fast (<0.5s); independent of rendering. |
| **`roblue_data`** | Data-driven definitions for Weapons, Waves, Enemies, Upgrades. RON/JSON loaders & schema validation. | `roblue_core`, `serde`, `ron`, `bevy_asset` | Isolated from gameplay logic. |
| **`roblue_camera`** | Dual-mode camera rig, continuous orthographic $\leftrightarrow$ perspective blending, camera follow, screen shake. | `roblue_core`, `bevy_camera`, `bevy_transform`, `bevy_render` | Independent visual math. |
| **`roblue_gameplay`** | Player movement controller, swarm AI, auto-attack weapons, projectiles, collisions, XP gems, level-up logic. | `roblue_core`, `roblue_spatial`, `roblue_data`, `bevy_time`, `bevy_sprite` | Iterated heavily; compiles in parallel without touching other layers. |
| **`roblue_render`** | 3D player mesh rendering, 2D sprite billboarding shaders, particle emitters, dimensional transition visual FX, dynamic lighting. | `roblue_core`, `roblue_camera`, `bevy_pbr`, `bevy_gltf` | Isolated render pipeline logic. |
| **`roblue_ui`** | HUD (Health/XP bars, kill counters, wave timer), 3-card level-up selection modal, pause menu, DPS metrics. | `roblue_core`, `bevy_ui`, `bevy_text` | Isolated UI layout. |
| **`roblue_app`** | Root executable. Assembles all crate plugins into `App::new()` and launches the engine. | All workspace crates, `bevy` | **< 0.5s relink** with `rust-lld`. |

---

## 3. Build & Link Optimization Arsenal

### A. Fast Linker: `rust-lld.exe` (Configured)
* Located in `.cargo/config.toml`.
* Replaces the default Windows MSVC `link.exe`, slashing incremental link times from ~15s to **< 0.5s**.

### B. Bevy Dynamic Linking (`dynamic_linking` feature)
* In dev mode, Bevy can be dynamically linked as a shared DLL (`bevy.dll`).
* Code changes in `roblue_gameplay` only recompile that single crate and link against the pre-built DLL.

### C. Workspace Profile Strategy (`Cargo.toml`)
```toml
# Fast debug builds with playable framerate
[profile.dev]
opt-level = 1

# Max optimization for external dependencies (wgpu, bevy, hashbrown)
[profile.dev.package."*"]
opt-level = 3

# Fast release builds with thin LTO
[profile.release]
opt-level = 3
lto = "thin"
codegen-units = 1
```

### D. Sub-crate Bevy Feature Isolation
Instead of pulling the entire monolithic `bevy` crate into every library:
* Lower-level crates (`roblue_core`, `roblue_spatial`) only pull lightweight modules (`bevy_ecs`, `bevy_math`), keeping their dependency trees tiny.
* Heavy rendering features (`bevy_pbr`, `bevy_gltf`, `wgpu`) are confined to `roblue_render` and `roblue_app`.

---

## 4. Hot-Reloading for Non-Code Changes
* **RON Data Assets (`weapons.ron`, `waves.ron`)**: Changes to weapon damage, attack speed, or wave spawn counts reload live via Bevy's asset server without requiring a recompile.
