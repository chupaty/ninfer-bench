# 10 - Goal 4: Autonomous Ally Companion, Multi-Archetype Locomotion & Aerial Helicopter Gunship

## 1. Overview
Goal 4 introduces a scalable, multi-archetype autonomous **Ally Companion Squad** (Ground Tank & Aerial Helicopter Gunship) operating alongside the player. The system cleanly decouples high-level tactical AI navigation (`AllyController`, formation offsets, hysteresis deadzones, mouse drag repositioning) from low-level physics locomotion (`VehicleChassis` ground driving and `FlightLocomotion` 3D rotorcraft dynamics), designed to support tanks, cars, bikes, helicopters, planes, watercraft, hovercraft, and humanoids for both AI companions and the player vehicle.

```mermaid
graph TD
    A[Player Heading & Position] -->|Formation Offsets| B[Target Destinations on Terrain]
    C[Mouse Left-Drag on Terrain] -->|Raycast & Squad Echelon Projection| B
    B --> D1[Ally #0 Tank: VehicleChassis]
    B --> D2[Ally #1 Helicopter: FlightLocomotion]
    D1 -->|Dist > 3.6m Outer Radius| E1[Ground Navigation: Steering, Terrain Adherence & Shorelines]
    D2 -->|Dist > 4.2m Outer Radius| E2[Flight Navigation: Banking Roll, Pitch Tilt, 7.5m Hover Altitude]
    E2 --> F[Rotor Animation: Main Rotor 40 rad/s, Tail Rotor 48 rad/s]
    G[Enemy Swarm AI] -->|Find Nearest| H[Target Closest Friendly: Player, Tank, or Helicopter]
    I[Underbelly Chin Turret & Wing Guns] -->|Downward Depression & Least-Time Aim| J[Rain Fire Down on Horde Swarms]
```

---

## 2. Core Specifications & Architectures

### 1. Multi-Archetype Locomotion Decoupling
- **`VehicleChassis` (Ground Vehicles / Tanks / Cars / Bikes)**:
  - 2D ground plane velocity, steering yaw, tire traction, terrain normal slope penalty/boost, and water shoreline collision barrier.
- **`FlightLocomotion` (Rotorcraft / Helicopters / Drones / Aircraft)**:
  - 3D flight velocity, hover cruising altitude ($Y = \text{ground\_h} + 7.5\text{m}$), forward pitch tilt proportional to acceleration ($-(\text{speed} / \text{max\_speed}) \times 0.28$), and dynamic banking roll into turns ($-\Delta\text{yaw} \times 0.45$).
  - Flies seamlessly across land, hills, and open water bodies.
- **`RotorBlade`**:
  - Independent continuous rotation system animating main top rotors ($40\text{ rad/s}$ around $Y$) and tail stabilizer rotors ($48\text{ rad/s}$ around $X$).

### 2. Multi-Ally Squad Composition & Pre-Equipped Loadouts

1. **Ground Tank Ally (`ally_id: 0`, Left Flank `Vec2::new(-7.0, 4.5)`)**:
   - **Chassis**: High-tech teal/cyan armor (`Color::srgb(0.08, 0.48, 0.52)`) equipped with 4 treaded wheels.
   - **Socket #0 (Top Mount)**: `BigTurret` ($2.0\text{ rad/s}$ traverse).
   - **Turret Sockets #1 & #2**: `BigGun` (Heavy Cannon firing explosive shells with "puchu" sound) & `SmallGun` (Rapid Twin Autocannon).

2. **Aerial Helicopter Gunship Ally (`ally_id: 1`, Right Flank `Vec2::new(7.5, -2.0)`, Cruise Altitude $7.5\text{m}$)**:
   - **Fuselage**: Aerodynamic body with spinning main rotor, tail stabilizer rotor, and undercarriage landing skids.
   - **Socket #0 (Underbelly Chin Mount)**: Inverted `BigTurret` ($2.4\text{ rad/s}$ traverse) hosting a `BigGun` (Heavy Cannon) with downward depression down to $-48.7^\circ$ ($-0.85\text{ rad}$) to track ground enemies from above.
   - **Sockets #1 & #2 (Wing Pylons)**: Port and Starboard `SmallGun` Twin Autocannons with conical gimbal tracking down to $-54.4^\circ$ ($-0.95\text{ rad}$).

### 3. Formation Attitude & Interactive Mouse Command Interface
- **Relative Attitude Mode (`AllyFormationMode::RelativePlayerAttitude`)**:
  - Squad members maintain their echelon formation relative to the player's facing orientation.
- **Mouse Drag Tactical Command**:
  - Clicking and dragging on the terrain projects the target point into local player space, spreading the squad into echelon (Tank on the left flank, Helicopter hovering on the right flank).
  - Glowing holographic waypoint ring (`AllyWaypointer`) tracks the destination on the terrain.

### 4. Downward Turret Tracking & Enemy Swarm Target Selection
- **Least-Time-to-Acquire Targeting**: Big Turrets and Big Guns prioritize targets reachable with minimal combined yaw traverse and pitch adjustment.
- **Underbelly Elevation**: Negative pitch depression ensures helicopters and elevated turrets engage low-elevation ground hordes with precision.
- **Enemy Swarm AI**: Orcs dynamically select and swarm towards the nearest friendly unit (`FriendlyMarker`), engaging both ground vehicles and aerial gunships.

---

## 3. Controls Summary

| Control | Action | Details |
| :--- | :--- | :--- |
| **W / S** | Player Throttle | Accelerates forward / reverse along vehicle heading with momentum and slope physics. |
| **A / D** | Player Steering | Smooth yaw rotation ($2.6\text{ rad/s}$) with tire traction drift. |
| **Left-Click (Click)** | 10-Shot Burst | Fires glowing homing projectile burst from player. |
| **Left-Click (Drag)** | Reposition Squad | Drag anywhere across the terrain to command the Tank and Helicopter allies to a new formation spot. |
| **Right-Click** | 100-Orc Horde Spawner | Spawns 100 Bearded Orcs across the island. |

