# Roblue: Data Architecture (Level 0 Specification)

This document answers the core question: **How do we store, organize, and query all game data?**

---

## 1. Unified Coordinate & World Space

To make 2D $\leftrightarrow$ 3D transitions seamless without teleportation or coordinate conversion bugs, **all simulation data lives in a unified 3D spatial coordinate system ($X, Y, Z$)**:

* **Ground Plane**: $XZ$ plane (where $Y$ is height/vertical axis).
* **2D Orthographic Mode**:
  * Movement systems clamp or lock entity $Y = 0.0$ (or surface ground elevation).
  * 2D sprites are placed at $(X, 0, Z)$ with optional fractional $Y$-sorting or sprite billboard transforms facing the camera angle.
* **3D Perspective Mode**:
  * Unlocks full 3D physics / velocity vectors ($\Delta X, \Delta Y, \Delta Z$).
  * Enables vertical jumping, falling, arcing projectiles, and multi-tier terrain.

---

## 2. ECS Component Hierarchy & Cache Locality

We categorize ECS data into 4 distinct layers:

### Layer A: Hot Simulation Data (Packed, Cache-Friendly Structs)
Components accessed every frame by thousands of enemies and projectiles:
```rust
/// Compact spatial transform for broad-phase simulation
#[derive(Component)]
pub struct Position(pub Vec3);

#[derive(Component)]
pub struct Velocity(pub Vec3);

#[derive(Component)]
pub struct Health {
    pub current: f32,
    pub max: f32,
}

#[derive(Component)]
pub struct HitboxRadius(pub f32);

#[derive(Component)]
pub struct EnemyMarker;

#[derive(Component)]
pub struct ProjectileMarker;
```

### Layer B: Cold / Semantic Metadata
Attached only to entities that need it (Player, Elites, Bosses):
```rust
#[derive(Component)]
pub struct CharacterStats {
    pub move_speed: f32,
    pub attack_cooldown_mult: f32,
    pub damage_mult: f32,
    pub crit_chance: f32,
    pub pickup_radius: f32,
}

#[derive(Component)]
pub struct WeaponInventory {
    pub slots: Vec<WeaponInstance>,
}
```

---

## 3. High-Performance Spatial Partitioning (Spatial Hash Grid)

Running naive $O(N^2)$ distance checks on 5,000 sprites vs 500 projectiles will destroy frame rates. 

* **Storage**: We maintain a centralized `SpatialHashGrid` Bevy Resource.
* **Cell Size**: Uniform grid cells (e.g., $64 \times 64$ units in world space).
* **Frame Lifecycle**:
  1. `clear_grid_system`: Clears bucket lists.
  2. `populate_grid_system`: Hot-inserts all enemy entity IDs into grid buckets in parallel.
  3. `query_grid_system`: Weapons, projectiles, and auto-aim systems query only neighbor cells within radius $R$ ($O(1)$ amortized lookup per query).

```rust
#[derive(Resource, Default)]
pub struct SpatialGrid {
    pub cell_size: f32,
    pub buckets: HashMap<IVec2, Vec<Entity>>,
}
```

---

## 4. Static & Config Data: Data-Driven RON/JSON Schemas

All game content (Weapons, Enemies, Waves, Upgrades, Level Curves) must be decoupled from Rust code using **Rusty Object Notation (`.ron`)** or JSON loaded via Bevy's Asset Loader.

### A. Weapon Definition (`assets/data/weapons.ron`)
```ron
(
    weapons: [
        (
            id: "plasma_orb",
            name: "Plasma Orb",
            description: "Orbits the player dealing continuous contact damage.",
            base_damage: 25.0,
            base_cooldown: 1.5,
            projectile_count: 2,
            projectile_speed: 180.0,
            behavior: Orbiting(radius: 80.0),
            scaling: (
                damage_per_level: 5.0,
                count_increase_levels: [3, 6, 8],
            ),
        ),
        (
            id: "void_laser",
            name: "Void Laser",
            description: "Fires piercing beams toward the nearest dense enemy cluster.",
            base_damage: 50.0,
            base_cooldown: 2.2,
            behavior: TargetedBeam(pierce: 999),
        ),
    ]
)
```

### B. Enemy & Wave Spawner Tables (`assets/data/waves.ron`)
```ron
(
    timeline: [
        (
            start_seconds: 0.0,
            end_seconds: 120.0,
            spawn_rate_per_sec: 15.0,
            pool: [
                (enemy_id: "slime_blue", weight: 80),
                (enemy_id: "slime_spiked", weight: 20),
            ],
            events: [
                (timestamp: 60.0, event: EliteSpawn("golem_mini")),
            ]
        ),
        (
            start_seconds: 120.0,
            end_seconds: 300.0,
            spawn_rate_per_sec: 35.0,
            pool: [
                (enemy_id: "skeleton_swarmer", weight: 60),
                (enemy_id: "bat_flock", weight: 40),
            ],
            events: [
                // Trigger 3D Dimensional Shift Boss Arena!
                (timestamp: 300.0, event: DimensionalShiftBoss("abyssal_colossus")),
            ]
        ),
    ]
)
```

---

## 5. Persistence & Save State Architecture

We split persistence into two distinct scopes:

1. **Active Run State (In-Memory)**:
   * Current run seed (`u64`).
   * Current elapsed time, kill count, collected gold, active build items.
   * Reroll tokens, active curses/modifiers.

2. **Meta Profile (On-Disk Persistent Storage)**:
   * Path: `SavedGames/profile.json` (or Platform AppData).
   * Unlocked characters, passive skill tree levels (e.g. +5% speed, +10% max HP).
   * Achievement flags, high scores, discovered item codex.
   * Serialized with `serde_json` or `bincode` with atomic rename writes (`.tmp` $\to$ `.json`) to prevent save corruption.
