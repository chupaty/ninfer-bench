# 08 - Weapons, Burst Firing & Combat System

## 1. Overview
The combat system in *Roblue* introduces rapid burst-fire weapons with auto-homing targeting and multi-hit enemy destruction rules.

```mermaid
graph TD
    A[Mouse Input] -->|Right Click| B[Mass Orc Spawner: 100 Orcs]
    A -->|Left Click| C[BurstShooter: Queue 10 Shots]
    C --> D[Shot Interval Timer: 0.10s]
    D -->|Tick| E[Spawn Glowing Homing Projectile]
    E --> F[Find Closest Alive Orc]
    F --> G[Dynamic Trajectory Steering]
    G --> H[Hitbox Collision Check]
    H -->|Hit| I[Reduce Orc HP by 1.0]
    I -->|HP <= 0| J[Orc Despawns with SfxKind::LevelUp]
    I -->|HP > 0| K[Damage SFX SfxKind::ActionClick]
```

---

## 2. Controls & Interactions

| Control | Action | Behavior |
| :--- | :--- | :--- |
| **Right-Click** | Spawn 100 Orcs | Scatters 100 64x64 pixel-art bearded orcs around the player (radius 18.0 to 65.0 units) sticking to terrain elevation. |
| **Left-Click** | 10-Shot Burst | Queues 10 shots fired at 0.10s intervals over 1.0 second. First shot fires instantly. |
| **WASD** | Movement | Traverses terrain in 3D, strictly adhering to procedural height ($Y = \text{height}(X, Z) + 1.0$). |
| **Mouse Cursor** | 3D Aim Reticle | Raycasts into 3D world, illuminating terrain with glowing cursor indicator. |

---

## 3. Weapon Payloads, Explosions & Lethality Rules

### Heavy Cannon (Big Gun)
- **Projectile**: Large glowing amber shell ($r=0.38$, emissive intensity $3.0$).
- **Terrain Interaction**: Detonates on contact with the terrain heightfield ($Y \le h(X,Z) + 0.15$), spawning an expanding fiery shockwave (`ExplosionEffect`).
- **Enemy Detonation**: Explodes on direct contact with any orc hitbox.
- **Blast Area of Effect (AOE)**: Shockwave expands to $5.5\text{m}$ radius over $0.35\text{s}$, instantly killing all enemies within the blast envelope.

### Rapid Autocannon (Small Gun / Burst Shooter)
- **Projectile**: Cyan kinetic bullet ($r=0.20$, emissive intensity $1.8$).
- **Terrain Interaction**: Silently despawns upon colliding with terrain ($Y \le h(X,Z) + 0.15$).
- **Enemy Impact**: Direct hits immediately destroy and despawn the target enemy.

### Instant Kill (1-Hit Kill)
- All direct bullet hits (Big Gun and Small Gun) and all explosive shockwave AOE blasts instantly kill and despawn enemy orcs.

---

## 4. Visual Shading & Pixel Art Clarity

To eliminate the "black orc" issue where 3D lighting shadows darken vertical 2D billboard quads:
- Standard material uses `unlit: true` and `alpha_mode: AlphaMode::Mask(0.5)`.
- Nearest-neighbor sampling (`ImageSampler::Nearest`) ensures clean, crisp pixel art scaling under perspective camera rotation.
- Glowing energy projectiles and explosive blast spheres use emissive linear RGBA (`unlit: true`).

