# Roblue: Dual-Mode Camera & Dimensional Transitions

This document details how Roblue achieves smooth, glitch-free transitions between 2D orthographic horde combat and 3D perspective action phases.

---

## 1. The Dimensional Shift Problem & Solution

### The Challenge
In Bevy, switching cameras abruptly between `OrthographicProjection` and `PerspectiveProjection` causes a jarring 1-frame pop, clipping plane discrepancies, and coordinate disorientation for the player.

### The Solution: Continuous Interpolated Camera Rig
Rather than swapping camera entities, we employ a unified **Transition Camera Rig**:

1. **State Machine (`DimensionState`)**:
   * `Mode2D`: Fixed angle (e.g. pitch $-60^\circ$ or $-90^\circ$), orthographic scaling (`scale: f32`).
   * `Transitioning { progress: f32, from: Mode, to: Mode, duration: f32, curve: Ease }`: Smoothly animates camera position, orientation, field-of-view / ortho scale, and projection parameters.
   * `Mode3D`: Orbiting / Follow perspective camera with pitch $-25^\circ$, FOV $60^\circ$, full depth buffer.

```rust
#[derive(Resource, Debug, Clone, PartialEq)]
pub enum DimensionMode {
    TwoD { ortho_scale: f32 },
    Transitioning {
        progress: f32, // 0.0 -> 1.0
        duration: f32,
        from_mode: Box<DimensionMode>,
        to_mode: Box<DimensionMode>,
    },
    ThreeD { fov_degrees: f32, distance: f32, pitch: f32 },
}
```

---

## 2. Rendering Sprites & 3D Models in the Same World

### Player Character (3D Model)
* Rendered as standard 3D glTF mesh with skeletal animation (`bevy_animation`).
* In 2D mode, the 3D lighting highlights the model against flat sprite enemies, creating an evocative *Halls of Torment / Diablo 1* depth contrast.
* In 3D mode, the camera gets close, showcasing attack animations, jump flips, and socketed particle emitters.

### Enemy Horde (2D Sprites)
* Rendered using Bevy's 2D Sprite Bundle / Billboard Mesh.
* **Billboarding Option**: In 3D transition, sprites can either:
  1. *Stay flat on ground plane* (like paper cutouts standing vertically facing the camera).
  2. *Billboard / Yaw toward Camera*: Sprites automatically rotate their transform $Y$-axis to always face the camera viewport, preserving readability during dramatic camera sweeps.
  3. *Pop into Low-Poly 3D*: Key mini-bosses or elites can swap from 2D sprites to 3D meshes during the transition animation.

---

## 3. Lighting, Fog & Visual Effects During Transition

| Visual Element | 2D Orthographic Mode | 3D Perspective Mode |
| :--- | :--- | :--- |
| **Directional Light / Sun** | Flat top-down ambient + soft shadow | Dynamic angled sunlight with long cascades |
| **Volumetric Fog / Skybox** | Disabled / solid dark backdrop | Dynamic skybox, height fog, horizon |
| **Bloom & Post-Processing** | Subtle neon outlines on spell effects | Full screen-space ambient occlusion (SSAO) + bloom |
| **Field of View** | Orthographic (parallel rays) | $60^\circ$ – $75^\circ$ dynamic FOV with speed lines |
