# Roblue: Project Overview & Design Philosophy

## 1. High Concept
**Roblue** is a high-octane bullet-heaven / horde survival game (in the lineage of *Vampire Survivors*, *Halls of Torment*, and *Risk of Rain*) built with the **Bevy Engine** in Rust.

### The Core Twist: Dimensional Shift (2D $\leftrightarrow$ 3D)
* **Standard Combat (2D Orthographic Mode)**:
  * Top-down, non-perspective projection (isometric or top-down flat orthographic).
  * High-density enemy hordes rendered as 2D billboarded or flat sprites (supporting 5,000+ simultaneous units).
  * Fast, planar positioning, crowd control, weapon synergy, and XP collection.
  * The player character is a **fully animated 3D mesh model** moving across the 2D plane.
* **Shift Events (3D Perspective Mode)**:
  * At pivotal moments (e.g., boss summons, berserk phases, special dimensional rifts, arena transitions, or ultimate abilities), the world shifts into full 3D perspective.
  * The camera smoothly pivots into an over-the-shoulder, cinematic third-person, or dynamic action-angle view with true depth.
  * Dimensional mechanics unlock: vertical jumping/dodges, 3D aerial attacks, vertical projectile arcs, and towering multi-layered bosses.

---

## 2. Visual & Architectural Identity

```
  ┌─────────────────────────────────────────────────────────────┐
  │                        ROBLUE WORLD                         │
  │                                                             │
  │   [ 3D Character Model ]            [ 2D Sprite Horde ]     │
  │     - glTF / Skeletal mesh            - Instanced sprites   │
  │     - Real-time 3D lighting           - Planar / Billboard  │
  │     - True 3D spatial bone sockets    - Spatial hash query  │
  │                                                             │
  │                 [ Dual-Mode Camera Rig ]                    │
  │   Orthographic (Top-Down 2D) <───> Perspective (Action 3D)  │
  └─────────────────────────────────────────────────────────────┘
```

---

## 3. Technology Foundation
* **Engine**: Bevy 0.18+ (ECS, modern render pipeline, asset server).
* **Language**: Rust (Edition 2024 / 2021).
* **Architecture**: Strict data-oriented ECS design, deterministic simulation ticking, data-driven RON configs, zero-panic runtime safety.
