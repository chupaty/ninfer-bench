# Roblue: Terrain Generation & Simple Mesh Builder

This document outlines the procedural terrain generation pipeline, height-to-color mapping, water level thresholding, and mesh building algorithms.

---

## 1. Algorithmic Overview

```
 ┌─────────────────────────────────────────────────────────────┐
 │                      Terrain Pipeline                       │
 │                                                             │
 │  1. Coordinate Grid (X, Z)                                  │
 │         │                                                   │
 │         ▼                                                   │
 │  2. Fractal Noise (FBM: Octaves, Persistence, Lacunarity)   │
 │         │                                                   │
 │         ▼                                                   │
 │  3. Height Evaluation: Y = height(X, Z)                     │
 │         │                                                   │
 │         ├──────────────┬─────────────────────────┐          │
 │         ▼              ▼                         ▼          │
 │  Vertex Positions   Vertex Normals         Vertex Colors    │
 │   (X, Y, Z)          (Cross Product)      (Biome Banding)   │
 │         │              │                         │          │
 │         └──────────────┴─────────────────────────┘          │
 │                        │                                    │
 │                        ▼                                    │
 │         4. Bevy `Mesh` Construction                         │
 │            - `Mesh::ATTRIBUTE_POSITION`                     │
 │            - `Mesh::ATTRIBUTE_NORMAL`                       │
 │            - `Mesh::ATTRIBUTE_COLOR`                        │
 │            - `Mesh::ATTRIBUTE_UV_0`                         │
 │            - `Indices::U32`                                 │
 │                        │                                    │
 │                        ▼                                    │
 │         5. Water Plane Mesh (Y = WaterLevel)                │
 └─────────────────────────────────────────────────────────────┘
```

---

## 2. Height Generation: Fractal Brownian Motion (FBM)

We use multi-octave noise to generate smooth rolling terrain with natural hills and valleys:

$$\text{height}(x, z) = \sum_{i=0}^{\text{octaves}-1} A \cdot p^i \cdot \text{noise}(x \cdot f \cdot l^i, z \cdot f \cdot l^i)$$

Where:
* $A$ = Base Amplitude (e.g., $15.0$ units)
* $f$ = Base Frequency (e.g., $0.02$)
* $p$ = Persistence / Gain (e.g., $0.5$)
* $l$ = Lacunarity (e.g., $2.0$)
* $\text{octaves}$ = Number of noise layers (e.g., $4$)

---

## 3. Height-to-Color Biome Gradient

Rather than requiring complex texture splatting initially, we bake vertex colors directly into `Mesh::ATTRIBUTE_COLOR`. The vertex color is selected based on normalized elevation:

| Elevation Band | Height Range ($Y$) | Color Description | RGBA Hex |
| :--- | :--- | :--- | :--- |
| **Deep Water / Ocean Bed** | $Y < \text{WaterLevel} - 2.0$ | Deep Abyssal Blue | `#0d2b45` |
| **Shallow Water / Coast** | $\text{WaterLevel} - 2.0 \le Y < \text{WaterLevel}$ | Turquoise Aqua | `#203c56` |
| **Sand Beach** | $\text{WaterLevel} \le Y < \text{WaterLevel} + 1.0$ | Warm Sand Gold | `#e9c46a` |
| **Lowland Grass** | $\text{WaterLevel} + 1.0 \le Y < 6.0$ | Vibrant Meadow Green | `#2a9d8f` |
| **Highland Forest** | $6.0 \le Y < 12.0$ | Deep Pine Green | `#264653` |
| **Rock Cliff / Mountain** | $12.0 \le Y < 18.0$ | Slate Stone Grey | `#6c757d` |
| **Snow Peak** | $Y \ge 18.0$ | Pure Glacial White | `#f8f9fa` |

```rust
pub fn height_to_color(height: f32, water_level: f32) -> [f32; 4] {
    if height < water_level - 2.0 {
        [0.05, 0.17, 0.27, 1.0] // Deep water bed
    } else if height < water_level {
        [0.12, 0.24, 0.34, 1.0] // Shallow coast
    } else if height < water_level + 1.0 {
        [0.91, 0.77, 0.42, 1.0] // Sand beach
    } else if height < 6.0 {
        [0.16, 0.62, 0.56, 1.0] // Grass
    } else if height < 12.0 {
        [0.15, 0.27, 0.33, 1.0] // Highland
    } else if height < 18.0 {
        [0.42, 0.46, 0.49, 1.0] // Rock
    } else {
        [0.97, 0.98, 0.98, 1.0] // Snow peak
    }
}
```

---

## 4. Simple Regular Heightfield Mesh Builder (The Core Algorithm)

Given a grid size of $W \times H$ vertices with cell spacing $S$:

```rust
use bevy::prelude::*;
use bevy::render::mesh::{Indices, PrimitiveTopology};
use bevy::render::render_asset::RenderAssetUsages;

pub struct TerrainConfig {
    pub width_cells: usize,
    pub depth_cells: usize,
    pub cell_size: f32,
    pub height_scale: f32,
    pub water_level: f32,
}

pub fn build_terrain_mesh(config: &TerrainConfig) -> Mesh {
    let num_verts_x = config.width_cells + 1;
    let num_verts_z = config.depth_cells + 1;
    let total_vertices = num_verts_x * num_verts_z;

    let mut positions = Vec::with_capacity(total_vertices);
    let mut normals = Vec::with_capacity(total_vertices);
    let mut colors = Vec::with_capacity(total_vertices);
    let mut uvs = Vec::with_capacity(total_vertices);

    let half_w = (config.width_cells as f32 * config.cell_size) * 0.5;
    let half_d = (config.depth_cells as f32 * config.cell_size) * 0.5;

    // 1. Generate Vertex Attributes
    for z_idx in 0..num_verts_z {
        let z = (z_idx as f32 * config.cell_size) - half_d;
        for x_idx in 0..num_verts_x {
            let x = (x_idx as f32 * config.cell_size) - half_w;

            // Height evaluation (sample noise or mathematical function)
            let y = sample_height(x, z, config.height_scale);

            positions.push([x, y, z]);
            colors.push(height_to_color(y, config.water_level));
            uvs.push([
                x_idx as f32 / config.width_cells as f32,
                z_idx as f32 / config.depth_cells as f32,
            ]);

            // Normal calculation (central differences)
            let delta = 0.5;
            let h_left = sample_height(x - delta, z, config.height_scale);
            let h_right = sample_height(x + delta, z, config.height_scale);
            let h_down = sample_height(x, z - delta, config.height_scale);
            let h_up = sample_height(x, z + delta, config.height_scale);

            let normal = Vec3::new(h_left - h_right, 2.0 * delta, h_down - h_up).normalize();
            normals.push([normal.x, normal.y, normal.z]);
        }
    }

    // 2. Generate Triangle Indices
    let mut indices = Vec::with_capacity(config.width_cells * config.depth_cells * 6);
    for z in 0..config.depth_cells {
        for x in 0..config.width_cells {
            let top_left = (z * num_verts_x + x) as u32;
            let top_right = top_left + 1;
            let bottom_left = ((z + 1) * num_verts_x + x) as u32;
            let bottom_right = bottom_left + 1;

            // Triangle 1
            indices.push(top_left);
            indices.push(bottom_left);
            indices.push(top_right);

            // Triangle 2
            indices.push(top_right);
            indices.push(bottom_left);
            indices.push(bottom_right);
        }
    }

    // 3. Assemble Mesh
    let mut mesh = Mesh::new(
        PrimitiveTopology::TriangleList,
        RenderAssetUsages::default(),
    );
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_COLOR, colors);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_indices(Indices::U32(indices));

    mesh
}
```

---

## 5. Water Plane Mesh

To complement the terrain, a simple transparent water quad is placed at $Y = \text{WaterLevel}$:

```rust
pub fn build_water_plane(width: f32, depth: f32) -> Mesh {
    Plane3d::default()
        .mesh()
        .size(width, depth)
        .build()
}
```

Rendered with a translucent PBR material:
```rust
materials.add(StandardMaterial {
    base_color: Color::srgba(0.1, 0.4, 0.75, 0.75), // Translucent cyan/blue
    alpha_mode: AlphaMode::Blend,
    perceptual_roughness: 0.1, // Shiny specular water highlights
    metallic: 0.1,
    ..default()
});
```

---

## 6. How this interacts with 2D $\leftrightarrow$ 3D Shifts

1. **In 2D Orthographic Mode**:
   - The camera looks down from above.
   - The terrain vertex colors produce a clean, stylish tactical map (green playfield, sandy coasts, deep blue water lakes).
   - High-contrast background for 2D enemy sprites.
2. **In 3D Perspective Mode**:
   - The camera lowers and tilts.
   - Real 3D depth is revealed: hills, valleys, cliff shadows, and the sunken water surface.
   - Entities on higher ground have visible elevation relative to valleys.
