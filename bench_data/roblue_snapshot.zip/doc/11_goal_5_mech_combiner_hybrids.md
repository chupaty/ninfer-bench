# 11 - Goal 5: Modular Mech Combiner & Vehicle Fusion System (Tentative)

## 1. High Concept & Vision
Goal 5 introduces the **Modular Mech Combiner / Vehicle Fusion System**. Building on the recursive socket hierarchy and decoupled multi-archetype locomotion of Goals 3 & 4, entire autonomous vehicles (Tanks, Helicopters, and future Walkers, Gunboats, and Jets) can dynamically **dock, merge, and transform** with the player's chassis into an **Ultimate Hybrid Mega-Mech**.

```mermaid
graph TD
    subgraph "Separated Squad Mode"
        P[Player Tank Chassis]
        A1[Ally Ground Tank #0]
        A2[Ally Helicopter Gunship #1]
    end

    P & A1 & A2 -->|Press 'F' / Proximity Magnetic Dock| M[⚡ FUSION COMBINE SEQUENCE ⚡]

    subgraph "Ultimate Mega-Hybrid Mech"
        M --> HC[Heavy Armored Ground Base]
        M --> HW[Dorsal Helicopter Jump-Jet Thrusters]
        M --> BA[Synchronized Multi-Turret Artillery Battery]
        M --> FS[Special: Jump-Jet Hover & Amphibious Thrust]
    end

    M -->|Press 'F' Ejection| P & A1 & A2
```

---

## 2. Core Mechanics & Gameplay Loop

### 1. Tactical Transformation (Deploy $\leftrightarrow$ Combine)
* **Separated Squad Mode (Perimeter & Crowd Control)**:
  * Allies operate autonomously via [`AllyController`](file:///c:/dev/roblue/crates/roblue_vehicle/src/components.rs), establishing broad defensive perimeters, herding horde swarms, and tracking independent targets.
* **Combined Super-Mech Mode (Boss Assault & Heavy Breakthrough)**:
  * Snapping the units together forms a single colossal war machine with concentrated firepower, massive durability, and hybrid movement mechanics to punch through dense horde swarms or engage colossal bosses.

---

## 3. Technical Architecture & ECS Data Model

### 1. Recursive Chassis Docking Sockets
* Extend [`SocketKind`](file:///c:/dev/roblue/crates/roblue_vehicle/src/components.rs) with `SocketKind::ChassisDock`:
  * **Dorsal Mount (Socket 0)**: Hosts aerial flight modules (Helicopter Gunship, Jet Boosters).
  * **Port / Starboard Flank Mounts (Sockets 1 & 2)**: Hosts ground tread modules, walker legs, or heavy side armor.
  * **Undercarriage Mount (Socket 3)**: Hosts amphibious hover skirts or heavy sub-turrets.

```rust
pub enum SocketKind {
    Mount,        // Structural vehicle parts (Big Turret, Small Turret)
    Gun,          // Weapon hardpoints (Heavy Cannon, Autocannon)
    ChassisDock,  // Sub-vehicle docking hardpoints (Helicopter, Tank pods, Walker legs)
}
```

### 2. Docking State Machine & Magnetic Snapping
* **`CombinerState` Component / Resource**:
  * `Separated`: Units navigate independently.
  * `Docking { progress: f32, target_socket: usize }`: Magnetic energy beams pull allies toward parent sockets with smooth transform interpolation.
  * `Combined`: Sub-vehicles become child entities of the master player chassis; autonomous navigation is suspended while weapon hardpoints join the master targeting bus.
  * `Undocking { progress: f32 }`: Decouples children, restoring [`VehicleChassis`](file:///c:/dev/roblue/crates/roblue_vehicle/src/components.rs) and [`FlightLocomotion`](file:///c:/dev/roblue/crates/roblue_vehicle/src/components.rs) AI.

### 3. Hybrid Locomotion Fusion (Jump-Jet Hovering)
* When the **Helicopter Gunship** is docked to the dorsal socket:
  * Its main rotor and tail stabilizer act as **High-Thrust Jump Jets**.
  * **Vertical Thruster Lift (`Space` key)**: Engages vertical rotor thrust, allowing the combined tank to leap over terrain ridges, glide across canyons, and hover across open water bodies without shoreline friction.

### 4. Firepower & Weapon Synchronization
* **Unified Weapon Bus**: All attached Big Turrets, Heavy Cannons, and Twin Autocannons across all docked units operate simultaneously.
* **Least-Time-to-Acquire Targeting**: Auto-aim prioritizes targets across all 6+ weapon hardpoints, executing continuous multi-directional firestorms.

---

## 4. Controls Specification

| Control | Action | Details |
| :--- | :--- | :--- |
| **F** | Toggle Combine / Undock | Magnetically snaps nearby allies into Mech Fusion, or unlatches them into squad formation. |
| **W / S** | Master Throttle | Drives the combined heavy chassis with scaled composite mass and acceleration. |
| **A / D** | Master Steering | Steers the combined hybrid with heavy momentum drift. |
| **Space** | Jump-Jet Thruster Boost | Activates docked helicopter rotors to hover/leap over obstacles and water. |
| **Left-Click (Click)** | Primary Burst Fire | Fires central player weapon battery. |
| **Left-Click (Drag)** | Squad Waypoint Command | (In Separated Mode) Repositions squad across the terrain. |
| **Right-Click** | 100-Orc Horde Spawner | Spawns 100 Bearded Orcs for target stress testing. |
